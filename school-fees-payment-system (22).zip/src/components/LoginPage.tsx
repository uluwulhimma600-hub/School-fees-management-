import React, { useState, useEffect } from 'react';

interface User {
  username: string;
  role: 'admin' | 'staff' | 'accountant';
  name: string;
  lastLogin?: string;
}

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  // Default admin credentials
  const DEFAULT_ADMIN = {
    username: 'admin',
    password: 'admin123',
    role: 'admin' as const,
    name: 'Administrator'
  };

  useEffect(() => {
    // Check for remembered login
    const remembered = localStorage.getItem('rememberedUser');
    if (remembered) {
      try {
        const user = JSON.parse(remembered);
        onLogin(user);
      } catch (e) {
        localStorage.removeItem('rememberedUser');
      }
    }

    // Check if already logged in
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      try {
        const user = JSON.parse(currentUser);
        onLogin(user);
      } catch (e) {
        localStorage.removeItem('currentUser');
      }
    }
  }, [onLogin]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // Check against stored users or default admin
    const storedUsers = localStorage.getItem('users');
    const users: any[] = storedUsers ? JSON.parse(storedUsers) : [DEFAULT_ADMIN];

    const user = users.find(
      u => u.username.toLowerCase() === username.toLowerCase() && u.password === password
    );

    if (user) {
      const userData: User = {
        username: user.username,
        role: user.role,
        name: user.name,
        lastLogin: new Date().toISOString()
      };

      if (rememberMe) {
        localStorage.setItem('rememberedUser', JSON.stringify(userData));
      }

      localStorage.setItem('currentUser', JSON.stringify(userData));
      localStorage.setItem('loginTime', Date.now().toString());
      
      // Log login activity
      const loginLogs = JSON.parse(localStorage.getItem('loginLogs') || '[]');
      loginLogs.push({
        username: user.username,
        timestamp: new Date().toISOString(),
        action: 'login'
      });
      localStorage.setItem('loginLogs', JSON.stringify(loginLogs.slice(-50)));

      onLogin(userData);
    } else {
      setError('Invalid username or password. Please try again.');
    }

    setIsLoading(false);
  };

  const handleResetPassword = () => {
    if (!resetEmail) {
      setError('Please enter your email address');
      return;
    }

    // In a real app, this would send a reset email
    alert('Password reset instructions have been sent to your email address.\n\nFor demo purposes, use:\nUsername: admin\nPassword: admin123');
    setShowResetModal(false);
    setResetEmail('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-teal-700 to-teal-900 flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          {(() => {
            // Try to load school logo from settings
            const savedSettings = localStorage.getItem('settings');
            const logo = savedSettings ? JSON.parse(savedSettings).logo : null;
            return (
              <div className="bg-white rounded-full w-32 h-32 mx-auto mb-4 flex items-center justify-center shadow-2xl p-2 border-4 border-teal-300">
                {logo ? (
                  <img src={logo} alt="School Logo" className="w-full h-full object-contain rounded-full" />
                ) : (
                  <div className="w-full h-full rounded-full bg-white flex flex-col items-center justify-center p-2 relative border-4 border-teal-600">
                    <div className="my-1 flex flex-col items-center">
                      <i className="fas fa-school text-3xl text-teal-600"></i>
                    </div>
                    <p className="text-[6px] font-black tracking-wider leading-tight uppercase text-teal-800">School Fees</p>
                    <p className="text-[5px] font-bold text-teal-700 leading-tight">Management System</p>
                  </div>
                )}
              </div>
            );
          })()}
          <h1 className="text-3xl font-bold text-white mb-2">School Fees Management</h1>
          <p className="text-teal-100">School Fees Management System</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Welcome Back</h2>
            <p className="text-gray-500 text-sm mt-1">Sign in to your account</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            {/* Username Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <i className="fas fa-user mr-2 text-teal-600"></i>
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                placeholder="Enter your username"
                required
                autoComplete="username"
              />
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <i className="fas fa-lock mr-2 text-teal-600"></i>
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all pr-12"
                  placeholder="Enter your password"
                  required
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                />
                <span className="ml-2 text-sm text-gray-600">Remember me</span>
              </label>
              <button
                type="button"
                onClick={() => setShowResetModal(true)}
                className="text-sm text-teal-600 hover:text-teal-800 font-medium"
              >
                Forgot password?
              </button>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
                <i className="fas fa-exclamation-circle mr-2"></i>
                <span className="text-sm">{error}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-teal-600 text-white py-3 rounded-lg hover:bg-teal-700 font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isLoading ? (
                <>
                  <i className="fas fa-circle-notch fa-spin mr-2"></i>
                  Signing in...
                </>
              ) : (
                <>
                  <i className="fas fa-sign-in-alt mr-2"></i>
                  Sign In
                </>
              )}
            </button>
          </form>

          
        </div>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-teal-100 text-sm">
            <i className="fas fa-shield-alt mr-1"></i>
            Secure & Encrypted Login
          </p>
        </div>
      </div>

      {/* Password Reset Modal */}
      {showResetModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-800">Reset Password</h3>
              <button
                onClick={() => setShowResetModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>

            <p className="text-gray-600 text-sm mb-4">
              Enter your email address and we'll send you instructions to reset your password.
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                placeholder="your@email.com"
              />
            </div>

            <div className="flex space-x-3">
              <button
                onClick={handleResetPassword}
                className="flex-1 bg-teal-600 text-white py-2 rounded-lg hover:bg-teal-700"
              >
                Send Reset Link
              </button>
              <button
                onClick={() => setShowResetModal(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
