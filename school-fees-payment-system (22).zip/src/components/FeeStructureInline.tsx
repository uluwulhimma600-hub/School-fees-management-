import React, { useState } from 'react';

interface FeeStructure {
  id: number;
  class: string;
  term: string;
  amount: number;
  session: string;
}

interface FeeStructureInlineProps {
  feeStructures: FeeStructure[];
  setFeeStructures: React.Dispatch<React.SetStateAction<FeeStructure[]>>;
}

const CLASS_OPTIONS = [
  'Nursery 1', 'Nursery 2', 'Nursery 3',
  'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6',
  'JSS1', 'JSS2', 'JSS3',
  'SS1', 'SS2', 'SS3'
];

const TERM_OPTIONS = ['1st', '2nd', '3rd'];

export default function FeeStructureInline({ feeStructures, setFeeStructures }: FeeStructureInlineProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingFee, setEditingFee] = useState<FeeStructure | null>(null);
  const [formData, setFormData] = useState({
    class: 'Nursery 1',
    term: '1st',
    amount: '',
    session: new Date().getFullYear().toString()
  });
  const [filterClass, setFilterClass] = useState('');
  const [filterTerm, setFilterTerm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingFee) {
      const updated = feeStructures.map(fee =>
        fee.id === editingFee.id
          ? { ...fee, ...formData, amount: parseFloat(formData.amount) }
          : fee
      );
      setFeeStructures(updated);
      localStorage.setItem('feeStructures', JSON.stringify(updated));
    } else {
      const exists = feeStructures.find(
        f => f.class === formData.class && f.term === formData.term && f.session === formData.session
      );

      if (exists) {
        alert('Fee structure for this class, term, and session already exists!');
        return;
      }

      const newFee: FeeStructure = {
        id: Date.now(),
        class: formData.class,
        term: formData.term,
        amount: parseFloat(formData.amount),
        session: formData.session
      };
      const updated = [...feeStructures, newFee];
      setFeeStructures(updated);
      localStorage.setItem('feeStructures', JSON.stringify(updated));
    }

    setShowForm(false);
    setEditingFee(null);
    setFormData({
      class: 'Nursery 1',
      term: '1st',
      amount: '',
      session: new Date().getFullYear().toString()
    });
  };

  const handleEdit = (fee: FeeStructure) => {
    setEditingFee(fee);
    setFormData({
      class: fee.class,
      term: fee.term,
      amount: fee.amount.toString(),
      session: fee.session
    });
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this fee structure?')) {
      const updated = feeStructures.filter(f => f.id !== id);
      setFeeStructures(updated);
      localStorage.setItem('feeStructures', JSON.stringify(updated));
    }
  };

  const filteredFees = feeStructures.filter(fee => {
    const matchesClass = !filterClass || fee.class === filterClass;
    const matchesTerm = !filterTerm || fee.term === filterTerm;
    return matchesClass && matchesTerm;
  });

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <div className="bg-blue-50 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-blue-600">{feeStructures.length}</p>
          <p className="text-xs text-gray-600">Fee Structures</p>
        </div>
        <div className="bg-green-50 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-green-600">
            {new Set(feeStructures.map(f => f.class)).size}
          </p>
          <p className="text-xs text-gray-600">Classes</p>
        </div>
        <div className="bg-purple-50 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-purple-600">
            {feeStructures.reduce((sum, f) => sum + f.amount, 0).toLocaleString()}
          </p>
          <p className="text-xs text-gray-600">Total Value (₦)</p>
        </div>
      </div>

      {/* Filters and Add Button */}
      <div className="flex gap-2">
        <select
          value={filterClass}
          onChange={(e) => setFilterClass(e.target.value)}
          className="flex-1 border rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All Classes</option>
          {CLASS_OPTIONS.map(c => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <select
          value={filterTerm}
          onChange={(e) => setFilterTerm(e.target.value)}
          className="md:w-32 border rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All Terms</option>
          {TERM_OPTIONS.map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <button
          onClick={() => {
            setEditingFee(null);
            setFormData({
              class: 'Nursery 1',
              term: '1st',
              amount: '',
              session: new Date().getFullYear().toString()
            });
            setShowForm(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm whitespace-nowrap"
        >
          <i className="fas fa-plus mr-1"></i>Add Fee
        </button>
      </div>

      {/* Fee Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredFees.map(fee => (
          <div key={fee.id} className="bg-white border-2 border-blue-200 rounded-lg p-3">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-bold text-gray-800">{fee.class}</h4>
                <p className="text-xs text-gray-600">{fee.term} Term</p>
              </div>
              <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">
                {fee.session}
              </span>
            </div>
            <p className="text-xl font-bold text-blue-600 mb-2">₦{fee.amount.toLocaleString()}</p>
            <div className="flex space-x-2">
              <button
                onClick={() => handleEdit(fee)}
                className="flex-1 bg-blue-600 text-white py-1.5 rounded text-xs hover:bg-blue-700"
              >
                <i className="fas fa-edit mr-1"></i>Edit
              </button>
              <button
                onClick={() => handleDelete(fee.id)}
                className="flex-1 bg-red-600 text-white py-1.5 rounded text-xs hover:bg-red-700"
              >
                <i className="fas fa-trash mr-1"></i>Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredFees.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <i className="fas fa-file-invoice-dollar text-4xl mb-2"></i>
          <p className="text-sm">No fee structures found. Add your first fee structure!</p>
        </div>
      )}

      {/* Add/Edit Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-800">
                  {editingFee ? 'Edit Fee Structure' : 'Add Fee Structure'}
                </h3>
                <button
                  onClick={() => {
                    setShowForm(false);
                    setEditingFee(null);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Class *</label>
                  <select
                    value={formData.class}
                    onChange={(e) => setFormData({ ...formData, class: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm"
                    required
                  >
                    {CLASS_OPTIONS.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Term *</label>
                  <select
                    value={formData.term}
                    onChange={(e) => setFormData({ ...formData, term: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm"
                    required
                  >
                    {TERM_OPTIONS.map(t => (
                      <option key={t} value={t}>{t} Term</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Session *</label>
                  <input
                    type="text"
                    value={formData.session}
                    onChange={(e) => setFormData({ ...formData, session: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm"
                    placeholder="e.g., 2025"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Fee Amount (₦) *</label>
                  <input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm"
                    placeholder="e.g., 50000"
                    required
                    min="1"
                  />
                </div>

                <div className="flex space-x-2 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 text-sm"
                  >
                    {editingFee ? 'Update' : 'Save'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowForm(false);
                      setEditingFee(null);
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
