const CACHE_VERSION = 'v3';
const CACHE_NAME = `schoolfees-${CACHE_VERSION}`;

// Install - cache the app immediately
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // Cache the main page and all assets
      return cache.addAll([
        './',
        './index.html',
        './manifest.json',
        './sw.js',
        './icons/icon-72x72.png',
        './icons/icon-128x128.png',
        './icons/icon-192x192.png',
        './icons/icon-512x512.png',
        './images/kida-logo.png'
      ]).catch(() => {
        // If some fail, cache what we can
        return cache.addAll(['./', './index.html', './manifest.json']);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate - delete old caches, take control immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch - ALWAYS serve from cache first for offline support
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  if (!event.request.url.startsWith('http')) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      // CACHE FIRST - return cached immediately if available
      if (cached) {
        // Update cache in background (don't wait)
        event.waitUntil(
          fetch(event.request).then((fresh) => {
            if (fresh && fresh.ok) {
              caches.open(CACHE_NAME).then((c) => c.put(event.request, fresh));
            }
          }).catch(() => {})
        );
        return cached;
      }

      // Not in cache - fetch from network
      return fetch(event.request).then((response) => {
        if (response && response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((c) => c.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        // Completely offline and not cached
        if (event.request.mode === 'navigate') {
          // Return the cached index.html for any page request
          return caches.match('./index.html')
            .then((r) => r || caches.match('/'))
            .then((r) => r || new Response('<h1>Offline</h1>', {
              headers: { 'Content-Type': 'text/html' }
            }));
        }
        return new Response('', { status: 503 });
      });
    })
  );
});

// Skip waiting when told to update
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
