import jsPDF from 'jspdf';

export function generateUserManual() {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  const addPage = () => {
    doc.addPage();
    y = 20;
  };

  const checkPage = (needed: number) => {
    if (y + needed > 270) addPage();
  };

  const title = (text: string, size: number = 18) => {
    checkPage(15);
    doc.setFontSize(size);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text(text, margin, y);
    y += size * 0.6;
  };

  const subtitle = (text: string) => {
    checkPage(12);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(55, 65, 81);
    doc.text(text, margin, y);
    y += 7;
  };

  const body = (text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 5;
  };

  const bullet = (text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth - 8);
    doc.text('•', margin + 2, y);
    doc.text(lines, margin + 8, y);
    y += lines.length * 5;
  };

  const numberedItem = (num: string, text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text(num, margin + 2, y);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth - 12);
    doc.text(lines, margin + 12, y);
    y += lines.length * 5;
  };

  const spacer = (h: number = 5) => { y += h; };

  const line = () => {
    checkPage(5);
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 5;
  };

  const pageFooter = () => {
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(150, 150, 150);
      doc.text(`SchoolFees Pro - User Manual | Page ${i} of ${totalPages}`, pageWidth / 2, 290, { align: 'center' });
      doc.text('Developed by Kida Digital Solutions Centre | 0703 856 2100', pageWidth / 2, 295, { align: 'center' });
    }
  };

  // ==========================================
  // COVER PAGE
  // ==========================================
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 120, 'F');

  doc.setFontSize(32);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('SchoolFees Pro', pageWidth / 2, 45, { align: 'center' });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text('School Fees Payment System', pageWidth / 2, 58, { align: 'center' });

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('USER MANUAL', pageWidth / 2, 80, { align: 'center' });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Complete Guide for School Administrators & Staff', pageWidth / 2, 95, { align: 'center' });
  doc.text('Version 1.0 | April 2026', pageWidth / 2, 105, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(55, 65, 81);
  doc.setFont('helvetica', 'bold');
  doc.text('Developed by:', pageWidth / 2, 145, { align: 'center' });

  doc.setFontSize(16);
  doc.setTextColor(37, 99, 235);
  doc.text('Kida Digital Solutions Centre', pageWidth / 2, 158, { align: 'center' });

  doc.setFontSize(10);
  doc.setTextColor(75, 85, 99);
  doc.setFont('helvetica', 'normal');
  doc.text('Software Development & ICT Services', pageWidth / 2, 168, { align: 'center' });
  doc.text('Besides Kida Primary School, Hawul L.G.A, Borno State', pageWidth / 2, 178, { align: 'center' });
  doc.text('Phone: 0703 856 2100 | Email: support@kidadigital.com', pageWidth / 2, 188, { align: 'center' });
  doc.text('Website: www.kidadigital.com', pageWidth / 2, 198, { align: 'center' });

  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text('© 2026 Kida Digital Solutions Centre. All rights reserved.', pageWidth / 2, 275, { align: 'center' });

  // ==========================================
  // TABLE OF CONTENTS
  // ==========================================
  addPage();
  title('TABLE OF CONTENTS', 22);
  spacer(10);

  const tocItems = [
    '1. Introduction ........................................... 3',
    '',
    '   >> Advantages of Digital Payment System ................ 4',
    '   >> Disadvantages of Manual Payment System .............. 6',
    '   >> Comparison Table: Digital vs Manual ................. 8',
    '',
    '2. System Requirements .................................... 9',
    '3. Getting Started - Login ................................ 10',
    '4. Dashboard Overview ..................................... 11',
    '5. Student Management ..................................... 12',
    '6. Fee Structure Setup .................................... 14',
    '7. Recording Payments ..................................... 15',
    '8. Payment PIN Security ................................... 17',
    '9. Payment History & Reprint .............................. 18',
    '10. Reports & Exports ..................................... 19',
    '11. Bulk SMS to Parents ................................... 20',
    '12. Receipt Management .................................... 21',
    '13. Class Promotion & Graduation .......................... 22',
    '14. Settings & Configuration .............................. 23',
    '15. User Management ....................................... 24',
    '16. Account Security ...................................... 25',
    '17. Digital Signature ..................................... 26',
    '18. Bluetooth Printing .................................... 26',
    '19. PWA - Install on Phone ................................ 27',
    '20. Offline Mode .......................................... 27',
    '21. Troubleshooting ....................................... 28',
    '22. Contact & Support ..................................... 29',
  ];

  tocItems.forEach(item => {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(55, 65, 81);
    doc.text(item, margin, y);
    y += 7;
  });

  // ==========================================
  // 1. INTRODUCTION
  // ==========================================
  addPage();
  title('1. INTRODUCTION');
  spacer();
  body('SchoolFees Pro is a comprehensive, modern school fees payment management system designed specifically for Nigerian schools. It helps schools manage student records, collect fees, generate receipts, track payments, send SMS reminders to parents, and much more.');
  spacer();
  body('Key features include:');
  bullet('Complete student management with passport photos');
  bullet('Fee structure setup per class and term');
  bullet('Secure payment recording with 4-digit PIN');
  bullet('Professional receipt generation and printing');
  bullet('Bluetooth printer support for mobile printing');
  bullet('PDF export for receipts and reports');
  bullet('Bulk SMS messaging to parents with outstanding fees');
  bullet('Class promotion and graduation management');
  bullet('User management with role-based access (Admin, Staff, Accountant)');
  bullet('Works completely offline as a Progressive Web App (PWA)');
  bullet('Digital signature for receipts');
  bullet('Export student data to CSV');
  spacer();
  line();

  // ==========================================
  // ADVANTAGES OF DIGITAL PAYMENT SYSTEM
  // ==========================================
  addPage();
  title('WHY DIGITAL SCHOOL FEE PAYMENT?', 20);
  spacer(5);

  // Green header box
  doc.setFillColor(220, 252, 231);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('ADVANTAGES OF DIGITAL / ONLINE SCHOOL PAYMENT SYSTEM', margin + 5, y + 8);
  y += 18;

  subtitle('1. Accuracy & Error-Free Records');
  body('Digital systems automatically calculate fees, balances, and totals eliminating human calculation errors that are common with manual bookkeeping. Every naira is accounted for with precision.');
  spacer();

  subtitle('2. Real-Time Financial Reports');
  body('Administrators can instantly view today\'s collection, total revenue, outstanding balances, and class-wise reports. No more waiting for end-of-term manual compilation.');
  spacer();

  subtitle('3. Time Saving');
  body('What takes hours of manual work - writing receipts, searching records, calculating balances - is done in seconds with a digital system. Staff can serve more parents in less time.');
  spacer();

  subtitle('4. Secure & Tamper-Proof');
  body('Digital records cannot be altered without authorization. PIN-protected payments, login authentication, and activity logging ensure every transaction is secure and traceable.');
  spacer();

  subtitle('5. Instant Receipt Generation');
  body('Professional receipts are generated automatically with school logo, signature, and all payment details. Receipts can be printed, exported as PDF, or sent via Bluetooth to mobile printers.');
  spacer();

  subtitle('6. Easy Student Search & History');
  body('Find any student\'s payment history in seconds by searching their name. Reprint any past receipt instantly. No more digging through piles of paper.');
  spacer();

  checkPage(60);
  subtitle('7. Parent Communication (SMS)');
  body('Send bulk SMS reminders to parents with outstanding fees, including student name, class, amount due, and payment deadline. Improves collection rates significantly.');
  spacer();

  subtitle('8. Works Offline');
  body('Unlike many online systems, SchoolFees Pro works completely offline after installation. No internet required for daily operations - perfect for areas with poor connectivity.');
  spacer();

  subtitle('9. Data Backup & Safety');
  body('All data is stored securely on the device. No risk of losing physical receipt books to fire, water damage, or theft. Data persists even when the device is offline.');
  spacer();

  subtitle('10. Class Promotion Automation');
  body('Automatically promote students to the next class at the end of the session with one click. SS3 graduates are organized in folders by year for permanent records.');
  spacer();

  subtitle('11. Multi-User Access');
  body('Multiple staff members can use the system with different roles (Admin, Accountant, Staff). Each user has their own login and permissions.');
  spacer();

  subtitle('12. Professional Image');
  body('Printed digital receipts with school logo and signature give your school a professional, modern image that builds trust with parents and the community.');
  spacer();

  subtitle('13. Cost Effective');
  body('No need to buy expensive receipt books, ledgers, or printing materials. The system runs on any phone, tablet, or computer you already have.');
  spacer();

  subtitle('14. Student Passport Photos');
  body('Each student\'s passport photo is stored digitally, making identification easy and eliminating the need for separate photo records.');
  spacer();

  subtitle('15. Export & Reporting');
  body('Export student lists, payment records, and reports to CSV files for further analysis in Excel. Generate class lists, unpaid student reports, and daily collection summaries.');
  spacer();

  // ==========================================
  // DISADVANTAGES OF MANUAL PAYMENT
  // ==========================================
  addPage();

  // Red header box
  doc.setFillColor(254, 226, 226);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(153, 27, 27);
  doc.text('DISADVANTAGES OF MANUAL / PAPER-BASED PAYMENT SYSTEM', margin + 5, y + 8);
  y += 18;

  subtitle('1. Human Calculation Errors');
  body('Manual calculations of fees, balances, and totals are prone to mistakes. A single arithmetic error can cause discrepancies that take hours to trace and correct.');
  spacer();

  subtitle('2. Time Consuming');
  body('Writing receipts by hand, searching through ledgers, calculating balances manually, and compiling reports takes excessive time that could be spent on education.');
  spacer();

  subtitle('3. Easy to Manipulate');
  body('Paper records can be easily altered, forged, or destroyed. Without proper controls, dishonest staff can manipulate records, leading to financial losses for the school.');
  spacer();

  subtitle('4. Lost or Damaged Records');
  body('Physical receipt books and ledgers can be lost, stolen, damaged by water, destroyed by fire, or eaten by termites. Once lost, the records are gone forever.');
  spacer();

  subtitle('5. No Real-Time Reports');
  body('Getting a financial summary requires manually counting through all receipt books. End-of-term reports take days to compile, and errors are common.');
  spacer();

  subtitle('6. Difficult to Search');
  body('Finding a specific student\'s payment record means flipping through pages of receipt books. If the receipt book is misplaced, the record is inaccessible.');
  spacer();

  subtitle('7. No Parent Communication');
  body('There is no efficient way to remind parents about outstanding fees. Schools must rely on sending physical letters or verbal reminders, which are often ignored.');
  spacer();

  subtitle('8. Receipt Duplication Issues');
  body('Duplicate or fake receipts can be created easily with manual systems. Parents may present forged receipts as proof of payment.');
  spacer();

  checkPage(50);
  subtitle('9. Storage Problems');
  body('Years of receipt books take up significant physical storage space. Filing and organizing them is a constant challenge.');
  spacer();

  subtitle('10. No Student Photos');
  body('Manual systems rarely include student photos, making it easy for identity confusion, especially in large schools.');
  spacer();

  subtitle('11. Unprofessional Appearance');
  body('Handwritten receipts look unprofessional and may not include all necessary details. This can affect the school\'s reputation with parents.');
  spacer();

  subtitle('12. Costly Materials');
  body('Continuous purchase of receipt books, carbon papers, ledgers, pens, and filing materials adds up to significant recurring costs.');
  spacer();

  subtitle('13. No Audit Trail');
  body('Manual systems lack a proper audit trail. It\'s difficult to track who recorded which payment, when, and whether any changes were made.');
  spacer();

  subtitle('14. Difficult Class Promotion');
  body('Manually updating student records for class promotion at the end of each session is tedious, error-prone, and time-consuming.');
  spacer();

  subtitle('15. Single Point of Failure');
  body('If the person responsible for the receipt books is absent, sick, or leaves the school, the entire payment system is disrupted.');
  spacer();

  // ==========================================
  // COMPARISON TABLE
  // ==========================================
  addPage();

  // Blue header
  doc.setFillColor(219, 234, 254);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('COMPARISON: DIGITAL vs MANUAL PAYMENT SYSTEM', margin + 5, y + 8);
  y += 20;

  // Table header
  doc.setFillColor(37, 99, 235);
  doc.rect(margin, y, contentWidth, 8, 'F');
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('Feature', margin + 3, y + 6);
  doc.text('Digital (SchoolFees Pro)', margin + 55, y + 6);
  doc.text('Manual (Paper-Based)', margin + 125, y + 6);
  y += 10;

  const tableRow = (feature: string, digital: string, manual: string, isEven: boolean) => {
    checkPage(10);
    if (isEven) {
      doc.setFillColor(249, 250, 251);
      doc.rect(margin, y - 1, contentWidth, 8, 'F');
    }
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(55, 65, 81);
    doc.text(feature, margin + 3, y + 4);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(22, 101, 52);
    const dLines = doc.splitTextToSize(digital, 60);
    doc.text(dLines, margin + 55, y + 4);
    doc.setTextColor(153, 27, 27);
    const mLines = doc.splitTextToSize(manual, 45);
    doc.text(mLines, margin + 125, y + 4);
    y += Math.max(dLines.length, mLines.length) * 5 + 3;
  };

  tableRow('Speed', 'Instant (seconds)', 'Slow (minutes/hours)', false);
  tableRow('Accuracy', '100% accurate calculations', 'Prone to human errors', true);
  tableRow('Receipt', 'Auto-generated, professional', 'Handwritten, unprofessional', false);
  tableRow('Search', 'Instant search by name', 'Manual page-by-page search', true);
  tableRow('Reports', 'Real-time, one-click', 'Manual compilation (days)', false);
  tableRow('Security', 'PIN-protected, logged', 'Easy to forge/manipulate', true);
  tableRow('Storage', 'Digital, unlimited', 'Physical, limited space', false);
  tableRow('Backup', 'Auto-saved on device', 'No backup, can be lost', true);
  tableRow('Parent SMS', 'Bulk SMS with details', 'No efficient method', false);
  tableRow('Cost', 'One-time setup, no materials', 'Recurring material costs', true);
  tableRow('Offline', 'Works offline (PWA)', 'N/A (always manual)', false);
  tableRow('Photos', 'Student passport stored', 'No photo records', true);
  tableRow('Promotion', 'One-click class promotion', 'Manual, time-consuming', false);
  tableRow('Multi-user', 'Multiple users with roles', 'Usually one person', true);
  tableRow('Audit Trail', 'Complete transaction log', 'No audit trail', false);
  tableRow('Professional', 'Logo, signature, modern', 'Basic, outdated', true);

  spacer(10);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('CONCLUSION:', margin, y);
  y += 7;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(55, 65, 81);
  const conclusion = 'SchoolFees Pro eliminates all the problems associated with manual fee collection. It saves time, reduces errors, improves security, enhances communication with parents, and gives your school a professional, modern image. The system pays for itself within weeks through improved efficiency and reduced material costs. Investing in a digital payment system is not just an upgrade — it is a necessity for any school that wants to operate efficiently in the 21st century.';
  const concLines = doc.splitTextToSize(conclusion, contentWidth);
  doc.text(concLines, margin, y);
  y += concLines.length * 5;
  spacer();
  line();

  // ==========================================
  // 2. SYSTEM REQUIREMENTS
  // ==========================================
  addPage();
  title('2. SYSTEM REQUIREMENTS');
  spacer();
  body('SchoolFees Pro works on any device with a modern web browser:');
  spacer();
  subtitle('Supported Devices:');
  bullet('Android phones and tablets (Chrome browser recommended)');
  bullet('iPhones and iPads (Safari browser)');
  bullet('Windows, Mac, and Linux computers (Chrome, Edge, or Firefox)');
  spacer();
  subtitle('Minimum Requirements:');
  bullet('Internet connection for first-time setup only');
  bullet('After installation, the app works completely offline');
  bullet('At least 50MB free storage space');
  bullet('Camera access for student passport photos (optional)');
  bullet('Bluetooth for wireless printing (optional)');
  spacer();
  line();

  // ==========================================
  // 3. GETTING STARTED - LOGIN
  // ==========================================
  addPage();
  title('3. GETTING STARTED - LOGIN');
  spacer();
  body('When you open the app for the first time, you will see the login page.');
  spacer();
  subtitle('How to Login:');
  numberedItem('1.', 'Open the app in your web browser');
  numberedItem('2.', 'Enter your username in the "Username" field');
  numberedItem('3.', 'Enter your password in the "Password" field');
  numberedItem('4.', 'Optionally check "Remember me" to stay logged in');
  numberedItem('5.', 'Click "Sign In"');
  spacer();
  subtitle('Default Admin Credentials:');
  body('The default administrator account is set up automatically. Contact the system administrator or developer for login credentials.');
  spacer();
  subtitle('Forgot Password:');
  body('If you forget your password, click "Forgot password?" on the login page. Contact the administrator at 0703 856 2100 for password reset assistance.');
  spacer();
  subtitle('User Roles:');
  bullet('Admin - Full access to all features including user management, fee structure, and class promotion');
  bullet('Accountant - Access to payments, reports, and student management');
  bullet('Staff - Basic access to view students and record payments');
  spacer();
  line();

  // ==========================================
  // 4. DASHBOARD
  // ==========================================
  addPage();
  title('4. DASHBOARD OVERVIEW');
  spacer();
  body('The dashboard is the main screen you see after logging in. It provides a quick overview of the school\'s financial status.');
  spacer();
  subtitle('Dashboard Cards:');
  bullet('Today\'s Collection - Total amount collected today');
  bullet('Total Collection (All Term) - Total amount collected across all terms');
  bullet('Total Students - Number of registered students');
  spacer();
  subtitle('Collection by Class:');
  body('Shows the total fees collected for each class, helping you identify which classes have the highest collection rates.');
  spacer();
  subtitle('Recent Payments:');
  body('Displays the last 5 payment transactions with student name, class, amount, and date.');
  spacer();
  line();

  // ==========================================
  // 5. STUDENT MANAGEMENT
  // ==========================================
  addPage();
  title('5. STUDENT MANAGEMENT');
  spacer();
  body('The Students section allows you to add, edit, and manage all student records.');
  spacer();

  subtitle('Adding a New Student:');
  numberedItem('1.', 'Navigate to "Students" from the menu');
  numberedItem('2.', 'Click the "Add Student" button (blue button, top right)');
  numberedItem('3.', 'Upload or take a passport photo using the camera buttons');
  numberedItem('4.', 'Enter the student\'s full name');
  numberedItem('5.', 'Select the class (Nursery 1 to SS3)');
  numberedItem('6.', 'Select the term (1st, 2nd, or 3rd)');
  numberedItem('7.', 'The fee amount will auto-fill based on the fee structure (if configured)');
  numberedItem('8.', 'Enter the parent\'s phone number');
  numberedItem('9.', 'Click "Add Student" to save');
  spacer();
  body('Note: The admission number is generated automatically in the format ADM/YY/XXXX.');
  spacer();

  subtitle('Taking a Passport Photo:');
  bullet('Click "Back" to use the rear camera');
  bullet('Click "Front" to use the selfie camera');
  bullet('Click "Switch" to toggle between cameras while the camera is open');
  bullet('Click "Capture" to take the photo');
  bullet('The photo will be saved with the student record');
  spacer();

  subtitle('Editing a Student:');
  numberedItem('1.', 'Find the student in the list (use search or class filter)');
  numberedItem('2.', 'Click the "Edit" button (blue button)');
  numberedItem('3.', 'Update the desired fields');
  numberedItem('4.', 'Click "Update Student" to save changes');
  spacer();

  subtitle('Deleting a Student:');
  numberedItem('1.', 'Find the student in the list');
  numberedItem('2.', 'Click the "Delete" button (red button)');
  numberedItem('3.', 'Confirm the deletion in the popup dialog');
  spacer();

  subtitle('Searching Students:');
  body('Use the search box to find students by name, admission number, or phone number. Use the class dropdown to filter by class.');
  spacer();
  line();

  // ==========================================
  // 6. FEE STRUCTURE
  // ==========================================
  addPage();
  title('6. FEE STRUCTURE SETUP');
  spacer();
  body('The Fee Structure allows administrators to set the fees for each class and term. When a new student is added, the fee will auto-fill based on the configured structure.');
  spacer();

  subtitle('Setting Up Fees (Admin Only):');
  numberedItem('1.', 'Go to Settings');
  numberedItem('2.', 'Scroll down to "Fee Structure" section');
  numberedItem('3.', 'Click "Add Fee"');
  numberedItem('4.', 'Select the Class (e.g., JSS1)');
  numberedItem('5.', 'Select the Term (e.g., 1st Term)');
  numberedItem('6.', 'Enter the Session (e.g., 2026)');
  numberedItem('7.', 'Enter the Fee Amount (e.g., 50000)');
  numberedItem('8.', 'Click "Save"');
  spacer();
  body('Repeat for all classes and terms. You can edit or delete fee structures at any time.');
  spacer();

  subtitle('How Auto-Fill Works:');
  body('When adding a new student, select the class and term. If a fee structure exists for that combination, the fee amount will automatically fill in. You can still manually override the amount if needed.');
  spacer();
  line();

  // ==========================================
  // 7. RECORDING PAYMENTS
  // ==========================================
  addPage();
  title('7. RECORDING PAYMENTS');
  spacer();
  body('The Payments section is where you record fee payments from students.');
  spacer();

  subtitle('How to Record a Payment:');
  numberedItem('1.', 'Navigate to "Payments" from the menu');
  numberedItem('2.', 'Type the student\'s name in the search box');
  numberedItem('3.', 'Select the student from the dropdown results (shows passport photo and balance)');
  numberedItem('4.', 'Review the student\'s information and outstanding balance');
  numberedItem('5.', 'Select the term (1st, 2nd, or 3rd)');
  numberedItem('6.', 'Enter the amount being paid');
  numberedItem('7.', 'Click "Record Payment & Generate Receipt"');
  numberedItem('8.', 'Enter your 4-digit Payment PIN when prompted');
  numberedItem('9.', 'Click "Authorize" to complete the payment');
  numberedItem('10.', 'The receipt will be generated automatically');
  spacer();

  subtitle('Important Notes:');
  bullet('Payment amount cannot exceed the outstanding balance');
  bullet('A 4-digit PIN is required for every payment (security feature)');
  bullet('Students with zero balance will not appear in the search results');
  bullet('The student\'s passport photo is displayed for visual verification');
  bullet('Recent transactions are shown on the right panel');
  spacer();
  line();

  // ==========================================
  // 8. PAYMENT PIN
  // ==========================================
  addPage();
  title('8. PAYMENT PIN SECURITY');
  spacer();
  body('Every payment requires a 4-digit PIN for authorization. This prevents unauthorized transactions.');
  spacer();

  subtitle('Default PIN:');
  body('The default payment PIN is set by the administrator. Contact the admin for the PIN.');
  spacer();

  subtitle('Changing the PIN:');
  numberedItem('1.', 'Go to Settings');
  numberedItem('2.', 'Scroll to "Account & Security" section');
  numberedItem('3.', 'Click "Update" on "Change Payment PIN"');
  numberedItem('4.', 'Enter your current LOGIN PASSWORD (not the old PIN)');
  numberedItem('5.', 'Enter your new 4-digit PIN');
  numberedItem('6.', 'Confirm the new PIN');
  numberedItem('7.', 'Click "Update PIN"');
  spacer();

  subtitle('PIN Security Features:');
  bullet('PIN must be exactly 4 digits (numbers only)');
  bullet('Maximum 5 failed attempts before lockout');
  bullet('Cannot change PIN without entering your login password');
  bullet('All PIN changes are logged with timestamps');
  bullet('Contact admin at 0703 856 2100 for PIN recovery');
  spacer();
  line();

  // ==========================================
  // 9. PAYMENT HISTORY
  // ==========================================
  addPage();
  title('9. PAYMENT HISTORY & REPRINT');
  spacer();
  body('The History section allows you to search all payment records and reprint receipts.');
  spacer();

  subtitle('Searching Payment Records:');
  numberedItem('1.', 'Navigate to "History" from the menu');
  numberedItem('2.', 'Type in the search box to find by student name, admission number, phone, or receipt ID');
  numberedItem('3.', 'Use filters: Class, Term, Date From, Date To');
  numberedItem('4.', 'Sort by Date, Name, or Amount');
  spacer();

  subtitle('Reprinting a Receipt:');
  numberedItem('1.', 'Find the payment record');
  numberedItem('2.', 'Click the "Reprint" button');
  numberedItem('3.', 'The receipt modal will open');
  numberedItem('4.', 'Choose: Print, Bluetooth Print, or Export PDF');
  spacer();

  subtitle('History Summary:');
  body('The summary bar shows total transactions, total amount, number of students, and fully paid count for the filtered results.');
  spacer();
  line();

  // ==========================================
  // 10. REPORTS
  // ==========================================
  addPage();
  title('10. REPORTS & EXPORTS');
  spacer();
  body('The Reports section provides financial reports and data export features.');
  spacer();

  subtitle('Unpaid Students Report:');
  body('Shows all students with outstanding balances, grouped by class. Click "Export CSV" to download the report.');
  spacer();

  subtitle('Today\'s Collection:');
  body('Shows all payments received today with student names, amounts, and times. Click "Export CSV" to download.');
  spacer();

  subtitle('Export Student Names by Class:');
  numberedItem('1.', 'Click "Show Options" in the Export section');
  numberedItem('2.', 'Select the classes you want to export (click each class box)');
  numberedItem('3.', 'Preview the list of students');
  numberedItem('4.', 'Click "Export Student Names to CSV"');
  numberedItem('5.', 'The CSV file will download with S/N, Name, Class, and Admission Number');
  spacer();
  line();

  // ==========================================
  // 11. BULK SMS
  // ==========================================
  addPage();
  title('11. BULK SMS TO PARENTS');
  spacer();
  body('Send payment reminder SMS messages to parents of students with outstanding fees.');
  spacer();

  subtitle('How to Send Bulk SMS:');
  numberedItem('1.', 'Go to Reports');
  numberedItem('2.', 'Click "Send SMS to Unpaid Students" button');
  numberedItem('3.', 'Select the payment deadline date using the calendar');
  numberedItem('4.', 'Review the SMS messages');
  numberedItem('5.', 'Click "Send SMS to This Parent" for each message');
  numberedItem('6.', 'The SMS app will open with the pre-filled message');
  numberedItem('7.', 'Send the message from your phone\'s SMS app');
  spacer();

  subtitle('SMS Message Content:');
  body('Each SMS includes: Student name, Class, Term, Total fees, Outstanding balance, Payment deadline, and School name.');
  spacer();

  subtitle('Additional Options:');
  bullet('Copy message to clipboard for manual sending');
  bullet('Download all messages as a text file');
  bullet('Restart to send again');
  bullet('Update all messages with a new deadline date');
  spacer();
  line();

  // ==========================================
  // 12. RECEIPT MANAGEMENT
  // ==========================================
  addPage();
  title('12. RECEIPT MANAGEMENT');
  spacer();
  body('Receipts are generated automatically after each payment and can be reprinted from the History section.');
  spacer();

  subtitle('Receipt Contents:');
  bullet('School logo (centered at top)');
  bullet('School name and address');
  bullet('Receipt number, date, and time');
  bullet('Student name, class, term, and admission number');
  bullet('Total fee, amount paid, and balance');
  bullet('Authorized digital signature');
  spacer();

  subtitle('Receipt Options:');
  bullet('Print - Opens browser print dialog for physical printing');
  bullet('Bluetooth Print - Sends receipt to connected Bluetooth thermal printer');
  bullet('Export PDF - Downloads receipt as a PDF file');
  spacer();

  subtitle('Customizing Receipts (Settings):');
  bullet('Upload school logo');
  bullet('Set school name and address');
  bullet('Draw digital signature');
  bullet('Adjust receipt font size (10px to 20px)');
  spacer();
  line();

  // ==========================================
  // 13. CLASS PROMOTION
  // ==========================================
  addPage();
  title('13. CLASS PROMOTION & GRADUATION');
  spacer();
  body('At the end of each academic session, promote students to the next class automatically.');
  spacer();

  subtitle('Promotion Flow:');
  bullet('Nursery 1 → Nursery 2 → Nursery 3 → Primary 1');
  bullet('Primary 1 → 2 → 3 → 4 → 5 → 6 → JSS1');
  bullet('JSS1 → JSS2 → JSS3 → SS1');
  bullet('SS1 → SS2 → SS3 → Graduate List');
  spacer();

  subtitle('How to Promote Students (Admin Only):');
  numberedItem('1.', 'Go to Settings');
  numberedItem('2.', 'Scroll to "Class Promotion & Graduation"');
  numberedItem('3.', 'Select the classes to promote (click each class box or "Select All")');
  numberedItem('4.', 'Click "Preview Promotion"');
  numberedItem('5.', 'Review the changes (shows From → To for each student)');
  numberedItem('6.', 'Click "Confirm Promotion"');
  spacer();

  subtitle('Graduate Folders:');
  body('SS3 students are moved to the Graduate list, automatically organized in folders named by academic session (e.g., "2026/2027 Graduate"). Each folder can be:');
  bullet('Expanded/collapsed to view students');
  bullet('Exported to CSV');
  bullet('Students can be restored back to class');
  bullet('Students can be permanently deleted');
  spacer();
  line();

  // ==========================================
  // 14. SETTINGS
  // ==========================================
  addPage();
  title('14. SETTINGS & CONFIGURATION');
  spacer();
  body('The Settings page contains all configuration options for the system.');
  spacer();

  subtitle('School Information:');
  bullet('School Name - Appears on dashboard and receipts');
  bullet('School Address - Appears on receipts');
  spacer();

  subtitle('School Logo:');
  bullet('Upload a logo image (PNG recommended)');
  bullet('Logo appears centered at the top of receipts');
  spacer();

  subtitle('Digital Signature:');
  bullet('Draw your signature using touch (mobile) or mouse (desktop)');
  bullet('Signature appears on all receipts');
  spacer();

  subtitle('Receipt Font Size:');
  bullet('Adjust the slider from 10px (small) to 20px (large)');
  bullet('All receipt text is bold for clear printing');
  spacer();

  subtitle('Data Management:');
  bullet('"Reset All Data" - Clears all data (students, payments, settings). Use with caution!');
  spacer();
  line();

  // ==========================================
  // 15. USER MANAGEMENT
  // ==========================================
  addPage();
  title('15. USER MANAGEMENT');
  spacer();
  body('Administrators can create and manage user accounts in Settings.');
  spacer();

  subtitle('Adding a New User (Admin Only):');
  numberedItem('1.', 'Go to Settings → User Management section');
  numberedItem('2.', 'Click "Add User"');
  numberedItem('3.', 'Enter: Full Name, Username, Password, Role, Email, Phone');
  numberedItem('4.', 'Select role: Admin, Staff, or Accountant');
  numberedItem('5.', 'Click "Create"');
  spacer();

  subtitle('Managing Users:');
  bullet('Edit - Update user information');
  bullet('Activate/Deactivate - Toggle user status');
  bullet('Delete - Remove user (cannot delete default admin)');
  bullet('Search - Find users by name, username, or email');
  spacer();
  line();

  // ==========================================
  // 16. ACCOUNT SECURITY
  // ==========================================
  title('16. ACCOUNT SECURITY');
  spacer();

  subtitle('Changing Your Password:');
  numberedItem('1.', 'Go to Settings → Account & Security');
  numberedItem('2.', 'Click "Update" on Change Password');
  numberedItem('3.', 'Enter current password, new password, and confirm');
  numberedItem('4.', 'Click "Update Password"');
  spacer();

  subtitle('Changing Payment PIN:');
  numberedItem('1.', 'Go to Settings → Account & Security');
  numberedItem('2.', 'Click "Update" on Change Payment PIN');
  numberedItem('3.', 'Enter your login password for verification');
  numberedItem('4.', 'Enter new 4-digit PIN and confirm');
  numberedItem('5.', 'Click "Update PIN"');
  spacer();
  line();

  // ==========================================
  // 17-18. DIGITAL SIGNATURE & BLUETOOTH
  // ==========================================
  addPage();
  title('17. DIGITAL SIGNATURE');
  spacer();
  subtitle('Drawing Your Signature:');
  numberedItem('1.', 'Go to Settings → Digital Signature section');
  numberedItem('2.', 'Click "Draw Signature"');
  numberedItem('3.', 'Use your finger (mobile) or mouse (desktop) to sign');
  numberedItem('4.', 'Click "Clear" to start over, or "Save Signature" to keep it');
  numberedItem('5.', 'Click "Save Settings" to apply');
  spacer();
  line();

  title('18. BLUETOOTH PRINTING');
  spacer();
  body('Connect to a Bluetooth thermal printer for mobile receipt printing.');
  spacer();
  subtitle('How to Connect:');
  numberedItem('1.', 'Click the Bluetooth button (bottom-right corner of screen)');
  numberedItem('2.', 'Select your printer from the device list');
  numberedItem('3.', 'Once connected, the button turns green');
  numberedItem('4.', 'When viewing a receipt, click "Bluetooth Print"');
  spacer();
  body('Note: Bluetooth printing requires Chrome browser on Android or Desktop.');
  spacer();
  line();

  // ==========================================
  // 19-20. PWA & OFFLINE
  // ==========================================
  addPage();
  title('19. INSTALL AS APP (PWA)');
  spacer();
  body('SchoolFees Pro can be installed on your phone or computer as a standalone app.');
  spacer();

  subtitle('On Android (Chrome):');
  numberedItem('1.', 'Open the app in Chrome browser');
  numberedItem('2.', 'Tap the menu (three dots) → "Install app" or "Add to Home Screen"');
  numberedItem('3.', 'The app icon will appear on your home screen');
  spacer();

  subtitle('On iPhone/iPad (Safari):');
  numberedItem('1.', 'Open the app in Safari');
  numberedItem('2.', 'Tap the Share button');
  numberedItem('3.', 'Tap "Add to Home Screen"');
  numberedItem('4.', 'Tap "Add"');
  spacer();

  subtitle('On Desktop (Chrome/Edge):');
  numberedItem('1.', 'Open the app in Chrome or Edge');
  numberedItem('2.', 'Click the install icon in the address bar');
  numberedItem('3.', 'Click "Install"');
  spacer();
  line();

  title('20. OFFLINE MODE');
  spacer();
  body('SchoolFees Pro works completely offline after the first visit. All data is stored locally on your device using localStorage. Features that work offline:');
  spacer();
  bullet('Login and authentication');
  bullet('Adding and editing students');
  bullet('Recording payments and generating receipts');
  bullet('Viewing reports and history');
  bullet('All settings and configuration');
  bullet('Digital signature');
  bullet('PDF export');
  spacer();
  body('SMS sending and Bluetooth printing require network/Bluetooth connectivity.');
  spacer();
  line();

  // ==========================================
  // 21. TROUBLESHOOTING
  // ==========================================
  addPage();
  title('21. TROUBLESHOOTING');
  spacer();

  subtitle('Problem: Cannot login');
  body('Solution: Verify your username and password. If forgotten, contact admin at 0703 856 2100 for reset.');
  spacer();

  subtitle('Problem: Payment PIN not working');
  body('Solution: After 5 failed attempts, the PIN is locked. Contact admin to reset. Make sure you enter exactly 4 digits.');
  spacer();

  subtitle('Problem: Camera not working');
  body('Solution: Ensure camera permissions are granted in your browser settings. Try switching between front and back cameras.');
  spacer();

  subtitle('Problem: Receipt not printing');
  body('Solution: For browser printing, ensure your printer is connected. For Bluetooth, make sure the printer is paired and the Bluetooth button shows green.');
  spacer();

  subtitle('Problem: Data disappeared');
  body('Solution: Data is stored in your browser\'s localStorage. Clearing browser data or cache will delete the data. Avoid using "Reset All Data" in settings unless intended.');
  spacer();

  subtitle('Problem: App not loading offline');
  body('Solution: The app must be loaded online at least once for caching. After that, it works offline. Try refreshing the page.');
  spacer();
  line();

  // ==========================================
  // 22. CONTACT & SUPPORT
  // ==========================================
  title('22. CONTACT & SUPPORT');
  spacer();

  doc.setFillColor(240, 245, 255);
  doc.roundedRect(margin, y, contentWidth, 60, 3, 3, 'F');
  y += 8;

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Kida Digital Solutions Centre', margin + 10, y);
  y += 7;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(75, 85, 99);
  doc.text('Developer: Abdullah Hashimu Kida (Managing Director)', margin + 10, y); y += 6;
  doc.text('Phone: 0703 856 2100', margin + 10, y); y += 6;
  doc.text('Email: support@kidadigital.com', margin + 10, y); y += 6;
  doc.text('Website: www.kidadigital.com', margin + 10, y); y += 6;
  doc.text('Address: Besides Kida Primary School, Hawul L.G.A, Borno State', margin + 10, y); y += 6;

  y += 15;
  subtitle('Services Offered:');
  bullet('School Management Systems');
  bullet('Student Report Sheet Generators');
  bullet('Digital Result Processing');
  bullet('ICT Training for Schools');
  bullet('Custom Software Development');
  spacer(10);

  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text('© 2026 Kida Digital Solutions Centre. All rights reserved.', pageWidth / 2, y + 5, { align: 'center' });
  doc.text('Version 1.0 | Last Updated: April 4, 2026', pageWidth / 2, y + 10, { align: 'center' });

  // Add page numbers
  pageFooter();

  // Save
  doc.save('SchoolFees_Pro_User_Manual.pdf');
}
