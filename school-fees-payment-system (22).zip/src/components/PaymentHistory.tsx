import { useState, useMemo } from 'react';

interface Student {
  id: number;
  name: string;
  class: string;
  admissionNumber: string;
  term: string;
  totalFee: number;
  parentPhone: string;
}

interface Payment {
  id: number;
  studentId: number;
  term: string;
  amountPaid: number;
  totalFee: number;
  balance: number;
  date: string;
}

interface PaymentHistoryProps {
  students: Student[];
  payments: Payment[];
  onReprintReceipt: (payment: Payment) => void;
}

export default function PaymentHistory({ students, payments, onReprintReceipt }: PaymentHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [filterTerm, setFilterTerm] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'name' | 'amount'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const CLASS_OPTIONS = [
    'Nursery 1', 'Nursery 2', 'Nursery 3',
    'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6',
    'JSS1', 'JSS2', 'JSS3',
    'SS1', 'SS2', 'SS3'
  ];

  const filteredPayments = useMemo(() => {
    let result = payments.map(payment => {
      const student = students.find(s => s.id === payment.studentId);
      return { ...payment, student };
    });

    // Search filter
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      result = result.filter(p => 
        p.student?.name.toLowerCase().includes(search) ||
        p.student?.admissionNumber.toLowerCase().includes(search) ||
        p.student?.parentPhone.includes(search) ||
        p.id.toString().includes(search)
      );
    }

    // Class filter
    if (filterClass) {
      result = result.filter(p => p.student?.class === filterClass);
    }

    // Term filter
    if (filterTerm) {
      result = result.filter(p => p.term === filterTerm);
    }

    // Date range filter
    if (filterDateFrom) {
      const from = new Date(filterDateFrom);
      from.setHours(0, 0, 0, 0);
      result = result.filter(p => new Date(p.date) >= from);
    }
    if (filterDateTo) {
      const to = new Date(filterDateTo);
      to.setHours(23, 59, 59, 999);
      result = result.filter(p => new Date(p.date) <= to);
    }

    // Sort
    result.sort((a, b) => {
      let compare = 0;
      switch (sortBy) {
        case 'date':
          compare = new Date(a.date).getTime() - new Date(b.date).getTime();
          break;
        case 'name':
          compare = (a.student?.name || '').localeCompare(b.student?.name || '');
          break;
        case 'amount':
          compare = a.amountPaid - b.amountPaid;
          break;
      }
      return sortOrder === 'desc' ? -compare : compare;
    });

    return result;
  }, [payments, students, searchTerm, filterClass, filterTerm, filterDateFrom, filterDateTo, sortBy, sortOrder]);

  const totalFiltered = filteredPayments.reduce((sum, p) => sum + p.amountPaid, 0);

  const clearFilters = () => {
    setSearchTerm('');
    setFilterClass('');
    setFilterTerm('');
    setFilterDateFrom('');
    setFilterDateTo('');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">
            <i className="fas fa-history text-blue-600 mr-2"></i>
            Payment History
          </h2>
          <p className="text-gray-600 text-sm">Search and reprint receipts for paid students</p>
        </div>
        <div className="bg-blue-600 text-white px-4 py-2 rounded-lg">
          <span className="text-sm font-medium">{filteredPayments.length} Records</span>
        </div>
      </div>

      {/* Search Box */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <input
              type="text"
              placeholder="Search by student name, admission number, phone, or receipt ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-lg"
              autoFocus
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <i className="fas fa-times"></i>
              </button>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <select
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm"
          >
            <option value="">All Classes</option>
            {CLASS_OPTIONS.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select
            value={filterTerm}
            onChange={(e) => setFilterTerm(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm"
          >
            <option value="">All Terms</option>
            <option value="1st">1st Term</option>
            <option value="2nd">2nd Term</option>
            <option value="3rd">3rd Term</option>
          </select>
          <input
            type="date"
            value={filterDateFrom}
            onChange={(e) => setFilterDateFrom(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm"
            placeholder="From Date"
          />
          <input
            type="date"
            value={filterDateTo}
            onChange={(e) => setFilterDateTo(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm"
            placeholder="To Date"
          />
          <button
            onClick={clearFilters}
            className="bg-gray-200 text-gray-700 rounded-lg px-3 py-2 text-sm hover:bg-gray-300"
          >
            <i className="fas fa-times mr-1"></i>Clear
          </button>
        </div>

        {/* Sort Options */}
        <div className="flex items-center space-x-3 mt-3 text-sm">
          <span className="text-gray-600 font-medium">Sort by:</span>
          <button
            onClick={() => { setSortBy('date'); setSortOrder(sortBy === 'date' && sortOrder === 'desc' ? 'asc' : 'desc'); }}
            className={`px-3 py-1 rounded-full ${sortBy === 'date' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            <i className="fas fa-calendar mr-1"></i>Date
            {sortBy === 'date' && <i className={`fas fa-arrow-${sortOrder === 'desc' ? 'down' : 'up'} ml-1`}></i>}
          </button>
          <button
            onClick={() => { setSortBy('name'); setSortOrder(sortBy === 'name' && sortOrder === 'asc' ? 'desc' : 'asc'); }}
            className={`px-3 py-1 rounded-full ${sortBy === 'name' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            <i className="fas fa-user mr-1"></i>Name
            {sortBy === 'name' && <i className={`fas fa-arrow-${sortOrder === 'desc' ? 'down' : 'up'} ml-1`}></i>}
          </button>
          <button
            onClick={() => { setSortBy('amount'); setSortOrder(sortBy === 'amount' && sortOrder === 'desc' ? 'asc' : 'desc'); }}
            className={`px-3 py-1 rounded-full ${sortBy === 'amount' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            <i className="fas fa-money-bill mr-1"></i>Amount
            {sortBy === 'amount' && <i className={`fas fa-arrow-${sortOrder === 'desc' ? 'down' : 'up'} ml-1`}></i>}
          </button>
        </div>
      </div>

      {/* Summary Card */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg shadow-md p-4 text-white">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-3xl font-bold">{filteredPayments.length}</p>
            <p className="text-sm text-blue-100">Transactions</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold">₦{totalFiltered.toLocaleString()}</p>
            <p className="text-sm text-blue-100">Total Amount</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold">{new Set(filteredPayments.map(p => p.studentId)).size}</p>
            <p className="text-sm text-blue-100">Students</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold">{filteredPayments.filter(p => p.balance === 0).length}</p>
            <p className="text-sm text-blue-100">Fully Paid</p>
          </div>
        </div>
      </div>

      {/* Payment Records */}
      <div className="space-y-3">
        {filteredPayments.map(payment => {
          const student = payment.student;
          return (
            <div
              key={payment.id}
              className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow border-l-4 border-blue-600"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                {/* Student Info */}
                <div className="flex items-center space-x-3 flex-1">
                  <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center">
                    <i className="fas fa-user-graduate text-blue-600 text-lg"></i>
                  </div>
                  <div>
                    <p className="font-bold text-gray-800 text-lg">{student?.name || 'Unknown'}</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs font-medium">
                        {student?.class}
                      </span>
                      <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs font-medium">
                        {payment.term} Term
                      </span>
                      <span className="bg-gray-100 text-gray-800 px-2 py-0.5 rounded text-xs font-medium">
                        {student?.admissionNumber}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Payment Info */}
                <div className="flex items-center space-x-6">
                  <div className="text-right">
                    <p className="text-xl font-bold text-green-600">₦{payment.amountPaid.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(payment.date).toLocaleDateString()} • {new Date(payment.date).toLocaleTimeString()}
                    </p>
                    <p className={`text-xs font-medium ${payment.balance === 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {payment.balance === 0 ? '✓ Fully Paid' : `Balance: ₦${payment.balance.toLocaleString()}`}
                    </p>
                  </div>

                  {/* Receipt ID */}
                  <div className="text-center">
                    <p className="text-xs text-gray-500">Receipt</p>
                    <p className="font-mono font-bold text-gray-700">#{payment.id.toString().padStart(6, '0')}</p>
                  </div>

                  {/* Reprint Button */}
                  <button
                    onClick={() => onReprintReceipt(payment)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-5 py-3 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-md flex items-center space-x-2"
                  >
                    <i className="fas fa-print"></i>
                    <span className="font-medium">Reprint</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredPayments.length === 0 && (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <i className="fas fa-search text-6xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-bold text-gray-700 mb-2">No Records Found</h3>
          <p className="text-gray-500 mb-4">
            {searchTerm 
              ? `No payment records found for "${searchTerm}"`
              : 'No payment records match your filters'}
          </p>
          {(searchTerm || filterClass || filterTerm || filterDateFrom || filterDateTo) && (
            <button
              onClick={clearFilters}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
            >
              <i className="fas fa-times mr-2"></i>Clear All Filters
            </button>
          )}
        </div>
      )}
    </div>
  );
}
