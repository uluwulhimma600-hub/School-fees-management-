import jsPDF from 'jspdf';

// Fetch Amiri Arabic font and convert to base64
async function loadAmiriFont(): Promise<string> {
  const url = 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/amiri/Amiri-Regular.ttf';
  try {
    const response = await fetch(url);
    const buffer = await response.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  } catch {
    return '';
  }
}

export async function generateUserManualAr() {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  // Load Arabic font
  const fontBase64 = await loadAmiriFont();
  let hasArabicFont = false;

  if (fontBase64) {
    doc.addFileToVFS('Amiri-Regular.ttf', fontBase64);
    doc.addFont('Amiri-Regular.ttf', 'Amiri', 'normal');
    hasArabicFont = true;
  }

  const setArabic = (size: number = 12) => {
    if (hasArabicFont) {
      doc.setFont('Amiri', 'normal');
    } else {
      doc.setFont('helvetica', 'normal');
    }
    doc.setFontSize(size);
  };

  const setArabicBold = (size: number = 14) => {
    if (hasArabicFont) {
      doc.setFont('Amiri', 'normal');
    } else {
      doc.setFont('helvetica', 'bold');
    }
    doc.setFontSize(size);
  };

  const addPage = () => { doc.addPage(); y = 20; };
  const checkPage = (n: number) => { if (y + n > 270) addPage(); };
  const spacer = (h: number = 5) => { y += h; };
  const hr = () => { checkPage(5); doc.setDrawColor(200,200,200); doc.setLineWidth(0.5); doc.line(margin,y,pageWidth-margin,y); y+=5; };

  const arTitle = (text: string, size: number = 18) => {
    checkPage(15);
    setArabicBold(size);
    doc.setTextColor(37, 99, 235);
    doc.text(text, pageWidth - margin, y, { align: 'right' });
    y += size * 0.7;
  };

  const arSub = (text: string) => {
    checkPage(10);
    setArabicBold(13);
    doc.setTextColor(55, 65, 81);
    doc.text(text, pageWidth - margin, y, { align: 'right' });
    y += 8;
  };

  const arBody = (text: string) => {
    checkPage(8);
    setArabic(11);
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth);
    lines.forEach((line: string) => {
      checkPage(6);
      doc.text(line, pageWidth - margin, y, { align: 'right' });
      y += 6;
    });
  };

  const arBullet = (text: string) => {
    checkPage(8);
    setArabic(11);
    doc.setTextColor(75, 85, 99);
    doc.text('•', pageWidth - margin, y);
    const lines = doc.splitTextToSize(text, contentWidth - 10);
    lines.forEach((line: string, i: number) => {
      checkPage(6);
      doc.text(line, pageWidth - margin - (i === 0 ? 6 : 0), y, { align: 'right' });
      if (i < lines.length - 1) y += 6;
    });
    y += 6;
  };

  const arStep = (num: string, text: string) => {
    checkPage(8);
    setArabicBold(11);
    doc.setTextColor(37, 99, 235);
    doc.text(num, pageWidth - margin, y, { align: 'right' });
    setArabic(11);
    doc.setTextColor(75, 85, 99);
    doc.text(text, pageWidth - margin - 15, y, { align: 'right' });
    y += 6;
  };

  const pageFooter = () => {
    const total = doc.getNumberOfPages();
    for (let i = 1; i <= total; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(150, 150, 150);
      doc.text(`SchoolFees Pro | ${i} / ${total}`, pageWidth / 2, 290, { align: 'center' });
      doc.text('Kida Digital Solutions Centre | 0703 856 2100', pageWidth / 2, 295, { align: 'center' });
    }
  };

  // ==========================================
  // COVER PAGE
  // ==========================================
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 120, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(32);
  doc.setTextColor(255, 255, 255);
  doc.text('SchoolFees Pro', pageWidth / 2, 40, { align: 'center' });

  setArabic(16);
  doc.setTextColor(255, 255, 255);
  doc.text('نظام دفع رسوم المدرسة', pageWidth / 2, 58, { align: 'center' });

  setArabicBold(20);
  doc.text('دليل المستخدم', pageWidth / 2, 80, { align: 'center' });

  setArabic(12);
  doc.text('دليل كامل لمديري المدارس والموظفين', pageWidth / 2, 100, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Version 1.0 | April 2026', pageWidth / 2, 112, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(55, 65, 81);
  doc.setFont('helvetica', 'bold');
  doc.text('Kida Digital Solutions Centre', pageWidth / 2, 155, { align: 'center' });

  setArabic(11);
  doc.setTextColor(75, 85, 99);
  doc.text('تطوير البرمجيات وخدمات تكنولوجيا المعلومات', pageWidth / 2, 168, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Hawul L.G.A, Borno State, Nigeria', pageWidth / 2, 180, { align: 'center' });
  doc.text('0703 856 2100 | support@kidadigital.com', pageWidth / 2, 190, { align: 'center' });

  // ==========================================
  // INTRODUCTION
  // ==========================================
  addPage();
  arTitle('المقدمة');
  spacer();
  arBody('برنامج SchoolFees Pro هو نظام حديث وشامل لإدارة دفع رسوم المدرسة. تم تصميمه خصيصاً للمدارس في نيجيريا. يساعد المدارس في تسجيل بيانات الطلاب، قبول الرسوم، طباعة الإيصالات، تتبع المدفوعات، وإرسال رسائل للأولياء.');
  spacer();
  arSub('الميزات الرئيسية:');
  arBullet('إدارة بيانات الطلاب مع صور جواز السفر');
  arBullet('إعداد الرسوم لكل صف وفصل دراسي');
  arBullet('تسجيل الدفع برقم أمان من ٤ أرقام');
  arBullet('إنشاء إيصالات احترافية وطباعتها');
  arBullet('دعم طابعة بلوتوث للطباعة المتنقلة');
  arBullet('تصدير الإيصالات كملف PDF');
  arBullet('إرسال رسائل جماعية للأولياء');
  arBullet('ترقية الصف وإدارة التخرج');
  arBullet('إدارة المستخدمين بأدوار مختلفة');
  arBullet('يعمل بدون إنترنت بالكامل');
  arBullet('توقيع رقمي للإيصالات');
  arBullet('تصدير بيانات الطلاب إلى CSV');
  spacer(); hr();

  // ==========================================
  // ADVANTAGES
  // ==========================================
  addPage();
  doc.setFillColor(220, 252, 231);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  setArabicBold(13);
  doc.setTextColor(22, 101, 52);
  doc.text('فوائد نظام الدفع الرقمي', pageWidth - margin - 5, y + 8, { align: 'right' });
  y += 20;

  arSub('١. الدقة وعدم الأخطاء');
  arBody('النظام الرقمي يحسب الرسوم والأرصدة والمجاميع تلقائياً بدون أخطاء حسابية.');
  spacer();
  arSub('٢. تقارير مالية فورية');
  arBody('يمكن للمديرين مشاهدة مجموع المحصولات والإيرادات والأرصدة المتبقية فوراً.');
  spacer();
  arSub('٣. توفير الوقت');
  arBody('ما يأخذ ساعات في النظام اليدوي - كتابة الإيصالات والبحث والحساب - يتم في ثوانٍ.');
  spacer();
  arSub('٤. الأمان والحماية');
  arBody('لا يمكن تعديل السجلات الرقمية بدون تصريح. رقم PIN وتسجيل الدخول يضمنان الأمان.');
  spacer();
  arSub('٥. إنشاء إيصالات فوري');
  arBody('يتم إنشاء إيصالات احترافية تلقائياً مع شعار المدرسة والتوقيع.');
  spacer();
  arSub('٦. سهولة البحث');
  arBody('اعثر على تاريخ دفع أي طالب في ثوانٍ عن طريق البحث باسمه.');
  spacer();
  arSub('٧. التواصل مع الأولياء');
  arBody('إرسال رسائل تذكير جماعية للأولياء الذين عليهم متأخرات.');
  spacer();
  arSub('٨. يعمل بدون إنترنت');
  arBody('يعمل بالكامل بدون إنترنت بعد التثبيت.');
  spacer();
  arSub('٩. حفظ البيانات بأمان');
  arBody('جميع البيانات محفوظة في الجهاز. لا خطر لفقدان السجلات.');
  spacer();
  arSub('١٠. ترقية الصف تلقائياً');
  arBody('في نهاية العام، اضغط زر واحد لترقية جميع الطلاب. طلاب SS3 ينتقلون لقائمة الخريجين.');
  spacer();

  // ==========================================
  // DISADVANTAGES
  // ==========================================
  addPage();
  doc.setFillColor(254, 226, 226);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  setArabicBold(13);
  doc.setTextColor(153, 27, 27);
  doc.text('عيوب نظام الدفع اليدوي', pageWidth - margin - 5, y + 8, { align: 'right' });
  y += 20;

  arSub('١. أخطاء حسابية');
  arBody('الحسابات اليدوية للرسوم والأرصدة معرضة للأخطاء. خطأ واحد قد يسبب مشاكل.');
  spacer();
  arSub('٢. استهلاك الوقت');
  arBody('كتابة الإيصالات باليد والبحث في الدفاتر وحساب الأرصدة يستهلك وقتاً كثيراً.');
  spacer();
  arSub('٣. سهولة التلاعب');
  arBody('يمكن تعديل السجلات الورقية أو تدميرها بسهولة.');
  spacer();
  arSub('٤. فقدان السجلات');
  arBody('كتب الإيصالات يمكن أن تضيع أو تتلف بالماء أو تحترق. إذا فقدت، ذهبت للأبد.');
  spacer();
  arSub('٥. لا تقارير فورية');
  arBody('للحصول على ملخص مالي، يجب العد عبر جميع الدفاتر. تقارير نهاية الفصل تستغرق أياماً.');
  spacer();
  arSub('٦. صعوبة البحث');
  arBody('لإيجاد سجل دفع طالب، يجب تقليب الصفحات واحدة بعد الأخرى.');
  spacer();
  arSub('٧. لا تواصل مع الأولياء');
  arBody('لا توجد طريقة فعالة لتذكير الأولياء بالمتأخرات.');
  spacer();
  arSub('٨. مشكلة نسخ الإيصالات');
  arBody('يمكن إنشاء إيصالات مزورة بسهولة.');
  spacer();
  arSub('٩. مشاكل التخزين');
  arBody('دفاتر الإيصالات لسنوات عديدة تشغل مساحة تخزين كبيرة.');
  spacer();
  arSub('١٠. مظهر غير احترافي');
  arBody('الإيصالات المكتوبة باليد لا تبدو احترافية.');
  spacer();

  // ==========================================
  // CHAPTERS
  // ==========================================
  addPage();
  arTitle('تسجيل الدخول');
  spacer();
  arBody('عندما تفتح التطبيق لأول مرة، ستظهر صفحة تسجيل الدخول.');
  spacer();
  arSub('كيفية تسجيل الدخول:');
  arStep('١.', 'افتح التطبيق في متصفح الويب');
  arStep('٢.', 'أدخل اسم المستخدم في حقل Username');
  arStep('٣.', 'أدخل كلمة المرور في حقل Password');
  arStep('٤.', 'اختيارياً، حدد Remember me');
  arStep('٥.', 'اضغط Sign In');
  spacer();
  arSub('أنواع المستخدمين:');
  arBullet('مدير (Admin) - وصول كامل لجميع الميزات');
  arBullet('محاسب (Accountant) - وصول للمدفوعات والتقارير');
  arBullet('موظف (Staff) - وصول أساسي للطلاب والدفع');
  spacer(); hr();

  arTitle('إدارة الطلاب');
  spacer();
  arSub('إضافة طالب جديد:');
  arStep('١.', 'انتقل إلى Students من القائمة');
  arStep('٢.', 'اضغط زر Add Student');
  arStep('٣.', 'ارفع أو التقط صورة جواز بالكاميرا');
  arStep('٤.', 'أدخل الاسم الكامل للطالب');
  arStep('٥.', 'اختر الصف والفصل الدراسي');
  arStep('٦.', 'الرسوم تملأ تلقائياً');
  arStep('٧.', 'أدخل رقم هاتف الوالد');
  arStep('٨.', 'اضغط Add Student للحفظ');
  spacer(); hr();

  addPage();
  arTitle('تسجيل الدفع');
  spacer();
  arStep('١.', 'انتقل إلى Payments');
  arStep('٢.', 'اكتب اسم الطالب في مربع البحث');
  arStep('٣.', 'اختر الطالب (تظهر الصورة والرصيد)');
  arStep('٤.', 'أدخل المبلغ المدفوع');
  arStep('٥.', 'اضغط Record Payment');
  arStep('٦.', 'أدخل رقم PIN (٤ أرقام)');
  arStep('٧.', 'اضغط Authorize لإكمال الدفع');
  arStep('٨.', 'يتم إنشاء الإيصال تلقائياً');
  spacer(); hr();

  arTitle('رقم أمان الدفع (PIN)');
  spacer();
  arBody('كل دفع يتطلب رقم أمان من ٤ أرقام. هذا يمنع المعاملات غير المصرح بها.');
  arBullet('يجب أن يكون ٤ أرقام بالضبط');
  arBullet('بعد ٥ محاولات فاشلة، يتم القفل');
  arBullet('لا يمكن تغيير PIN بدون كلمة المرور');
  arBullet('اتصل بالمدير على 0703 856 2100 للمساعدة');
  spacer(); hr();

  addPage();
  arTitle('التقارير والتصدير');
  spacer();
  arBullet('الطلاب غير المسددين - يظهر جميع الطلاب الذين عليهم متأخرات');
  arBullet('تحصيلات اليوم - يظهر جميع المدفوعات اليوم');
  arBullet('تصدير أسماء الطلاب - اختر الصف ثم صدّر CSV');
  spacer(); hr();

  arTitle('إرسال SMS للأولياء');
  spacer();
  arStep('١.', 'انتقل إلى Reports');
  arStep('٢.', 'اضغط Send SMS to Unpaid Students');
  arStep('٣.', 'اختر تاريخ الموعد النهائي');
  arStep('٤.', 'اضغط Send SMS لكل والد');
  spacer(); hr();

  arTitle('ترقية الصف والتخرج');
  spacer();
  arStep('١.', 'انتقل إلى Settings > Class Promotion');
  arStep('٢.', 'اختر الصفوف للترقية');
  arStep('٣.', 'اضغط Preview Promotion');
  arStep('٤.', 'اضغط Confirm Promotion');
  spacer();
  arBody('طلاب SS3 ينتقلون إلى مجلد الخريجين تلقائياً (مثال: "2026/2027 Graduate").');
  spacer(); hr();

  addPage();
  arTitle('الإعدادات');
  spacer();
  arBullet('اسم المدرسة والعنوان');
  arBullet('شعار المدرسة');
  arBullet('التوقيع الرقمي');
  arBullet('حجم خط الإيصال');
  arBullet('هيكل الرسوم لكل صف');
  arBullet('إدارة المستخدمين');
  arBullet('أمن الحساب - تغيير كلمة المرور و PIN');
  spacer(); hr();

  arTitle('تثبيت التطبيق والعمل بدون إنترنت');
  spacer();
  arSub('على أندرويد:');
  arBody('افتح في Chrome > القائمة > Install app');
  arSub('على آيفون:');
  arBody('افتح في Safari > مشاركة > Add to Home Screen');
  spacer();
  arSub('العمل بدون إنترنت:');
  arBody('بعد زيارة التطبيق لأول مرة، جميع الميزات تعمل بدون إنترنت. جميع البيانات محفوظة في جهازك.');
  spacer(); hr();

  // ==========================================
  // CONTACT
  // ==========================================
  arTitle('اتصل بنا');
  spacer();
  doc.setFillColor(240, 245, 255);
  doc.roundedRect(margin, y, contentWidth, 50, 3, 3, 'F');
  y += 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(37, 99, 235);
  doc.text('Kida Digital Solutions Centre', margin + 10, y); y += 8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(75, 85, 99);
  doc.text('Abdullah Hashimu Kida (Managing Director)', margin + 10, y); y += 6;
  doc.text('Phone: 0703 856 2100', margin + 10, y); y += 6;
  doc.text('Email: support@kidadigital.com', margin + 10, y); y += 6;
  doc.text('Hawul L.G.A, Borno State, Nigeria', margin + 10, y); y += 6;

  y += 15;
  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text('© 2026 Kida Digital Solutions Centre', pageWidth / 2, y, { align: 'center' });

  pageFooter();
  doc.save('SchoolFees_Pro_Daleel_Arabic.pdf');
}
