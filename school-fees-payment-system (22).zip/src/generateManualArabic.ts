import jsPDF from 'jspdf';

export function generateUserManualArabic() {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  const addPage = () => {
    doc.addPage();
    y = 20;
  };

  const checkPage = (needed: number) => {
    if (y + needed > 270) addPage();
  };

  const _title = (text: string, size: number = 16) => {
    checkPage(15);
    doc.setFontSize(size);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text(text, pageWidth - margin, y, { align: 'right' });
    y += size * 0.6;
  };
  void _title;

  const subtitle = (text: string) => {
    checkPage(12);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(55, 65, 81);
    doc.text(text, pageWidth - margin, y, { align: 'right' });
    y += 7;
  };

  const body = (text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, pageWidth - margin, y, { align: 'right' });
    y += lines.length * 5;
  };

  const bullet = (text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth - 8);
    doc.text(lines, pageWidth - margin - 8, y, { align: 'right' });
    doc.text('•', pageWidth - margin - 2, y);
    y += lines.length * 5;
  };

  const numberedItem = (num: string, text: string) => {
    checkPage(8);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text(num, pageWidth - margin, y, { align: 'right' });
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    const lines = doc.splitTextToSize(text, contentWidth - 12);
    doc.text(lines, pageWidth - margin - 12, y, { align: 'right' });
    y += lines.length * 5;
  };

  const spacer = (h: number = 5) => { y += h; };

  const line = () => {
    checkPage(5);
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 5;
  };

  // Since jsPDF has limited Arabic font support, we'll use
  // transliterated Arabic (Franco-Arabic) mixed with simple Arabic words
  // and English labels for clarity

  const pageFooter = () => {
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(150, 150, 150);
      doc.text(`SchoolFees Pro - Dalili Mai Amfani | Shafi ${i} na ${totalPages}`, pageWidth / 2, 290, { align: 'center' });
      doc.text('Kida Digital Solutions Centre | 0703 856 2100', pageWidth / 2, 295, { align: 'center' });
    }
  };

  // ==========================================
  // COVER PAGE
  // ==========================================
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 120, 'F');

  doc.setFontSize(32);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('SchoolFees Pro', pageWidth / 2, 40, { align: 'center' });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text('Tsarin Biyan Kudin Makaranta', pageWidth / 2, 55, { align: 'center' });

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('DALILI MAI AMFANI', pageWidth / 2, 78, { align: 'center' });
  doc.setFontSize(12);
  doc.text('(User Manual - Hausa Version)', pageWidth / 2, 88, { align: 'center' });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Cikakken Jagora don Masu Gudanar da Makaranta', pageWidth / 2, 102, { align: 'center' });
  doc.text('Version 1.0 | Afrilu 2026', pageWidth / 2, 112, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(55, 65, 81);
  doc.setFont('helvetica', 'bold');
  doc.text('Mai Kirkira:', pageWidth / 2, 145, { align: 'center' });

  doc.setFontSize(16);
  doc.setTextColor(37, 99, 235);
  doc.text('Kida Digital Solutions Centre', pageWidth / 2, 158, { align: 'center' });

  doc.setFontSize(10);
  doc.setTextColor(75, 85, 99);
  doc.setFont('helvetica', 'normal');
  doc.text('Harabar Software da Sabis na ICT', pageWidth / 2, 168, { align: 'center' });
  doc.text('Kusa da Makarantar Firamare ta Kida, Hawul L.G.A, Jihar Borno', pageWidth / 2, 178, { align: 'center' });
  doc.text('Waya: 0703 856 2100 | Email: support@kidadigital.com', pageWidth / 2, 188, { align: 'center' });
  doc.text('Website: www.kidadigital.com', pageWidth / 2, 198, { align: 'center' });

  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text('(c) 2026 Kida Digital Solutions Centre. Duk hakkin mallaka an kiyaye su.', pageWidth / 2, 275, { align: 'center' });

  // ==========================================
  // TABLE OF CONTENTS - ABIN DA KE CIKI
  // ==========================================
  addPage();
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('ABIN DA KE CIKI (Table of Contents)', margin, y);
  y += 15;

  const tocItems = [
    '1. Gabatarwa (Introduction) .............................. 3',
    '   >> Amfanin Tsarin Dijital ............................. 4',
    '   >> Matsalolin Tsarin Hannu ............................ 6',
    '   >> Kwatancen Dijital da Tsarin Hannu .................. 8',
    '2. Abubuwan da ake Bukata (Requirements) ................. 9',
    '3. Yadda ake Shiga (Login) ............................... 10',
    '4. Dashboard - Allon Gani ................................ 11',
    '5. Gudanar da Dalibai (Students) ......................... 12',
    '6. Tsarin Kudin Kowane Aji (Fee Structure) ............... 14',
    '7. Rubuta Biyan Kudi (Payments) .......................... 15',
    '8. Lambar Sirri ta Biya (Payment PIN) .................... 17',
    '9. Tarihin Biya da Sake Buga (History) ................... 18',
    '10. Rahotanni (Reports) .................................. 19',
    '11. Sako Zuwa Iyaye (Bulk SMS) ........................... 20',
    '12. Gudanar da Rasiti (Receipt) .......................... 21',
    '13. Habaka Aji da Kammala Karatu (Promotion) ............. 22',
    '14. Saituna (Settings) ................................... 23',
    '15. Gudanar da Masu Amfani (Users) ....................... 24',
    '16. Tsaron Asusu (Security) .............................. 25',
    '17. Sa Hannu na Dijital (Digital Signature) .............. 26',
    '18. Bugawa ta Bluetooth .................................. 26',
    '19. Shigar da App a Wayar (PWA) .......................... 27',
    '20. Aiki ba tare da Intanet ba (Offline) ................. 27',
    '21. Warware Matsaloli (Troubleshooting) .................. 28',
    '22. Tuntubar Mu (Contact) ................................ 29',
  ];

  tocItems.forEach(item => {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(55, 65, 81);
    doc.text(item, margin, y);
    y += 7;
  });

  // ==========================================
  // 1. GABATARWA
  // ==========================================
  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('1. GABATARWA (Introduction)', margin, y);
  y += 12;

  body('SchoolFees Pro wani tsari ne na zamani don gudanar da biyan kudin makaranta. An tsara shi musamman don makarantun Nijeriya. Yana taimakawa makarantu wajen rubuta bayanan dalibai, karbar kudi, buga rasiti, bin diddigin biya, da aika sako zuwa iyaye.');
  spacer();
  body('Manyan abubuwan da yake yi sun hada da:');
  bullet('Gudanar da bayanan dalibai tare da hoton fasfo');
  bullet('Saita kudin kowane aji da kowane zangon karatu');
  bullet('Rubuta biya tare da lambar sirri ta lambobi 4');
  bullet('Samar da rasiti na kwararru da bugawa');
  bullet('Goyon bayan na\'urar buga ta Bluetooth');
  bullet('Fitar da rasiti a matsayin PDF');
  bullet('Aika sako ga iyaye masu bashi');
  bullet('Habaka aji da gudanar da kammala karatu');
  bullet('Gudanar da masu amfani da ikon shiga daban-daban');
  bullet('Yana aiki ba tare da intanet ba (Offline)');
  bullet('Sa hannu na dijital don rasiti');
  bullet('Fitar da bayanan dalibai zuwa CSV');
  spacer();
  line();

  // ==========================================
  // ADVANTAGES - AMFANIN TSARIN DIJITAL
  // ==========================================
  addPage();

  doc.setFillColor(220, 252, 231);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('AMFANIN TSARIN BIYAN KUDI NA DIJITAL', margin + 5, y + 8);
  y += 18;

  subtitle('1. Daidaito da Rashin Kuskure');
  body('Tsarin dijital yana lissafa kudin karatu, ragowar kudi, da jimla ta atomatik ba tare da kuskuren lissafi ba. Kowane naira ana lissafa shi daidai.');
  spacer();

  subtitle('2. Rahotannin Kudi na Lokaci-Lokaci');
  body('Masu gudanarwa za su iya ganin yawan kudin da aka karba a yau, jimlar kudaden shiga, ragowar basuka, da rahotannin kowane aji nan take.');
  spacer();

  subtitle('3. Adana Lokaci');
  body('Abin da yake daukar sa\'o\'i a tsarin hannu - rubuta rasiti, binciken bayani, lissafin ragowar kudi - ana yi a cikin dakikoki kadan.');
  spacer();

  subtitle('4. Tsaro da Amincewar Bayani');
  body('Ba a iya canza bayanan dijital ba tare da izini ba. Lambar sirri ta PIN, shiga da sunan mai amfani, da rubuta kowane aiki suna tabbatar da tsaro.');
  spacer();

  subtitle('5. Samar da Rasiti nan take');
  body('Ana samar da rasiti na kwararru ta atomatik tare da alamar makaranta, sa hannu, da duk bayanan biya. Ana iya buga shi, fitar da shi a matsayin PDF, ko aika ta Bluetooth.');
  spacer();

  subtitle('6. Saukin Binciken Dalibai');
  body('Nemo tarihin biyan kudin kowane dalibai a cikin dakikoki ta hanyar neman sunansa. Sake buga kowane rasiti nan take.');
  spacer();

  subtitle('7. Sadarwa da Iyaye (SMS)');
  body('Aika sakonnin tunawa ga iyaye masu bashin kudin karatu, ciki har da sunan dalibai, aji, adadin da ake bin su, da ranar biya.');
  spacer();

  checkPage(40);
  subtitle('8. Aiki Ba tare da Intanet ba');
  body('Ba kamar tsarin kan layi da yawa ba, SchoolFees Pro yana aiki gaba daya ba tare da intanet ba bayan shigarwa. Ba a bukatar intanet don ayyukan yau da kullum.');
  spacer();

  subtitle('9. Adana Bayani da Aminci');
  body('Ana adana duk bayanan a cikin na\'ura. Babu hadarin rasa littattafan rasiti ta hanyar gobara, ruwa, ko sata.');
  spacer();

  subtitle('10. Habaka Aji ta Atomatik');
  body('A karshen zangon karatu, danna maballin daya don habaka duk dalibai zuwa aji na gaba. Daliban SS3 ana mayar da su cikin foldar masu kammala karatu.');
  spacer();

  subtitle('11. Masu Amfani da Yawa');
  body('Ma\'aikata da yawa za su iya amfani da tsarin tare da mukaman daban-daban (Admin, Accountant, Staff).');
  spacer();

  subtitle('12. Siffar Kwararru');
  body('Rasiti na dijital tare da alamar makaranta da sa hannu suna baiwa makarantarku siffar zamani da kwararru.');
  spacer();

  subtitle('13. Rahusa');
  body('Babu bukatar siyan littattafan rasiti masu tsada. Tsarin yana aiki a kowane waya ko kwamfuta da kuke da shi.');
  spacer();

  subtitle('14. Hoton Fasfo na Dalibai');
  body('Ana adana hoton fasfo na kowane dalibai a cikin tsarin, wanda ke saukaka ganewa.');
  spacer();

  subtitle('15. Fitar da Bayani');
  body('Fitar da jerin dalibai, bayanan biya, da rahotanni zuwa fayilolin CSV don bincike a Excel.');
  spacer();

  // ==========================================
  // DISADVANTAGES - MATSALOLIN TSARIN HANNU
  // ==========================================
  addPage();

  doc.setFillColor(254, 226, 226);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(153, 27, 27);
  doc.text('MATSALOLIN TSARIN BIYAN KUDI NA HANNU', margin + 5, y + 8);
  y += 18;

  subtitle('1. Kuskuren Lissafi');
  body('Lissafin hannu na kudaden karatu, ragowar kudi, da jimla suna da saukin yin kuskure. Kuskure guda daya zai iya haifar da rikici da yake daukar sa\'o\'i don gyarawa.');
  spacer();

  subtitle('2. Cin Lokaci');
  body('Rubuta rasiti da hannu, binciken littattafai, lissafin ragowar kudi, da tattara rahotanni suna cin lokaci mai yawa.');
  spacer();

  subtitle('3. Saukin Canza Bayani');
  body('Ana iya canza bayanan takarda ko hallaka su cikin sauki. Ma\'aikaci marar gaskiya zai iya canza bayani, wanda ke haifar da asarar kudi ga makarantar.');
  spacer();

  subtitle('4. Bacewar Bayani');
  body('Littattafan rasiti za su iya bacewa, lalacewa ta hanyar ruwa, konewa, ko lalata ta gara. Idan sun bace, bayanan sun tafi har abada.');
  spacer();

  subtitle('5. Rashin Rahotanni na Lokaci-Lokaci');
  body('Don samun takamaiman rahoton kudi, dole ne a kirga ta hanyar duk littattafan rasiti. Rahotannin karshen zangon karatu suna daukar kwanaki.');
  spacer();

  subtitle('6. Wahalar Bincike');
  body('Don nemo bayanan biyan kudin dalibai, dole ne a juya shafukan littattafan rasiti daya bayan daya.');
  spacer();

  subtitle('7. Rashin Sadarwa da Iyaye');
  body('Babu hanyar da ta dace don tunatar da iyaye game da bashin kudin karatu. Makarantu suna dogaro ne da wasikunan hannu ko sanarwar baki.');
  spacer();

  checkPage(40);
  subtitle('8. Matsalar Kwafi na Rasiti');
  body('Ana iya samar da rasiti na karya cikin sauki da tsarin hannu. Iyaye na iya gabatar da rasiti na karya a matsayin shaida.');
  spacer();

  subtitle('9. Matsalar Ajiya');
  body('Littattafan rasiti na shekaru da yawa suna cinye sararin ajiya. Shiryawa da tsara su babbar kalubale ce.');
  spacer();

  subtitle('10. Rashin Hoton Dalibai');
  body('Tsarin hannu ba kasafai yake dauke da hoton dalibai ba, wanda ke saukaka rudani na ganowa.');
  spacer();

  subtitle('11. Rashin Siffar Kwararru');
  body('Rasiti na hannu bai yi kyau ba kuma yana iya rasa muhimman bayanai. Wannan na iya shafar martabar makaranta.');
  spacer();

  subtitle('12. Tsadar Kayayyaki');
  body('Siyan littattafan rasiti, carbon paper, ledger, alqualam, da kayan shiryawa suna kara tsada a kowace lokaci.');
  spacer();

  subtitle('13. Rashin Sawun Bincike');
  body('Ba a iya bin sawun wanda ya rubuta wace biya, a yaushe, da ko an yi canje-canje ba.');
  spacer();

  subtitle('14. Wahalar Habaka Aji');
  body('Sabunta bayanan dalibai da hannu don habaka aji a karshen kowane zangon karatu yana da wahala kuma yana daukar lokaci.');
  spacer();

  subtitle('15. Dogaro da Mutum Daya');
  body('Idan mutumin da ke kula da littattafan rasiti ya yi rashin lafiya, ko ya bar makaranta, duk tsarin biyan kudi yana tsayawa.');
  spacer();

  // ==========================================
  // COMPARISON TABLE
  // ==========================================
  addPage();

  doc.setFillColor(219, 234, 254);
  doc.roundedRect(margin, y, contentWidth, 12, 3, 3, 'F');
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('KWATANCEN: DIJITAL da TSARIN HANNU', margin + 5, y + 8);
  y += 20;

  doc.setFillColor(37, 99, 235);
  doc.rect(margin, y, contentWidth, 8, 'F');
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('Abu', margin + 3, y + 6);
  doc.text('Dijital (SchoolFees Pro)', margin + 50, y + 6);
  doc.text('Tsarin Hannu', margin + 130, y + 6);
  y += 10;

  const tableRow = (feature: string, digital: string, manual: string, isEven: boolean) => {
    checkPage(10);
    if (isEven) {
      doc.setFillColor(249, 250, 251);
      doc.rect(margin, y - 1, contentWidth, 8, 'F');
    }
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(55, 65, 81);
    doc.text(feature, margin + 3, y + 4);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(22, 101, 52);
    doc.text(doc.splitTextToSize(digital, 70), margin + 50, y + 4);
    doc.setTextColor(153, 27, 27);
    doc.text(doc.splitTextToSize(manual, 40), margin + 130, y + 4);
    y += 9;
  };

  tableRow('Sauri', 'Nan take (dakikoki)', 'A hankali (sa\'o\'i)', false);
  tableRow('Daidaito', '100% daidai', 'Kuskuren mutum', true);
  tableRow('Rasiti', 'Atomatik, kwararru', 'Rubutun hannu', false);
  tableRow('Bincike', 'Nan take ta suna', 'Shafi bayan shafi', true);
  tableRow('Rahotanni', 'Lokaci guda, danna daya', 'Tattarawa da hannu (kwanaki)', false);
  tableRow('Tsaro', 'PIN, an rubuta', 'Saukin karya', true);
  tableRow('Ajiya', 'Dijital, ba iyaka', 'Na zahiri, karancin sarari', false);
  tableRow('Adanawa', 'An adana ta atomatik', 'Babu adanawa, zai iya bacewa', true);
  tableRow('SMS Iyaye', 'Sako tare da bayani', 'Babu hanya mai kyau', false);
  tableRow('Kudin', 'Shigarwa guda, babu kaya', 'Kayan da ake saya koyaushe', true);
  tableRow('Offline', 'Yana aiki ba intanet', 'Koyaushe na hannu', false);
  tableRow('Hotuna', 'An adana hoton dalibai', 'Babu bayanan hoto', true);
  tableRow('Habaka Aji', 'Danna daya', 'Na hannu, yana daukar lokaci', false);
  tableRow('Masu Amfani', 'Masu amfani da yawa', 'Yawanci mutum daya', true);
  tableRow('Binciken Aiki', 'Cikakken bayani', 'Babu binciken aiki', false);
  tableRow('Kwararru', 'Alama, sa hannu, zamani', 'Na asali, tsohuwar hanya', true);

  spacer(10);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('KAMMALAWA:', margin, y);
  y += 7;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(55, 65, 81);
  const conclusion = 'SchoolFees Pro yana kawar da duk matsalolin da ke tattare da karbar kudin karatu da hannu. Yana adana lokaci, rage kuskure, inganta tsaro, inganta sadarwa da iyaye, kuma yana baiwa makarantarku siffar zamani da kwararru. Saka hannun jari a tsarin biyan kudi na dijital ba kawai habakawa ba ne - larura ce ga kowane makarantar da ke son yin aiki cikin inganci a karni na 21.';
  const concLines = doc.splitTextToSize(conclusion, contentWidth);
  doc.text(concLines, margin, y);
  y += concLines.length * 5;
  spacer();
  line();

  // ==========================================
  // CHAPTERS 2-22 (Hausa translations)
  // ==========================================
  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('2. ABUBUWAN DA AKE BUKATA', margin, y);
  y += 12;
  body('SchoolFees Pro yana aiki a kowane na\'ura da ke da burauzar yanar gizo na zamani:');
  spacer();
  subtitle('Na\'urorin da ake Tallafawa:');
  bullet('Wayoyin Android da allunan (Ana ba da shawarar burauzar Chrome)');
  bullet('iPhone da iPad (burauzar Safari)');
  bullet('Kwamfutotin Windows, Mac, da Linux (Chrome, Edge, ko Firefox)');
  spacer();
  subtitle('Mafi Karancin Bukata:');
  bullet('Hadar intanet don kafa na farko kacal');
  bullet('Bayan shigarwa, app din yana aiki gaba daya ba tare da intanet ba');
  bullet('Akalla 50MB na sararin ajiya');
  bullet('Izinin kyamara don hoton fasfo na dalibai (na zabi)');
  bullet('Bluetooth don bugawa maras waya (na zabi)');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('3. YADDA AKE SHIGA (Login)', margin, y);
  y += 12;
  body('Lokacin da kuka bude app din a karon farko, za ku ga shafin shiga.');
  spacer();
  subtitle('Yadda ake Shiga:');
  numberedItem('1.', 'Bude app din a cikin burauzar yanar gizo');
  numberedItem('2.', 'Shigar da sunan mai amfani a filin "Username"');
  numberedItem('3.', 'Shigar da kalmar sirri a filin "Password"');
  numberedItem('4.', 'Zabi "Remember me" don ci gaba da shiga');
  numberedItem('5.', 'Danna "Sign In"');
  spacer();
  subtitle('Idan kun Manta Kalmar Sirri:');
  body('Tuntubar mai gudanarwa a 0703 856 2100 don taimakon sake saita kalmar sirri.');
  spacer();
  subtitle('Ire-iren Masu Amfani:');
  bullet('Admin - Cikakken damar shiga duk abubuwan da ke ciki');
  bullet('Accountant - Damar shiga biyan kudi, rahotanni, da gudanar da dalibai');
  bullet('Staff - Damar ganin dalibai da rubuta biya');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('4. DASHBOARD - ALLON GANI', margin, y);
  y += 12;
  body('Dashboard shine babban allon da kuke gani bayan shiga. Yana ba da takamaiman bayani game da halin kudin makaranta.');
  spacer();
  subtitle('Katunan Dashboard:');
  bullet('Kudin Yau - Jimlar kudin da aka karba a yau');
  bullet('Jimlar Kudi (Dukkan Zangon) - Jimlar kudin da aka karba gaba daya');
  bullet('Jimlar Dalibai - Adadin daliban da aka yi rijista');
  spacer();
  subtitle('Biyan Kudi na Kwanan nan:');
  body('Yana nuna ayyukan biyan kudi 5 na baya tare da sunan dalibai, aji, adadi, da kwanan wata.');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('5. GUDANAR DA DALIBAI (Students)', margin, y);
  y += 12;
  body('Sashen Dalibai yana ba ku damar kara, gyara, da gudanar da dukkan bayanan dalibai.');
  spacer();
  subtitle('Kara Sabon Dalibai:');
  numberedItem('1.', 'Je zuwa "Students" daga menu');
  numberedItem('2.', 'Danna maballin "Add Student"');
  numberedItem('3.', 'Loda ko dauki hoton fasfo ta amfani da maballin kyamara');
  numberedItem('4.', 'Shigar da cikakken sunan dalibai');
  numberedItem('5.', 'Zabi aji (Nursery 1 zuwa SS3)');
  numberedItem('6.', 'Zabi zangon karatu (1st, 2nd, ko 3rd)');
  numberedItem('7.', 'Kudin karatu zai cika ta atomatik daga tsarin kudin');
  numberedItem('8.', 'Shigar da lambar waya ta iyaye');
  numberedItem('9.', 'Danna "Add Student" don adanawa');
  spacer();
  subtitle('Hoton Fasfo:');
  bullet('Danna "Back" don amfani da kyamarar baya');
  bullet('Danna "Front" don amfani da kyamarar selfie');
  bullet('Danna "Switch" don canza tsakanin kyamarori');
  bullet('Danna "Capture" don daukan hoton');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('6-7. TSARIN KUDI da RUBUTA BIYA', margin, y);
  y += 12;
  subtitle('Saita Tsarin Kudin (Admin Kadai):');
  numberedItem('1.', 'Je zuwa Settings');
  numberedItem('2.', 'Gangara zuwa sashen "Fee Structure"');
  numberedItem('3.', 'Danna "Add Fee"');
  numberedItem('4.', 'Zabi Aji, Zangon Karatu, Session, da Kudin');
  numberedItem('5.', 'Danna "Save"');
  spacer();
  subtitle('Rubuta Biya:');
  numberedItem('1.', 'Je zuwa "Payments"');
  numberedItem('2.', 'Rubuta sunan dalibai a cikin akwatin bincike');
  numberedItem('3.', 'Zabi dalibai daga sakamakon (yana nuna hoto da ragowar kudi)');
  numberedItem('4.', 'Shigar da adadin da ake biya');
  numberedItem('5.', 'Danna "Record Payment"');
  numberedItem('6.', 'Shigar da lambar sirri ta PIN (lambobi 4)');
  numberedItem('7.', 'Danna "Authorize" don kammala biyan');
  numberedItem('8.', 'Rasiti za a samar da shi ta atomatik');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('8-9. LAMBAR SIRRI da TARIHI', margin, y);
  y += 12;
  subtitle('Lambar Sirri ta Biya (PIN):');
  body('Kowane biya yana bukatar lambar sirri ta lambobi 4. Wannan yana hana ayyukan da ba a ba da izini ba.');
  bullet('Dole ne ya kasance lambobi 4 kacal');
  bullet('Bayan yunwa 5 da ba daidai ba, za a kulle');
  bullet('Ba za a iya canza PIN ba tare da kalmar sirri ta shiga ba');
  bullet('Tuntubar admin a 0703 856 2100 don taimako');
  spacer();
  subtitle('Tarihin Biya da Sake Buga Rasiti:');
  numberedItem('1.', 'Je zuwa "History" daga menu');
  numberedItem('2.', 'Rubuta a akwatin bincike don nemo ta sunan dalibai');
  numberedItem('3.', 'Amfani da tacewa: Aji, Zangon Karatu, Kwanan wata');
  numberedItem('4.', 'Danna "Reprint" don sake buga rasiti');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('10-12. RAHOTANNI, SMS, da RASITI', margin, y);
  y += 12;
  subtitle('Rahotanni:');
  bullet('Daliban da ba su biya ba - yana nuna duk daliban da ke da bashi');
  bullet('Kudin Yau - yana nuna duk biyan da aka karba a yau');
  bullet('Fitar da Sunayen Dalibai - zabi aji sannan fitar da CSV');
  spacer();
  subtitle('Aika Sako ga Iyaye (SMS):');
  numberedItem('1.', 'Je zuwa Reports');
  numberedItem('2.', 'Danna "Send SMS to Unpaid Students"');
  numberedItem('3.', 'Zabi ranar karshe ta biya ta amfani da kalandar');
  numberedItem('4.', 'Danna "Send SMS" don kowane iyaye');
  spacer();
  subtitle('Rasiti:');
  body('Rasiti suna dauke da alamar makaranta, suna, adireshi, lambar rasiti, bayanan dalibai, kudin, da sa hannun dijital. Ana iya buga su, fitar su a PDF, ko aika ta Bluetooth.');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('13-15. HABAKA AJI, SAITUNA, MASU AMFANI', margin, y);
  y += 12;
  subtitle('Habaka Aji (Admin Kadai):');
  numberedItem('1.', 'Je zuwa Settings > "Class Promotion"');
  numberedItem('2.', 'Zabi ajin da za a habaka');
  numberedItem('3.', 'Danna "Preview Promotion"');
  numberedItem('4.', 'Danna "Confirm Promotion"');
  body('Daliban SS3 za a mayar da su cikin foldar masu kammala karatu ta shekarar (misali "2026/2027 Graduate").');
  spacer();
  subtitle('Saituna:');
  bullet('Sunan Makaranta da Adireshi');
  bullet('Alamar Makaranta (logo)');
  bullet('Sa Hannu na Dijital');
  bullet('Girman Rubutun Rasiti');
  bullet('Gudanar da Bayani (Reset)');
  spacer();
  subtitle('Gudanar da Masu Amfani (Admin Kadai):');
  bullet('Kara, gyara, share masu amfani');
  bullet('Sanya mukamin: Admin, Staff, ko Accountant');
  bullet('Kunna/kashe asusu');
  spacer();
  line();

  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('16-20. TSARO, BLUETOOTH, PWA, OFFLINE', margin, y);
  y += 12;
  subtitle('Tsaron Asusu:');
  bullet('Canja kalmar sirri: Settings > Account & Security > Change Password');
  bullet('Canja PIN: Settings > Account & Security > Change Payment PIN');
  bullet('Dole ne a shigar da kalmar sirri ta yanzu don tabbatarwa');
  spacer();
  subtitle('Sa Hannu na Dijital:');
  numberedItem('1.', 'Je zuwa Settings > Digital Signature');
  numberedItem('2.', 'Danna "Draw Signature"');
  numberedItem('3.', 'Zana sa hannun ku ta amfani da yatsa (waya) ko linzamin kwamfuta');
  numberedItem('4.', 'Danna "Save Signature"');
  spacer();
  subtitle('Bugawa ta Bluetooth:');
  numberedItem('1.', 'Danna maballin Bluetooth (kusurwar dama ta kasa)');
  numberedItem('2.', 'Zabi na\'urar bugawa daga jerin na\'urori');
  numberedItem('3.', 'Lokacin kallon rasiti, danna "Bluetooth Print"');
  spacer();
  subtitle('Shigar da App a Waya (PWA):');
  bullet('Android: Bude a Chrome > Menu > "Install app"');
  bullet('iPhone: Bude a Safari > Share > "Add to Home Screen"');
  bullet('Desktop: Bude a Chrome > Danna alamar shigarwa');
  spacer();
  subtitle('Aiki Ba tare da Intanet ba:');
  body('Bayan ziyartar app din a karon farko (tare da intanet), duk abubuwa suna aiki ba tare da intanet ba. Ana adana duk bayanan a na\'urar ku.');
  spacer();
  line();

  // ==========================================
  // TROUBLESHOOTING & CONTACT
  // ==========================================
  addPage();
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('21. WARWARE MATSALOLI', margin, y);
  y += 12;

  subtitle('Matsala: Ba zan iya shiga ba');
  body('Magani: Tabbatar da sunan mai amfani da kalmar sirri. Tuntubar admin a 0703 856 2100.');
  spacer();
  subtitle('Matsala: PIN bai yi aiki ba');
  body('Magani: Bayan yunwa 5, an kulle PIN. Tuntubar admin don sake saiti.');
  spacer();
  subtitle('Matsala: Kyamara ba ta aiki ba');
  body('Magani: Tabbatar cewa an ba da izinin kyamara a saitin burauzar ku. Gwada canza tsakanin kyamarar gaba da baya.');
  spacer();
  subtitle('Matsala: Rasiti bai buga ba');
  body('Magani: Don buga ta burauzar, tabbatar an hada na\'urar bugawa. Don Bluetooth, tabbatar an hada na\'urar kuma maballin Bluetooth yana kore.');
  spacer();
  subtitle('Matsala: Bayanan sun bace');
  body('Magani: Ana adana bayanan a cikin localStorage na burauzar ku. Share bayanan burauzar ko cache zai goge bayanan.');
  spacer();
  line();

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('22. TUNTUBAR MU (Contact)', margin, y);
  y += 12;

  doc.setFillColor(240, 245, 255);
  doc.roundedRect(margin, y, contentWidth, 55, 3, 3, 'F');
  y += 8;
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Kida Digital Solutions Centre', margin + 10, y);
  y += 7;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(75, 85, 99);
  doc.text('Mai Kirkira: Abdullah Hashimu Kida (Managing Director)', margin + 10, y); y += 6;
  doc.text('Waya: 0703 856 2100', margin + 10, y); y += 6;
  doc.text('Email: support@kidadigital.com', margin + 10, y); y += 6;
  doc.text('Website: www.kidadigital.com', margin + 10, y); y += 6;
  doc.text('Adireshi: Kusa da Makarantar Firamare ta Kida, Hawul L.G.A, Jihar Borno', margin + 10, y); y += 6;

  y += 15;
  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text('(c) 2026 Kida Digital Solutions Centre. Duk hakkin mallaka an kiyaye su.', pageWidth / 2, y, { align: 'center' });
  doc.text('Version 1.0 | Afrilu 4, 2026', pageWidth / 2, y + 5, { align: 'center' });

  // Add page numbers
  pageFooter();

  doc.save('SchoolFees_Pro_Dalili_Hausa.pdf');
}
