import { useState, useMemo } from 'react';

interface Student {
  id: number;
  name: string;
  class: string;
  admissionNumber: string;
  term: string;
  totalFee: number;
  parentPhone: string;
}

interface ClassPromotionProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}

// Exact promotion mapping: each class promotes to the next
const PROMOTION_MAP: Record<string, string> = {
  'Nursery 1': 'Nursery 2',
  'Nursery 2': 'Nursery 3',
  'Nursery 3': 'Primary 1',
  'Primary 1': 'Primary 2',
  'Primary 2': 'Primary 3',
  'Primary 3': 'Primary 4',
  'Primary 4': 'Primary 5',
  'Primary 5': 'Primary 6',
  'Primary 6': 'JSS1',
  'JSS1': 'JSS2',
  'JSS2': 'JSS3',
  'JSS3': 'SS1',
  'SS1': 'SS2',
  'SS2': 'SS3',
  'SS3': 'GRADUATE'
};

const CLASS_ORDER = [
  'Nursery 1', 'Nursery 2', 'Nursery 3',
  'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6',
  'JSS1', 'JSS2', 'JSS3',
  'SS1', 'SS2', 'SS3'
];

const FINAL_CLASSES = ['SS3'];

export default function ClassPromotion({ students, setStudents }: ClassPromotionProps) {
  const [showConfirm, setShowConfirm] = useState(false);
  const [promotionPreview, setPromotionPreview] = useState<any[]>([]);
  const [selectedClasses, setSelectedClasses] = useState<string[]>([]);
  const [promotionDone, setPromotionDone] = useState(false);

  // Get graduates list from localStorage
  const [graduates, setGraduates] = useState<Student[]>(() => {
    const stored = localStorage.getItem('graduates');
    return stored ? JSON.parse(stored) : [];
  });

  const [showGraduates, setShowGraduates] = useState(false);

  // Count students per class
  const classCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    CLASS_ORDER.forEach(c => { counts[c] = 0; });
    students.forEach(s => {
      if (counts[s.class] !== undefined) {
        counts[s.class]++;
      }
    });
    return counts;
  }, [students]);

  const getNextClass = (currentClass: string): string => {
    return PROMOTION_MAP[currentClass] || currentClass;
  };

  const toggleClass = (className: string) => {
    setSelectedClasses(prev => 
      prev.includes(className) 
        ? prev.filter(c => c !== className) 
        : [...prev, className]
    );
  };

  const selectAll = () => {
    const classesWithStudents = CLASS_ORDER.filter(c => classCounts[c] > 0);
    setSelectedClasses(classesWithStudents);
  };

  const deselectAll = () => {
    setSelectedClasses([]);
  };

  const previewPromotion = () => {
    if (selectedClasses.length === 0) {
      alert('Please select at least one class to promote!');
      return;
    }

    const preview = students
      .filter(s => selectedClasses.includes(s.class))
      .map(s => ({
        ...s,
        fromClass: s.class,
        toClass: getNextClass(s.class),
        isGraduating: FINAL_CLASSES.includes(s.class)
      }));

    setPromotionPreview(preview);
    setShowConfirm(true);
  };

  // Generate graduation session name e.g. "2026/2027"
  const getGraduationSession = () => {
    const year = new Date().getFullYear();
    return `${year}/${year + 1}`;
  };

  const executePromotion = () => {
    const graduatingStudents: Student[] = [];
    const updatedStudents = students.map(s => {
      if (!selectedClasses.includes(s.class)) return s;

      if (FINAL_CLASSES.includes(s.class)) {
        graduatingStudents.push(s);
        return null;
      }

      const nextClass = getNextClass(s.class);
      if (nextClass === 'GRADUATE') {
        graduatingStudents.push(s);
        return null;
      }

      return { ...s, class: nextClass };
    }).filter(Boolean) as Student[];

    // Save graduates with session name
    const session = getGraduationSession();
    const allGraduates = [...graduates, ...graduatingStudents.map(s => ({
      ...s,
      graduatedAt: new Date().toISOString(),
      graduatedFrom: s.class,
      graduationSession: session
    }))];
    setGraduates(allGraduates as any);
    localStorage.setItem('graduates', JSON.stringify(allGraduates));

    // Update students
    setStudents(updatedStudents);

    // Log promotion
    const promotionLog = JSON.parse(localStorage.getItem('promotionLog') || '[]');
    promotionLog.push({
      timestamp: new Date().toISOString(),
      promoted: updatedStudents.length,
      graduated: graduatingStudents.length,
      classes: selectedClasses,
      session: session
    });
    localStorage.setItem('promotionLog', JSON.stringify(promotionLog.slice(-20)));

    setShowConfirm(false);
    setPromotionPreview([]);
    setSelectedClasses([]);
    setPromotionDone(true);
  };

  const restoreGraduate = (graduate: any) => {
    if (confirm(`Restore ${graduate.name} back to ${graduate.graduatedFrom || 'SS3'}?`)) {
      const restoredStudent: Student = {
        id: graduate.id,
        name: graduate.name,
        class: graduate.graduatedFrom || 'SS3',
        admissionNumber: graduate.admissionNumber,
        term: graduate.term,
        totalFee: graduate.totalFee,
        parentPhone: graduate.parentPhone
      };
      setStudents(prev => [...prev, restoredStudent]);

      const updatedGrads = graduates.filter((g: any) => g.id !== graduate.id);
      setGraduates(updatedGrads);
      localStorage.setItem('graduates', JSON.stringify(updatedGrads));
    }
  };

  const deleteGraduate = (id: number) => {
    if (confirm('Permanently delete this graduate record?')) {
      const updatedGrads = graduates.filter((g: any) => g.id !== id);
      setGraduates(updatedGrads);
      localStorage.setItem('graduates', JSON.stringify(updatedGrads));
    }
  };

  return (
    <div className="space-y-6">
      {/* Success Message */}
      {promotionDone && (
        <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center">
            <i className="fas fa-check-circle text-green-600 text-2xl mr-3"></i>
            <div>
              <p className="font-bold text-green-800">Promotion Completed Successfully!</p>
              <p className="text-sm text-green-700">All selected students have been promoted to the next class.</p>
            </div>
          </div>
          <button onClick={() => setPromotionDone(false)} className="text-green-600 hover:text-green-800">
            <i className="fas fa-times"></i>
          </button>
        </div>
      )}

      {/* Class Overview */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="flex justify-between items-center mb-4">
          <h4 className="font-bold text-gray-800">
            <i className="fas fa-th-list text-blue-600 mr-2"></i>
            Select Classes to Promote
          </h4>
          <div className="flex space-x-2">
            <button onClick={selectAll} className="text-sm text-blue-600 hover:text-blue-800 font-medium">
              Select All
            </button>
            <span className="text-gray-300">|</span>
            <button onClick={deselectAll} className="text-sm text-gray-600 hover:text-gray-800 font-medium">
              Deselect All
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {CLASS_ORDER.map(className => {
            const count = classCounts[className];
            const nextClass = getNextClass(className);
            const isSelected = selectedClasses.includes(className);
            const isGraduating = FINAL_CLASSES.includes(className);

            return (
              <button
                key={className}
                onClick={() => count > 0 && toggleClass(className)}
                disabled={count === 0}
                className={`p-3 rounded-lg border-2 text-left transition-all ${
                  count === 0 
                    ? 'border-gray-200 bg-gray-50 opacity-50 cursor-not-allowed' 
                    : isSelected 
                      ? isGraduating 
                        ? 'border-orange-500 bg-orange-50' 
                        : 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50 cursor-pointer'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-bold text-sm">{className}</p>
                    <p className="text-xs text-gray-500">{count} student{count !== 1 ? 's' : ''}</p>
                  </div>
                  {isSelected && count > 0 && (
                    <i className="fas fa-check-circle text-blue-600"></i>
                  )}
                </div>
                {count > 0 && (
                  <div className="mt-2">
                    <i className="fas fa-arrow-right text-xs text-gray-400 mr-1"></i>
                    <span className={`text-xs font-medium ${isGraduating ? 'text-orange-600' : 'text-green-600'}`}>
                      {nextClass === 'GRADUATE' ? '🎓 Graduate' : nextClass}
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Promote Button */}
      <div className="flex space-x-3">
        <button
          onClick={previewPromotion}
          disabled={selectedClasses.length === 0}
          className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-purple-700 font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
        >
          <i className="fas fa-arrow-up mr-2"></i>
          Preview Promotion ({selectedClasses.length} class{selectedClasses.length !== 1 ? 'es' : ''})
        </button>
        <button
          onClick={() => setShowGraduates(!showGraduates)}
          className="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 font-semibold shadow-lg"
        >
          <i className="fas fa-graduation-cap mr-2"></i>
          Graduates ({graduates.length})
        </button>
      </div>

      {/* Promotion Guide */}
      <div className="bg-blue-50 border-l-4 border-blue-600 rounded-lg p-4">
        <h4 className="font-bold text-blue-900 mb-3">
          <i className="fas fa-info-circle mr-2"></i>
          Exact Promotion Flow
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-blue-800">
          <div className="bg-white bg-opacity-50 rounded-lg p-3">
            <p className="font-bold text-blue-900 mb-2">🏫 Nursery Section:</p>
            <p>Nursery 1 → Nursery 2</p>
            <p>Nursery 2 → Nursery 3</p>
            <p>Nursery 3 → <strong>Primary 1</strong></p>
          </div>
          <div className="bg-white bg-opacity-50 rounded-lg p-3">
            <p className="font-bold text-blue-900 mb-2">📚 Primary Section:</p>
            <p>Primary 1 → Primary 2</p>
            <p>Primary 2 → Primary 3</p>
            <p>Primary 3 → Primary 4</p>
            <p>Primary 4 → Primary 5</p>
            <p>Primary 5 → Primary 6</p>
            <p>Primary 6 → <strong>JSS1</strong></p>
          </div>
          <div className="bg-white bg-opacity-50 rounded-lg p-3">
            <p className="font-bold text-blue-900 mb-2">📖 Junior Secondary:</p>
            <p>JSS1 → JSS2</p>
            <p>JSS2 → JSS3</p>
            <p>JSS3 → <strong>SS1</strong></p>
          </div>
          <div className="bg-white bg-opacity-50 rounded-lg p-3">
            <p className="font-bold text-blue-900 mb-2">🎓 Senior Secondary:</p>
            <p>SS1 → SS2</p>
            <p>SS2 → SS3</p>
            <p>SS3 → <strong>🎓 Graduate List</strong></p>
          </div>
        </div>
      </div>

      {/* Graduates List - Folder Style */}
      {showGraduates && (() => {
        // Group graduates by session
        const graduatesBySession: Record<string, any[]> = {};
        graduates.forEach((grad: any) => {
          const session = grad.graduationSession || 'Unknown Session';
          if (!graduatesBySession[session]) {
            graduatesBySession[session] = [];
          }
          graduatesBySession[session].push(grad);
        });

        // Sort sessions newest first
        const sortedSessions = Object.keys(graduatesBySession).sort().reverse();

        return (
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex justify-between items-center mb-6">
            <h4 className="font-bold text-gray-800 text-lg">
              <i className="fas fa-graduation-cap text-orange-600 mr-2"></i>
              Graduate Folders ({sortedSessions.length} session{sortedSessions.length !== 1 ? 's' : ''} • {graduates.length} total)
            </h4>
            <button onClick={() => setShowGraduates(false)} className="text-gray-400 hover:text-gray-600">
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>

          {graduates.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <i className="fas fa-folder-open text-6xl text-gray-300 mb-4"></i>
              <p className="text-lg font-medium">No graduate folders yet</p>
              <p className="text-sm">Graduate folders will appear here after promoting SS3 students</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedSessions.map(session => (
                <FolderCard 
                  key={session} 
                  session={session} 
                  graduates={graduatesBySession[session]} 
                  onRestore={restoreGraduate}
                  onDelete={deleteGraduate}
                />
              ))}
            </div>
          )}
        </div>
        );
      })()}

      {/* Promotion Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  <i className="fas fa-arrow-up text-blue-600 mr-2"></i>
                  Confirm Class Promotion
                </h3>
                <button onClick={() => setShowConfirm(false)} className="text-gray-400 hover:text-gray-600">
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              {/* Summary */}
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-blue-50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-blue-600">{promotionPreview.length}</p>
                  <p className="text-xs text-gray-600">Total Students</p>
                </div>
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-green-600">
                    {promotionPreview.filter(s => !s.isGraduating).length}
                  </p>
                  <p className="text-xs text-gray-600">Promoting</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-orange-600">
                    {promotionPreview.filter(s => s.isGraduating).length}
                  </p>
                  <p className="text-xs text-gray-600">🎓 Graduating</p>
                </div>
              </div>

              {/* Student List */}
              <div className="border rounded-lg max-h-80 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-3 text-left">Student</th>
                      <th className="p-3 text-left">From</th>
                      <th className="p-3 text-center"></th>
                      <th className="p-3 text-left">To</th>
                    </tr>
                  </thead>
                  <tbody>
                    {promotionPreview.map(student => (
                      <tr key={student.id} className={`border-b ${student.isGraduating ? 'bg-orange-50' : ''}`}>
                        <td className="p-3">
                          <p className="font-medium">{student.name}</p>
                          <p className="text-xs text-gray-500">{student.admissionNumber}</p>
                        </td>
                        <td className="p-3">
                          <span className="bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-medium">
                            {student.fromClass}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <i className="fas fa-arrow-right text-gray-400"></i>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            student.isGraduating 
                              ? 'bg-orange-100 text-orange-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {student.isGraduating ? '🎓 Graduate' : student.toClass}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Warning */}
              <div className="bg-yellow-50 border-l-4 border-yellow-500 rounded-lg p-4 mt-4">
                <p className="text-sm text-yellow-800">
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  <strong>Warning:</strong> This action will promote all selected students to the next class.
                  SS3 students will be moved to the Graduate list. This cannot be undone easily.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3 mt-6">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-medium"
                >
                  <i className="fas fa-times mr-2"></i>Cancel
                </button>
                <button
                  onClick={executePromotion}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-lg hover:from-green-700 hover:to-emerald-700 font-semibold shadow-lg"
                >
                  <i className="fas fa-check-circle mr-2"></i>
                  Confirm Promotion
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Folder Card Component - Each graduation year as a folder
function FolderCard({ session, graduates, onRestore, onDelete }: { 
  session: string; 
  graduates: any[]; 
  onRestore: (grad: any) => void;
  onDelete: (id: number) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-2 border-amber-300 rounded-xl overflow-hidden">
      {/* Folder Tab */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 p-4 flex items-center justify-between hover:from-amber-500 hover:to-orange-500 transition-all"
      >
        <div className="flex items-center space-x-4">
          <div className="relative">
            <i className={`fas fa-folder${isOpen ? '-open' : ''} text-4xl text-amber-800`}></i>
            <span className="absolute -top-1 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
              {graduates.length}
            </span>
          </div>
          <div className="text-left">
            <h5 className="font-bold text-lg text-amber-900">📁 {session} Graduate</h5>
            <p className="text-sm text-amber-800">{graduates.length} student{graduates.length !== 1 ? 's' : ''} in this folder</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <span className="bg-white bg-opacity-40 px-3 py-1 rounded-full text-sm font-bold text-amber-900">
            🎓 {graduates.length}
          </span>
          <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'} text-amber-800`}></i>
        </div>
      </button>

      {/* Folder Contents */}
      {isOpen && (
        <div className="bg-amber-50 p-4">
          {/* Folder Stats */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white rounded-lg p-2 text-center border border-amber-200">
              <p className="text-xl font-bold text-amber-600">{graduates.length}</p>
              <p className="text-xs text-gray-600">Total</p>
            </div>
            <div className="bg-white rounded-lg p-2 text-center border border-amber-200">
              <p className="text-xl font-bold text-orange-600">SS3</p>
              <p className="text-xs text-gray-600">From Class</p>
            </div>
            <div className="bg-white rounded-lg p-2 text-center border border-amber-200">
              <p className="text-xl font-bold text-green-600">{session}</p>
              <p className="text-xs text-gray-600">Session</p>
            </div>
          </div>

          {/* Export Folder Button */}
          <button
            onClick={() => {
              const headers = ['S/N', 'Student Name', 'Class', 'Admission No', 'Graduation Date', 'Session'];
              const csvData = [
                headers,
                ...graduates.map((g: any, i: number) => [
                  (i + 1).toString(),
                  g.name,
                  g.graduatedFrom || g.class,
                  g.admissionNumber,
                  g.graduatedAt ? new Date(g.graduatedAt).toLocaleDateString() : '',
                  session
                ])
              ];
              const csvContent = "data:text/csv;charset=utf-8," +
                csvData.map(row => row.map(cell => `"${cell}"`).join(",")).join("\n");
              const link = document.createElement("a");
              link.setAttribute("href", encodeURI(csvContent));
              link.setAttribute("download", `${session}_graduates.csv`);
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }}
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 mb-4 text-sm font-medium"
          >
            <i className="fas fa-download mr-2"></i>
            Export {session} Graduate List to CSV
          </button>

          {/* Student List */}
          <div className="space-y-2">
            {graduates.map((grad: any, idx: number) => (
              <div key={grad.id} className="bg-white border border-amber-200 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <div className="w-9 h-9 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm shadow">
                      {idx + 1}
                    </div>
                    <div>
                      <p className="font-bold text-gray-800">{grad.name}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <span className="bg-orange-100 text-orange-800 px-2 py-0.5 rounded text-xs font-medium">
                          🎓 {grad.graduatedFrom || grad.class}
                        </span>
                        <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-xs">
                          {grad.admissionNumber}
                        </span>
                        {grad.graduatedAt && (
                          <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-xs">
                            {new Date(grad.graduatedAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => onRestore(grad)}
                      className="bg-blue-600 text-white px-2.5 py-1.5 rounded text-xs hover:bg-blue-700"
                      title="Restore to class"
                    >
                      <i className="fas fa-undo"></i>
                    </button>
                    <button
                      onClick={() => onDelete(grad.id)}
                      className="bg-red-600 text-white px-2.5 py-1.5 rounded text-xs hover:bg-red-700"
                      title="Delete permanently"
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
