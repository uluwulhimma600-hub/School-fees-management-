// IndexedDB Database for SchoolFees Pro
// Supports large data storage (500MB+) vs localStorage (5MB)
// Persistent storage requested so browser never auto-deletes

const DB_NAME = 'SchoolFeesProDB';
const DB_VERSION = 2;

const STORES = {
  students: 'students',
  payments: 'payments',
  settings: 'settings',
  feeStructures: 'feeStructures',
  graduates: 'graduates',
  users: 'users',
  logs: 'logs',
};

let dbInstance: IDBDatabase | null = null;

// Open/create the database
function openDB(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Students store with indexes for fast search
      if (!db.objectStoreNames.contains(STORES.students)) {
        const studentStore = db.createObjectStore(STORES.students, { keyPath: 'id' });
        studentStore.createIndex('name', 'name', { unique: false });
        studentStore.createIndex('class', 'class', { unique: false });
        studentStore.createIndex('admissionNumber', 'admissionNumber', { unique: false });
        studentStore.createIndex('parentPhone', 'parentPhone', { unique: false });
      }
      // Payments store with indexes
      if (!db.objectStoreNames.contains(STORES.payments)) {
        const paymentStore = db.createObjectStore(STORES.payments, { keyPath: 'id' });
        paymentStore.createIndex('studentId', 'studentId', { unique: false });
        paymentStore.createIndex('term', 'term', { unique: false });
        paymentStore.createIndex('date', 'date', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.settings)) {
        db.createObjectStore(STORES.settings, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORES.feeStructures)) {
        const feeStore = db.createObjectStore(STORES.feeStructures, { keyPath: 'id' });
        feeStore.createIndex('class', 'class', { unique: false });
        feeStore.createIndex('term', 'term', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.graduates)) {
        const gradStore = db.createObjectStore(STORES.graduates, { keyPath: 'id' });
        gradStore.createIndex('graduationSession', 'graduationSession', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.users)) {
        const userStore = db.createObjectStore(STORES.users, { keyPath: 'id' });
        userStore.createIndex('username', 'username', { unique: true });
      }
      if (!db.objectStoreNames.contains(STORES.logs)) {
        const logStore = db.createObjectStore(STORES.logs, { keyPath: 'id', autoIncrement: true });
        logStore.createIndex('type', 'type', { unique: false });
        logStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };

    request.onerror = () => {
      console.error('IndexedDB open failed, falling back to localStorage');
      reject(request.error);
    };
  });
}

// ========== GENERIC CRUD OPERATIONS ==========

// Get all items from a store
export async function dbGetAll<T>(storeName: string): Promise<T[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result as T[]);
      request.onerror = () => reject(request.error);
    });
  } catch {
    // Fallback to localStorage
    const data = localStorage.getItem(storeName);
    return data ? JSON.parse(data) : [];
  }
}

// Get single item by key
export async function dbGet<T>(storeName: string, key: any): Promise<T | undefined> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result as T | undefined);
      request.onerror = () => reject(request.error);
    });
  } catch {
    return undefined;
  }
}

// Put (add or update) single item
export async function dbPut<T>(storeName: string, item: T): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.put(item);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Fallback
  }
}

// Save entire array (replace all)
export async function dbSaveAll<T>(storeName: string, items: T[]): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.clear();
      items.forEach(item => store.put(item));
      tx.oncomplete = () => {
        // Also save to localStorage as backup
        try { localStorage.setItem(storeName, JSON.stringify(items)); } catch {}
        resolve();
      };
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Fallback to localStorage
    try { localStorage.setItem(storeName, JSON.stringify(items)); } catch {}
  }
}

// Delete single item by key
export async function dbDelete(storeName: string, key: any): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {}
}

// Clear entire store
export async function dbClear(storeName: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {}
}

// ========== SETTINGS (key-value) ==========

export async function dbGetSettings(key: string): Promise<any> {
  try {
    const result = await dbGet<{ key: string; value: any }>(STORES.settings, key);
    return result?.value;
  } catch {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  }
}

export async function dbSaveSettings(key: string, value: any): Promise<void> {
  try {
    await dbPut(STORES.settings, { key, value });
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  } catch {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }
}

// ========== CLEAR ALL DATA ==========

export async function dbClearAll(): Promise<void> {
  try {
    const db = await openDB();
    const storeNames = Array.from(db.objectStoreNames);
    const tx = db.transaction(storeNames, 'readwrite');
    storeNames.forEach(name => tx.objectStore(name).clear());
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {}
  localStorage.clear();
}

// ========== MIGRATION: localStorage -> IndexedDB ==========

export async function migrateFromLocalStorage(): Promise<void> {
  try {
    // Migrate students
    const students = localStorage.getItem('students');
    if (students) {
      const data = JSON.parse(students);
      if (data.length > 0) {
        const existing = await dbGetAll(STORES.students);
        if (existing.length === 0) {
          await dbSaveAll(STORES.students, data);
          console.log('[DB] Migrated', data.length, 'students');
        }
      }
    }

    // Migrate payments
    const payments = localStorage.getItem('payments');
    if (payments) {
      const data = JSON.parse(payments);
      if (data.length > 0) {
        const existing = await dbGetAll(STORES.payments);
        if (existing.length === 0) {
          await dbSaveAll(STORES.payments, data);
          console.log('[DB] Migrated', data.length, 'payments');
        }
      }
    }

    // Migrate fee structures
    const fees = localStorage.getItem('feeStructures');
    if (fees) {
      const data = JSON.parse(fees);
      if (data.length > 0) {
        const existing = await dbGetAll(STORES.feeStructures);
        if (existing.length === 0) {
          await dbSaveAll(STORES.feeStructures, data);
          console.log('[DB] Migrated', data.length, 'fee structures');
        }
      }
    }

    // Migrate graduates
    const grads = localStorage.getItem('graduates');
    if (grads) {
      const data = JSON.parse(grads);
      if (data.length > 0) {
        const existing = await dbGetAll(STORES.graduates);
        if (existing.length === 0) {
          await dbSaveAll(STORES.graduates, data);
          console.log('[DB] Migrated', data.length, 'graduates');
        }
      }
    }

    // Migrate users
    const users = localStorage.getItem('users');
    if (users) {
      const data = JSON.parse(users);
      if (data.length > 0) {
        const existing = await dbGetAll(STORES.users);
        if (existing.length === 0) {
          await dbSaveAll(STORES.users, data);
          console.log('[DB] Migrated', data.length, 'users');
        }
      }
    }

    // Migrate settings
    const settings = localStorage.getItem('settings');
    if (settings) {
      await dbSaveSettings('settings', JSON.parse(settings));
      console.log('[DB] Migrated settings');
    }

    console.log('[DB] Migration complete');
  } catch (error) {
    console.error('[DB] Migration failed:', error);
  }
}

// ========== DB INFO ==========

export async function dbGetSize(): Promise<{ used: string; stores: Record<string, number> }> {
  const stores: Record<string, number> = {};
  try {
    const db = await openDB();
    for (const name of Array.from(db.objectStoreNames)) {
      const items = await dbGetAll(name);
      stores[name] = items.length;
    }
  } catch {}

  // Estimate storage used
  let usedBytes = 0;
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      usedBytes = estimate.usage || 0;
    }
  } catch {}

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return { used: formatBytes(usedBytes), stores };
}

// ========== REQUEST PERSISTENT STORAGE ==========
// Prevents browser from auto-deleting data when storage is low

export async function requestPersistentStorage(): Promise<boolean> {
  try {
    if (navigator.storage && navigator.storage.persist) {
      const granted = await navigator.storage.persist();
      console.log('[DB] Persistent storage:', granted ? 'GRANTED' : 'denied');
      return granted;
    }
  } catch {}
  return false;
}

// ========== STORAGE QUOTA ==========

export async function getStorageQuota(): Promise<{ used: number; quota: number; percent: number }> {
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const est = await navigator.storage.estimate();
      const used = est.usage || 0;
      const quota = est.quota || 0;
      return { used, quota, percent: quota > 0 ? Math.round((used / quota) * 100) : 0 };
    }
  } catch {}
  return { used: 0, quota: 0, percent: 0 };
}

export { STORES };
