interface DeveloperInfoProps {
  isVisible: boolean;
  onClose: () => void;
}

export default function DeveloperInfo({ isVisible, onClose }: DeveloperInfoProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 rounded-2xl max-w-2xl w-full max-h-screen overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="relative">
          <div className="absolute top-4 right-4">
            <button
              onClick={onClose}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white rounded-full p-2 transition-all"
            >
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <div className="text-center pt-8 pb-6 px-6">
            <div className="bg-white rounded-xl mx-auto mb-4 p-3 shadow-lg w-56">
              <img 
                src="./images/kida-logo.png" 
                alt="KIDA Digital Solutions Center Logo" 
                className="w-full h-auto object-contain"
              />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Kida Digital Solutions Centre</h2>
            <p className="text-blue-100 text-lg">Software Development & ICT Services</p>
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-t-3xl px-6 pb-8">
          {/* Contact Information */}
          <div className="py-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <i className="fas fa-address-card text-blue-600 mr-2"></i>
              Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <i className="fas fa-map-marker-alt text-blue-600"></i>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Address</p>
                  <p className="text-gray-800 font-medium">Besides Kida Primary School,<br/>Hawul L.G.A, Borno State</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="bg-green-100 p-2 rounded-lg">
                  <i className="fas fa-phone text-green-600"></i>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Phone</p>
                  <p className="text-gray-800 font-medium">0703 856 2100</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="bg-purple-100 p-2 rounded-lg">
                  <i className="fas fa-envelope text-purple-600"></i>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="text-gray-800 font-medium">support@kidadigital.com</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="bg-orange-100 p-2 rounded-lg">
                  <i className="fas fa-globe text-orange-600"></i>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Website</p>
                  <p className="text-gray-800 font-medium">www.kidadigital.com</p>
                </div>
              </div>
            </div>
          </div>

          {/* Developer */}
          <div className="py-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <i className="fas fa-user-tie text-blue-600 mr-2"></i>
              Managing Director / Lead Developer
            </h3>
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-5">
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold shadow-lg">
                  AK
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-800">Abdullah Hashimu Kida</p>
                  <p className="text-blue-600 font-semibold">Managing Director</p>
                  <p className="text-gray-600 text-sm">Software Developer & ICT Specialist</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium">
                  <i className="fas fa-code mr-1"></i>
                  Full-Stack Developer
                </span>
                <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-medium">
                  <i className="fas fa-mobile-alt mr-1"></i>
                  Mobile Apps
                </span>
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium">
                  <i className="fas fa-graduation-cap mr-1"></i>
                  ICT Training
                </span>
                <span className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-xs font-medium">
                  <i className="fas fa-user-tie mr-1"></i>
                  Managing Director
                </span>
              </div>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-phone text-blue-600 mr-2 w-4 text-center"></i>
                  <span>0703 856 2100</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-envelope text-blue-600 mr-2 w-4 text-center"></i>
                  <span className="text-sm">abdullahihashimu00@gmail.com</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-id-badge text-blue-600 mr-2 w-4 text-center"></i>
                  <span>ID: 001</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-map-marker-alt text-blue-600 mr-2 w-4 text-center"></i>
                  <span>Hawul, Borno State</span>
                </div>
              </div>
            </div>
          </div>

          {/* Services */}
          <div className="py-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <i className="fas fa-briefcase text-blue-600 mr-2"></i>
              Services Offered
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center space-x-3 bg-green-50 p-3 rounded-lg">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
                <span className="text-gray-800 font-medium">School Management Systems</span>
              </div>
              <div className="flex items-center space-x-3 bg-green-50 p-3 rounded-lg">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
                <span className="text-gray-800 font-medium">Student Report Sheet Generators</span>
              </div>
              <div className="flex items-center space-x-3 bg-green-50 p-3 rounded-lg">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
                <span className="text-gray-800 font-medium">Digital Result Processing</span>
              </div>
              <div className="flex items-center space-x-3 bg-green-50 p-3 rounded-lg">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
                <span className="text-gray-800 font-medium">ICT Training for Schools</span>
              </div>
              <div className="flex items-center space-x-3 bg-green-50 p-3 rounded-lg md:col-span-2">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
                <span className="text-gray-800 font-medium">Custom Software Development</span>
              </div>
            </div>
          </div>

          {/* Download Manuals */}
          <div className="py-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <i className="fas fa-book text-blue-600 mr-2"></i>
              User Manuals
            </h3>
            <div className="space-y-3">
              <button
                onClick={() => {
                  import('../generateManual').then(m => m.generateUserManual());
                }}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-xl hover:from-green-700 hover:to-emerald-700 font-semibold text-lg shadow-lg flex items-center justify-center"
              >
                <i className="fas fa-file-pdf mr-3 text-xl"></i>
                Download User Manual (English)
              </button>
              <button
                onClick={() => {
                  import('../generateManualArabic').then(m => m.generateUserManualArabic());
                }}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white py-4 rounded-xl hover:from-amber-600 hover:to-orange-700 font-semibold text-lg shadow-lg flex items-center justify-center"
              >
                <i className="fas fa-file-pdf mr-3 text-xl"></i>
                Zazzage Dalili (Hausa)
              </button>
              <button
                onClick={async () => {
                  const btn = document.activeElement as HTMLButtonElement;
                  if (btn) { btn.textContent = '... جاري التحميل'; btn.disabled = true; }
                  const m = await import('../generateManualAr');
                  await m.generateUserManualAr();
                  if (btn) { btn.innerHTML = '<i class="fas fa-file-pdf mr-3"></i> دليل المستخدم (العربية)'; btn.disabled = false; }
                }}
                className="w-full bg-gradient-to-r from-teal-600 to-cyan-700 text-white py-4 rounded-xl hover:from-teal-700 hover:to-cyan-800 font-semibold text-lg shadow-lg flex items-center justify-center"
              >
                <i className="fas fa-file-pdf mr-3 text-xl"></i>
                دليل المستخدم (العربية)
              </button>
              <p className="text-xs text-gray-500 text-center">Complete guide with advantages of digital payment & comparison tables</p>
            </div>
          </div>

          {/* CTA */}
          <div className="py-6">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-center text-white">
              <h4 className="text-xl font-bold mb-2">Need a Custom Solution?</h4>
              <p className="text-blue-100 mb-4">Contact us today for your software development needs</p>
              <div className="flex flex-col sm:flex-row justify-center space-y-2 sm:space-y-0 sm:space-x-3">
                <a
                  href="tel:07038562100"
                  className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-all flex items-center justify-center"
                >
                  <i className="fas fa-phone mr-2"></i>
                  Call Now
                </a>
                <a
                  href="mailto:support@kidadigital.com"
                  className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-all flex items-center justify-center"
                >
                  <i className="fas fa-envelope mr-2"></i>
                  Email Us
                </a>
                <a
                  href="https://www.kidadigital.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-all flex items-center justify-center"
                >
                  <i className="fas fa-globe mr-2"></i>
                  Visit Website
                </a>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-6 border-t border-gray-200">
            <div className="text-center">
              <p className="text-gray-600 text-sm mb-2">
                © 2026 Kida Digital Solutions Centre. All rights reserved.
              </p>
              <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
                <span className="flex items-center">
                  <i className="fas fa-tag mr-1"></i>
                  Version 1.0
                </span>
                <span>·</span>
                <span className="flex items-center">
                  <i className="fas fa-calendar-alt mr-1"></i>
                  Last Updated: April 4, 2026
                </span>
              </div>
              <div className="mt-4 flex justify-center space-x-4">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 text-lg">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-600 text-lg">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-pink-600 hover:text-pink-800 text-lg">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-blue-700 hover:text-blue-900 text-lg">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="https://wa.me/2347038562100" target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-800 text-lg">
                  <i className="fab fa-whatsapp"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
