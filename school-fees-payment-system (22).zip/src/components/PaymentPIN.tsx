import { useState } from 'react';

interface PaymentPINProps {
  onVerify: () => void;
  onCancel: () => void;
}

export default function PaymentPIN({ onVerify, onCancel }: PaymentPINProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attempts, setAttempts] = useState(0);

  // Default PIN if none set
  const DEFAULT_PIN = '8562';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    await new Promise(resolve => setTimeout(resolve, 400));

    const storedPIN = localStorage.getItem('paymentPIN') || DEFAULT_PIN;

    if (pin === storedPIN) {
      // Success
      setPin('');
      setAttempts(0);
      onVerify();
    } else {
      // Failed
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setPin('');

      if (newAttempts >= 5) {
        setError('Too many failed attempts. Please contact admin at 0703 856 2100');
      } else {
        setError(`Incorrect PIN. ${5 - newAttempts} attempt${5 - newAttempts !== 1 ? 's' : ''} remaining.`);
      }

      // Log failed attempt
      const failedLog = JSON.parse(localStorage.getItem('pinFailedAttempts') || '[]');
      failedLog.push({ timestamp: new Date().toISOString() });
      localStorage.setItem('pinFailedAttempts', JSON.stringify(failedLog.slice(-20)));
    }

    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <div className="text-center mb-6">
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <i className="fas fa-shield-alt text-white text-3xl"></i>
          </div>
          <h3 className="text-xl font-bold text-gray-800">🔐 Payment Authorization</h3>
          <p className="text-gray-600 text-sm mt-2">Enter 4-digit PIN to authorize payment</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
              className="w-full border-2 border-gray-300 rounded-lg px-4 py-4 text-center text-3xl tracking-widest focus:border-blue-500 focus:outline-none font-mono"
              placeholder="••••"
              maxLength={4}
              inputMode="numeric"
              required
              autoFocus
              disabled={attempts >= 5}
            />
            <div className="flex justify-between mt-2">
              <p className="text-xs text-gray-500">4-digit PIN</p>
              <p className={`text-xs ${pin.length === 4 ? 'text-green-500' : 'text-gray-400'}`}>{pin.length}/4</p>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border-2 border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
              <i className="fas fa-exclamation-triangle mr-2"></i>
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={() => { setPin(''); onCancel(); }}
              className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || pin.length !== 4 || attempts >= 5}
              className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-purple-700 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <><i className="fas fa-circle-notch fa-spin mr-2"></i>Verifying...</>
              ) : (
                <><i className="fas fa-lock-open mr-2"></i>Authorize</>
              )}
            </button>
          </div>
        </form>

        <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-500 rounded-lg p-3">
          <p className="text-xs text-yellow-900">
            <i className="fas fa-user-shield mr-1"></i>
            Contact admin at <strong>0703 856 2100</strong> for PIN recovery.
          </p>
        </div>
      </div>
    </div>
  );
}
