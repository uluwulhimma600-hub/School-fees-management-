import React, { useState } from 'react';

interface CredentialManagementProps {
  currentUser: any;
}

export default function CredentialManagement({ currentUser }: CredentialManagementProps) {
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showChangePIN, setShowChangePIN] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Password form
  const [pwdCurrent, setPwdCurrent] = useState('');
  const [pwdNew, setPwdNew] = useState('');
  const [pwdConfirm, setPwdConfirm] = useState('');

  // PIN form
  const [pinPassword, setPinPassword] = useState('');
  const [pinNew, setPinNew] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [showPinPassword, setShowPinPassword] = useState(false);

  const DEFAULT_ADMIN_USERNAME = 'admin';
  const DEFAULT_ADMIN_PASSWORD = 'admin123';

  const getUsers = () => {
    const stored = localStorage.getItem('users');
    if (stored) return JSON.parse(stored);
    const defaultUser = {
      id: 1,
      username: DEFAULT_ADMIN_USERNAME,
      password: DEFAULT_ADMIN_PASSWORD,
      role: 'admin',
      name: 'Administrator',
      email: 'admin@school.com',
      phone: '07038562100',
      createdAt: new Date().toISOString(),
      isActive: true
    };
    localStorage.setItem('users', JSON.stringify([defaultUser]));
    return [defaultUser];
  };

  const resetPasswordForm = () => {
    setPwdCurrent('');
    setPwdNew('');
    setPwdConfirm('');
    setError('');
    setShowChangePassword(false);
  };

  const resetPINForm = () => {
    setPinPassword('');
    setPinNew('');
    setPinConfirm('');
    setShowPinPassword(false);
    setError('');
    setShowChangePIN(false);
  };

  // ========== CHANGE PASSWORD ==========
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const users = getUsers();
    const user = users.find((u: any) => u.username === currentUser.username);

    if (!user) {
      setError('User not found');
      return;
    }

    if (pwdCurrent !== user.password) {
      setError('Current password is incorrect');
      return;
    }

    if (pwdNew.length < 6) {
      setError('New password must be at least 6 characters');
      return;
    }

    if (pwdNew !== pwdConfirm) {
      setError('New password and confirmation do not match');
      return;
    }

    if (pwdNew === pwdCurrent) {
      setError('New password must be different from current password');
      return;
    }

    // Update password in users list
    const updatedUsers = users.map((u: any) =>
      u.username === currentUser.username ? { ...u, password: pwdNew } : u
    );
    localStorage.setItem('users', JSON.stringify(updatedUsers));

    // Log change
    const log = JSON.parse(localStorage.getItem('credentialChangeLog') || '[]');
    log.push({ timestamp: new Date().toISOString(), username: currentUser.username, type: 'password' });
    localStorage.setItem('credentialChangeLog', JSON.stringify(log.slice(-20)));

    setSuccess('✅ Password changed successfully!');
    resetPasswordForm();
  };

  // ========== CHANGE PIN ==========
  const handleChangePIN = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Step 1: Verify user password
    const users = getUsers();
    const user = users.find((u: any) => u.username === currentUser.username);

    if (!user) {
      setError('User not found');
      return;
    }

    if (pinPassword !== user.password) {
      setError('Password is incorrect. You must enter your login password to change PIN.');
      return;
    }

    // Step 2: Validate new PIN
    if (pinNew.length !== 4) {
      setError('PIN must be exactly 4 digits');
      return;
    }

    if (!/^\d{4}$/.test(pinNew)) {
      setError('PIN must contain only numbers (0-9)');
      return;
    }

    if (pinNew !== pinConfirm) {
      setError('New PIN and confirmation do not match');
      return;
    }

    // Step 3: Check if same as current PIN
    const currentPIN = localStorage.getItem('paymentPIN') || '8562';
    if (pinNew === currentPIN) {
      setError('New PIN must be different from current PIN');
      return;
    }

    // Step 4: Save new PIN
    localStorage.setItem('paymentPIN', pinNew);

    // Log change
    const log = JSON.parse(localStorage.getItem('credentialChangeLog') || '[]');
    log.push({ timestamp: new Date().toISOString(), username: currentUser.username, type: 'pin' });
    localStorage.setItem('credentialChangeLog', JSON.stringify(log.slice(-20)));

    setSuccess('✅ Payment PIN changed successfully! New PIN: ' + pinNew.replace(/./g, '•'));
    resetPINForm();
  };

  return (
    <div className="space-y-6">
      {/* Success Message */}
      {success && (
        <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center">
            <i className="fas fa-check-circle text-green-600 text-xl mr-3"></i>
            <span className="text-green-800 font-medium">{success}</span>
          </div>
          <button onClick={() => setSuccess('')} className="text-green-600 hover:text-green-800">
            <i className="fas fa-times"></i>
          </button>
        </div>
      )}

      {/* Change Password Card */}
      <div className="bg-white border-2 border-blue-200 rounded-lg p-4">
        <div className="flex justify-between items-center mb-3">
          <h4 className="font-bold text-gray-800">
            <i className="fas fa-key text-blue-600 mr-2"></i>
            Change Password
          </h4>
          <button
            onClick={() => {
              setShowChangePassword(true);
              setShowChangePIN(false);
              setError('');
              setSuccess('');
            }}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
          >
            <i className="fas fa-edit mr-1"></i>Update
          </button>
        </div>
        <p className="text-sm text-gray-600">
          Update your login password. You must enter your current password first.
        </p>
      </div>

      {/* Change PIN Card */}
      <div className="bg-white border-2 border-purple-200 rounded-lg p-4">
        <div className="flex justify-between items-center mb-3">
          <h4 className="font-bold text-gray-800">
            <i className="fas fa-lock text-purple-600 mr-2"></i>
            Change Payment PIN
          </h4>
          <button
            onClick={() => {
              setShowChangePIN(true);
              setShowChangePassword(false);
              setError('');
              setSuccess('');
            }}
            className="text-purple-600 hover:text-purple-800 text-sm font-medium"
          >
            <i className="fas fa-edit mr-1"></i>Update
          </button>
        </div>
        <p className="text-sm text-gray-600">
          Update the 4-digit payment PIN. Enter your login password to verify identity.
        </p>
        <div className="mt-3 bg-purple-50 border-l-4 border-purple-500 p-3">
          <p className="text-xs text-purple-900">
            <i className="fas fa-info-circle mr-1"></i>
            <strong>Default PIN:</strong> Contact admin at <strong>0703 856 2100</strong>
          </p>
        </div>
      </div>

      {/* Activity Log */}
      <ActivityLog currentUser={currentUser} />

      {/* ===== CHANGE PASSWORD MODAL ===== */}
      {showChangePassword && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-800">
                <i className="fas fa-key text-blue-600 mr-2"></i>
                Change Password
              </h3>
              <button onClick={resetPasswordForm} className="text-gray-400 hover:text-gray-600">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center">
                <i className="fas fa-exclamation-circle mr-2"></i>
                <span className="text-sm">{error}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Current Password *</label>
                <input
                  type="password"
                  value={pwdCurrent}
                  onChange={(e) => setPwdCurrent(e.target.value)}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-2 focus:border-blue-500 focus:outline-none"
                  placeholder="Enter current password"
                  required
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">New Password *</label>
                <input
                  type="password"
                  value={pwdNew}
                  onChange={(e) => setPwdNew(e.target.value)}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-2 focus:border-blue-500 focus:outline-none"
                  placeholder="Minimum 6 characters"
                  required
                  minLength={6}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password *</label>
                <input
                  type="password"
                  value={pwdConfirm}
                  onChange={(e) => setPwdConfirm(e.target.value)}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-2 focus:border-blue-500 focus:outline-none"
                  placeholder="Re-enter new password"
                  required
                />
                {pwdNew && pwdConfirm && pwdNew !== pwdConfirm && (
                  <p className="text-xs text-red-500 mt-1"><i className="fas fa-times-circle mr-1"></i>Passwords do not match</p>
                )}
                {pwdNew && pwdConfirm && pwdNew === pwdConfirm && (
                  <p className="text-xs text-green-500 mt-1"><i className="fas fa-check-circle mr-1"></i>Passwords match</p>
                )}
              </div>
              <div className="flex space-x-3 pt-2">
                <button type="button" onClick={resetPasswordForm} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!pwdCurrent || !pwdNew || !pwdConfirm || pwdNew !== pwdConfirm}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-save mr-1"></i>Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===== CHANGE PIN MODAL ===== */}
      {showChangePIN && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-800">
                <i className="fas fa-lock text-purple-600 mr-2"></i>
                Change Payment PIN
              </h3>
              <button onClick={resetPINForm} className="text-gray-400 hover:text-gray-600">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <p className="text-xs text-blue-800">
                <i className="fas fa-shield-alt mr-1"></i>
                <strong>Security:</strong> Enter your login password to verify your identity before changing PIN.
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center">
                <i className="fas fa-exclamation-circle mr-2"></i>
                <span className="text-sm">{error}</span>
              </div>
            )}

            <form onSubmit={handleChangePIN} className="space-y-4">
              {/* Step 1: Verify Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <i className="fas fa-key text-blue-600 mr-1"></i>
                  Your Login Password *
                </label>
                <div className="relative">
                  <input
                    type={showPinPassword ? 'text' : 'password'}
                    value={pinPassword}
                    onChange={(e) => setPinPassword(e.target.value)}
                    className="w-full border-2 border-gray-300 rounded-lg px-4 py-2 focus:border-purple-500 focus:outline-none pr-10"
                    placeholder="Enter your login password"
                    required
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPinPassword(!showPinPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <i className={`fas ${showPinPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
              </div>

              {/* Step 2: New PIN */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <i className="fas fa-lock text-purple-600 mr-1"></i>
                  New PIN (4 Digits) *
                </label>
                <input
                  type="password"
                  value={pinNew}
                  onChange={(e) => setPinNew(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-center text-2xl tracking-widest focus:border-purple-500 focus:outline-none font-mono"
                  placeholder="••••"
                  maxLength={4}
                  inputMode="numeric"
                  required
                />
                <div className="flex justify-between mt-1">
                  <p className="text-xs text-gray-500">Must be 4 digits (0-9)</p>
                  <p className={`text-xs ${pinNew.length === 4 ? 'text-green-500' : 'text-gray-400'}`}>
                    {pinNew.length}/4
                  </p>
                </div>
              </div>

              {/* Step 3: Confirm PIN */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <i className="fas fa-check-circle text-purple-600 mr-1"></i>
                  Confirm New PIN *
                </label>
                <input
                  type="password"
                  value={pinConfirm}
                  onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-center text-2xl tracking-widest focus:border-purple-500 focus:outline-none font-mono"
                  placeholder="••••"
                  maxLength={4}
                  inputMode="numeric"
                  required
                />
                {pinNew && pinConfirm && pinNew !== pinConfirm && (
                  <p className="text-xs text-red-500 mt-1"><i className="fas fa-times-circle mr-1"></i>PINs do not match</p>
                )}
                {pinNew.length === 4 && pinConfirm.length === 4 && pinNew === pinConfirm && (
                  <p className="text-xs text-green-500 mt-1"><i className="fas fa-check-circle mr-1"></i>PINs match ✓</p>
                )}
              </div>

              <div className="flex space-x-3 pt-2">
                <button type="button" onClick={resetPINForm} className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!pinPassword || pinNew.length !== 4 || pinConfirm.length !== 4 || pinNew !== pinConfirm}
                  className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                >
                  <i className="fas fa-save mr-2"></i>Update PIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Activity Log
function ActivityLog({ currentUser }: { currentUser: any }) {
  const [logs] = useState<any[]>(() => {
    const stored = localStorage.getItem('credentialChangeLog');
    return stored ? JSON.parse(stored) : [];
  });

  const userLogs = logs.filter(log => log.username === currentUser.username);
  if (userLogs.length === 0) return null;

  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h4 className="font-bold text-gray-800 mb-3">
        <i className="fas fa-history mr-2"></i>
        Recent Changes
      </h4>
      <div className="space-y-2 max-h-40 overflow-y-auto">
        {userLogs.slice(-5).reverse().map((log, idx) => (
          <div key={idx} className="text-xs flex justify-between items-center py-2 border-b border-gray-200">
            <span className="text-gray-600">
              <i className={`fas mr-1 ${log.type === 'password' ? 'fa-key text-blue-600' : 'fa-lock text-purple-600'}`}></i>
              {log.type === 'password' ? 'Password' : 'Payment PIN'} changed
            </span>
            <span className="text-gray-500">
              {new Date(log.timestamp).toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
