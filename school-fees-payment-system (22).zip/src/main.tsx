import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// Register Service Worker for OFFLINE support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then((reg) => {
        console.log('[APP] Service Worker registered - app works offline!');

        // Check for updates
        reg.addEventListener('updatefound', () => {
          const worker = reg.installing;
          if (!worker) return;
          worker.addEventListener('statechange', () => {
            if (worker.state === 'installed' && navigator.serviceWorker.controller) {
              // New version available
              console.log('[APP] New version available');
            } else if (worker.state === 'installed') {
              // First install - app now works offline
              console.log('[APP] App cached - works offline now!');
            }
          });
        });
      })
      .catch((err) => console.log('[APP] SW registration failed:', err));
  });
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
