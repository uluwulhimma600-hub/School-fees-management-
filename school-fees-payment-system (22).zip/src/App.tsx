import React, { useState, useEffect, useMemo } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { dbSaveAll, dbGetAll, dbSaveSettings, dbGetSettings, dbClearAll, dbGetSize, migrateFromLocalStorage, requestPersistentStorage, getStorageQuota, STORES } from './db';
import LoginPage from './components/LoginPage';
import DeveloperInfo from './components/DeveloperInfo';

import FeeStructureInline from './components/FeeStructureInline';
import CredentialManagement from './components/CredentialManagement';
import PaymentPIN from './components/PaymentPIN';
import PaymentHistory from './components/PaymentHistory';
import ClassPromotion from './components/ClassPromotion';

// Types
interface Student {
  id: number;
  name: string;
  class: string;
  admissionNumber: string;
  term: string;
  totalFee: number;
  parentPhone: string;
  passport?: string;
}

interface Payment {
  id: number;
  studentId: number;
  term: string;
  amountPaid: number;
  totalFee: number;
  balance: number;
  date: string;
}

interface Settings {
  schoolName: string;
  schoolAddress: string;
  signature: string | null;
  logo: string | null;
  receiptFontSize: number;
  themeColor: string;
}

// Class options
const CLASS_OPTIONS = [
  'Nursery 1', 'Nursery 2', 'Nursery 3',
  'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6',
  'JSS1', 'JSS2', 'JSS3',
  'SS1', 'SS2', 'SS3'
];

const TERM_OPTIONS = ['1st', '2nd', '3rd'];

// Initial mock data
const initialStudents: Student[] = [
  { id: 1, name: "John Doe", class: "JSS1", admissionNumber: "ADM001", term: "1st", totalFee: 50000, parentPhone: "08012345678", passport: '' },
  { id: 2, name: "Jane Smith", class: "SS2", admissionNumber: "ADM002", term: "2nd", totalFee: 65000, parentPhone: "08023456789", passport: '' },
  { id: 3, name: "Mike Johnson", class: "JSS3", admissionNumber: "ADM003", term: "1st", totalFee: 55000, parentPhone: "08034567890", passport: '' },
];

const initialPayments: Payment[] = [];

const initialSettings: Settings = {
  schoolName: "School Name",
  schoolAddress: "School Address",
  signature: null,
  logo: null,
  receiptFontSize: 14,
  themeColor: 'teal'
};

// Helper functions
const exportToCSV = (data: any[][], filename: string) => {
  const csvContent = "data:text/csv;charset=utf-8," + 
    data.map(row => row.map(cell => `"${cell}"`).join(",")).join("\n");
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const getStudentBalance = (studentId: number, term: string, students: Student[], payments: Payment[]): number => {
  const student = students.find(s => s.id === studentId);
  if (!student) return 0;
  const termPayments = payments.filter(p => p.studentId === studentId && p.term === term);
  const totalPaid = termPayments.reduce((sum, p) => sum + p.amountPaid, 0);
  return student.totalFee - totalPaid;
};

// Theme color mapping
const THEME_COLORS: Record<string, { nav: string; navActive: string; navHover: string; select: string }> = {
  teal:    { nav: 'bg-teal-700',    navActive: 'bg-teal-900',    navHover: 'hover:bg-teal-800',    select: 'bg-teal-800' },
  blue:    { nav: 'bg-blue-700',    navActive: 'bg-blue-900',    navHover: 'hover:bg-blue-800',    select: 'bg-blue-800' },
  green:   { nav: 'bg-green-700',   navActive: 'bg-green-900',   navHover: 'hover:bg-green-800',   select: 'bg-green-800' },
  purple:  { nav: 'bg-purple-700',  navActive: 'bg-purple-900',  navHover: 'hover:bg-purple-800',  select: 'bg-purple-800' },
  red:     { nav: 'bg-red-700',     navActive: 'bg-red-900',     navHover: 'hover:bg-red-800',     select: 'bg-red-800' },
  orange:  { nav: 'bg-orange-700',  navActive: 'bg-orange-900',  navHover: 'hover:bg-orange-800',  select: 'bg-orange-800' },
  pink:    { nav: 'bg-pink-700',    navActive: 'bg-pink-900',    navHover: 'hover:bg-pink-800',    select: 'bg-pink-800' },
  indigo:  { nav: 'bg-indigo-700',  navActive: 'bg-indigo-900',  navHover: 'hover:bg-indigo-800',  select: 'bg-indigo-800' },
  cyan:    { nav: 'bg-cyan-700',    navActive: 'bg-cyan-900',    navHover: 'hover:bg-cyan-800',    select: 'bg-cyan-800' },
  amber:   { nav: 'bg-amber-700',   navActive: 'bg-amber-900',   navHover: 'hover:bg-amber-800',   select: 'bg-amber-800' },
  lime:    { nav: 'bg-lime-700',    navActive: 'bg-lime-900',    navHover: 'hover:bg-lime-800',    select: 'bg-lime-800' },
  emerald: { nav: 'bg-emerald-700', navActive: 'bg-emerald-900', navHover: 'hover:bg-emerald-800', select: 'bg-emerald-800' },
  sky:     { nav: 'bg-sky-700',     navActive: 'bg-sky-900',     navHover: 'hover:bg-sky-800',     select: 'bg-sky-800' },
  violet:  { nav: 'bg-violet-700',  navActive: 'bg-violet-900',  navHover: 'hover:bg-violet-800',  select: 'bg-violet-800' },
  rose:    { nav: 'bg-rose-700',    navActive: 'bg-rose-900',    navHover: 'hover:bg-rose-800',    select: 'bg-rose-800' },
  fuchsia: { nav: 'bg-fuchsia-700', navActive: 'bg-fuchsia-900', navHover: 'hover:bg-fuchsia-800', select: 'bg-fuchsia-800' },
  slate:   { nav: 'bg-slate-700',   navActive: 'bg-slate-900',   navHover: 'hover:bg-slate-800',   select: 'bg-slate-800' },
  zinc:    { nav: 'bg-zinc-700',    navActive: 'bg-zinc-900',    navHover: 'hover:bg-zinc-800',    select: 'bg-zinc-800' },
  stone:   { nav: 'bg-stone-700',   navActive: 'bg-stone-900',   navHover: 'hover:bg-stone-800',   select: 'bg-stone-800' },
  gray:    { nav: 'bg-gray-700',    navActive: 'bg-gray-900',    navHover: 'hover:bg-gray-800',    select: 'bg-gray-800' },
};

// Navigation Component
function Navigation({ currentView, setCurrentView, themeColor }: { currentView: string; setCurrentView: (view: string) => void; themeColor: string }) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line' },
    { id: 'students', label: 'Students', icon: 'fa-users' },
    { id: 'payments', label: 'Payments', icon: 'fa-money-bill-wave' },
    { id: 'history', label: 'History', icon: 'fa-history' },
    { id: 'reports', label: 'Reports', icon: 'fa-file-alt' },
    { id: 'settings', label: 'Settings', icon: 'fa-cog' },
  ];

  const t = THEME_COLORS[themeColor] || THEME_COLORS.teal;

  return (
    <nav className={`${t.nav} text-white shadow-lg sticky top-0 z-40`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <i className="fas fa-school text-2xl"></i>
            <span className="font-bold text-xl">School Fees Management</span>
          </div>
          <div className="hidden md:flex space-x-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`px-4 py-2 rounded-lg transition-all ${currentView === item.id ? t.navActive : t.navHover}`}
              >
                <i className={`fas ${item.icon} mr-2`}></i>
                {item.label}
              </button>
            ))}
          </div>
          <div className="md:hidden">
            <select 
              value={currentView}
              onChange={(e) => setCurrentView(e.target.value)}
              className={`${t.select} text-white rounded px-3 py-1`}
            >
              {navItems.map(item => (
                <option key={item.id} value={item.id}>{item.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </nav>
  );
}

// Dashboard Component
function Dashboard({ students, payments, settings }: { students: Student[]; payments: Payment[]; settings: Settings }) {
  const today = new Date().toDateString();
  const todayPayments = payments.filter(p => new Date(p.date).toDateString() === today);
  const todayCollection = todayPayments.reduce((sum, p) => sum + p.amountPaid, 0);
  const totalCollection = payments.reduce((sum, p) => sum + p.amountPaid, 0);

  const classStats = useMemo(() => {
    const stats: Record<string, number> = {};
    students.forEach(student => {
      const classPayments = payments.filter(p => {
        const pStudent = students.find(s => s.id === p.studentId);
        return pStudent && pStudent.class === student.class;
      });
      const total = classPayments.reduce((sum, p) => sum + p.amountPaid, 0);
      stats[student.class] = (stats[student.class] || 0) + total;
    });
    return stats;
  }, [students, payments]);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{settings.schoolName}</h1>
        <p className="text-gray-600">Fees Management Dashboard</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          title="Today's Collection" 
          value={`₦${todayCollection.toLocaleString()}`}
          icon="fa-calendar-day"
          color="bg-green-500"
        />
        <StatCard 
          title="Total Collection (All Term)" 
          value={`₦${totalCollection.toLocaleString()}`}
          icon="fa-money-bill-wave"
          color="bg-green-600"
        />
        <StatCard 
          title="Total Students" 
          value={students.length}
          icon="fa-users"
          color="bg-purple-500"
        />
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4">Collection by Class</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {Object.entries(classStats).map(([className, amount]) => (
            <div key={className} className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">₦{amount.toLocaleString()}</div>
              <div className="text-sm text-gray-600">{className}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4">Recent Payments</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-3">Student</th>
                <th className="p-3">Class</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {payments.slice(-5).reverse().map(payment => {
                const student = students.find(s => s.id === payment.studentId);
                return (
                  <tr key={payment.id} className="border-b">
                    <td className="p-3">{student?.name}</td>
                    <td className="p-3">{student?.class}</td>
                    <td className="p-3">₦{payment.amountPaid.toLocaleString()}</td>
                    <td className="p-3">{new Date(payment.date).toLocaleDateString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, color }: { title: string; value: string | number; icon: string; color: string }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 flex items-center space-x-4">
      <div className={`${color} text-white p-4 rounded-full`}>
        <i className={`fas ${icon} text-2xl`}></i>
      </div>
      <div>
        <p className="text-gray-600 text-sm">{title}</p>
        <p className="text-2xl font-bold text-gray-800">{value}</p>
      </div>
    </div>
  );
}

// Student Management Component
function StudentManagement({ students, setStudents, payments, feeStructures }: { 
  students: Student[]; 
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>; 
  payments: Payment[];
  feeStructures: any[];
}) {
  const [showForm, setShowForm] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    class: 'Nursery 1',
    admissionNumber: '',
    term: '1st',
    totalFee: '',
    parentPhone: '',
    passport: ''
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [showCamera, setShowCamera] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('environment');
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  // Auto-fill fee based on class and term
  useEffect(() => {
    if (formData.class && formData.term && !editingStudent) {
      const currentSession = new Date().getFullYear().toString();
      const feeStructure = feeStructures.find(
        f => f.class === formData.class && f.term === formData.term && f.session === currentSession
      );
      if (feeStructure) {
        setFormData(prev => ({ ...prev, totalFee: feeStructure.amount.toString() }));
      }
    }
  }, [formData.class, formData.term, editingStudent, feeStructures]);

  // Generate admission number automatically
  const generateAdmissionNumber = () => {
    const year = new Date().getFullYear().toString().slice(-2);
    const count = students.length + 1;
    return `ADM/${year}/${count.toString().padStart(4, '0')}`;
  };

  // Handle passport upload
  const handlePassportUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Image too large! Maximum 2MB allowed.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, passport: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Start camera with specified facing mode
  const openCamera = async (facing: 'user' | 'environment') => {
    // Stop existing camera first
    if (videoRef.current) {
      const oldStream = videoRef.current.srcObject as MediaStream;
      oldStream?.getTracks().forEach(track => track.stop());
    }
    setCameraFacing(facing);
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: facing, width: { ideal: 640 }, height: { ideal: 640 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      alert('Camera access denied or not available.');
      setShowCamera(false);
    }
  };

  // Switch between front and back camera
  const switchCamera = async () => {
    const newFacing = cameraFacing === 'user' ? 'environment' : 'user';
    await openCamera(newFacing);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      canvasRef.current.width = 400;
      canvasRef.current.height = 400;
      if (ctx) {
        // If front camera, flip horizontally for natural mirror look
        if (cameraFacing === 'user') {
          ctx.translate(400, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(videoRef.current, 0, 0, 400, 400);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.85);
        setFormData(prev => ({ ...prev, passport: dataUrl }));
      }
      const stream = videoRef.current.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      setShowCamera(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
    }
    setShowCamera(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const admissionNumber = editingStudent ? formData.admissionNumber : generateAdmissionNumber();
    if (editingStudent) {
      setStudents(students.map(s => s.id === editingStudent.id ? { ...s, ...formData, admissionNumber, totalFee: parseFloat(formData.totalFee) } : s));
    } else {
      const newStudent: Student = {
        id: Date.now(),
        ...formData,
        admissionNumber,
        totalFee: parseFloat(formData.totalFee)
      };
      setStudents([...students, newStudent]);
    }
    setShowForm(false);
    setEditingStudent(null);
    setFormData({ name: '', class: 'Nursery 1', admissionNumber: '', term: '1st', totalFee: '', parentPhone: '', passport: '' });
  };

  const handleEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      class: student.class,
      admissionNumber: student.admissionNumber,
      term: student.term,
      totalFee: student.totalFee.toString(),
      parentPhone: student.parentPhone,
      passport: student.passport || ''
    });
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this student?')) {
      setStudents(students.filter(s => s.id !== id));
    }
  };

  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           student.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           student.parentPhone.includes(searchTerm);
      const matchesClass = !filterClass || student.class === filterClass;
      return matchesSearch && matchesClass;
    });
  }, [students, searchTerm, filterClass]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Student Management</h2>
        <button 
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <i className="fas fa-plus mr-2"></i>Add Student
        </button>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-md p-4 flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search by name, admission number, or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
          />
        </div>
        <div className="md:w-48">
          <select
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
          >
            <option value="">All Classes</option>
            {CLASS_OPTIONS.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-screen overflow-y-auto">
            <div className="p-6">
              {/* Header */}
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-800">
                    <i className={`fas ${editingStudent ? 'fa-user-edit text-blue-600' : 'fa-user-plus text-green-600'} mr-2`}></i>
                    {editingStudent ? 'Edit Student' : 'Add New Student'}
                  </h3>
                  {editingStudent && (
                    <p className="text-sm text-gray-500 mt-1">Updating: {editingStudent.name}</p>
                  )}
                </div>
                <button
                  onClick={() => {setShowForm(false); setEditingStudent(null);}}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Passport Photo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <i className="fas fa-camera mr-1 text-blue-600"></i> Student Passport Photo
                  </label>
                  <div className="flex items-center space-x-4">
                    {/* Preview */}
                    <div className="w-24 h-24 rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden bg-gray-50 shrink-0">
                      {formData.passport ? (
                        <img src={formData.passport} alt="Passport" className="w-full h-full object-cover" />
                      ) : (
                        <i className="fas fa-user text-4xl text-gray-300"></i>
                      )}
                    </div>
                    <div className="flex flex-col space-y-2 flex-1">
                      {/* Upload Button */}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePassportUpload}
                        className="hidden"
                        id="passport-upload"
                      />
                      <label
                        htmlFor="passport-upload"
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium cursor-pointer text-center"
                      >
                        <i className="fas fa-upload mr-2"></i>Upload Photo
                      </label>
                      {/* Camera Buttons */}
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => openCamera('environment')}
                          className="flex-1 bg-purple-600 text-white px-3 py-2 rounded-lg hover:bg-purple-700 text-sm font-medium"
                        >
                          <i className="fas fa-camera mr-1"></i>Back
                        </button>
                        <button
                          type="button"
                          onClick={() => openCamera('user')}
                          className="flex-1 bg-indigo-600 text-white px-3 py-2 rounded-lg hover:bg-indigo-700 text-sm font-medium"
                        >
                          <i className="fas fa-user-circle mr-1"></i>Front
                        </button>
                      </div>
                      {/* Remove Button */}
                      {formData.passport && (
                        <button
                          type="button"
                          onClick={() => setFormData({...formData, passport: ''})}
                          className="bg-red-100 text-red-600 px-4 py-1 rounded-lg hover:bg-red-200 text-xs"
                        >
                          <i className="fas fa-trash mr-1"></i>Remove
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Camera Modal */}
                {showCamera && (
                  <div className="bg-gray-900 rounded-xl p-4">
                    <div className="relative">
                      <video 
                        ref={videoRef} 
                        className="w-full rounded-lg" 
                        autoPlay 
                        playsInline 
                        muted
                        style={{ transform: cameraFacing === 'user' ? 'scaleX(-1)' : 'none' }}
                      ></video>
                      {/* Camera indicator */}
                      <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-xs">
                        <i className={`fas ${cameraFacing === 'user' ? 'fa-user-circle' : 'fa-camera'} mr-1`}></i>
                        {cameraFacing === 'user' ? 'Front Camera' : 'Back Camera'}
                      </div>
                      {/* Switch camera button */}
                      <button
                        type="button"
                        onClick={switchCamera}
                        className="absolute top-2 right-2 bg-white bg-opacity-30 hover:bg-opacity-50 text-white p-2 rounded-full transition-all"
                      >
                        <i className="fas fa-sync-alt text-lg"></i>
                      </button>
                    </div>
                    <canvas ref={canvasRef} className="hidden"></canvas>
                    <div className="flex space-x-2 mt-3">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium"
                      >
                        <i className="fas fa-camera mr-2"></i>Capture
                      </button>
                      <button
                        type="button"
                        onClick={switchCamera}
                        className="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 font-medium"
                      >
                        <i className="fas fa-sync-alt mr-1"></i>Switch
                      </button>
                      <button
                        type="button"
                        onClick={stopCamera}
                        className="flex-1 bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 font-medium"
                      >
                        <i className="fas fa-times mr-2"></i>Cancel
                      </button>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <i className="fas fa-user mr-1 text-blue-600"></i> Full Name *
                  </label>
                  <input
                    type="text"
                    placeholder="Enter student's full name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg px-3 py-2 focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <i className="fas fa-chalkboard mr-1 text-blue-600"></i> Class *
                  </label>
                  <select
                    value={formData.class}
                    onChange={(e) => setFormData({...formData, class: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg px-3 py-2 focus:border-blue-500 focus:outline-none"
                  >
                    {CLASS_OPTIONS.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <i className="fas fa-calendar mr-1 text-blue-600"></i> Term *
                  </label>
                  <select
                    value={formData.term}
                    onChange={(e) => setFormData({...formData, term: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg px-3 py-2 focus:border-blue-500 focus:outline-none"
                  >
                    {TERM_OPTIONS.map(t => (
                      <option key={t} value={t}>{t} Term</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <i className="fas fa-money-bill mr-1 text-blue-600"></i> Total Fee (₦) *
                    {!editingStudent && formData.totalFee && (
                      <span className="text-green-600 ml-2 text-xs">
                        <i className="fas fa-check-circle mr-1"></i>Auto-filled from fee structure
                      </span>
                    )}
                  </label>
                  <input
                    type="number"
                    placeholder="e.g., 50000"
                    value={formData.totalFee}
                    onChange={(e) => setFormData({...formData, totalFee: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg px-3 py-2 focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <i className="fas fa-phone mr-1 text-blue-600"></i> Parent's Phone Number *
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g., 08012345678"
                    value={formData.parentPhone}
                    onChange={(e) => setFormData({...formData, parentPhone: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg px-3 py-2 focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
                <div className="flex space-x-2 pt-4">
                  <button type="submit" className={`flex-1 text-white py-3 rounded-lg font-semibold ${editingStudent ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700'}`}>
                    <i className={`fas ${editingStudent ? 'fa-save' : 'fa-plus-circle'} mr-2`}></i>
                    {editingStudent ? 'Update Student' : 'Add Student'}
                  </button>
                  <button 
                    type="button" 
                    onClick={() => {setShowForm(false); setEditingStudent(null);}}
                    className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden hidden md:block">
        <table className="w-full text-left">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4">Photo</th>
              <th className="p-4">Name</th>
              <th className="p-4">Class</th>
              <th className="p-4">Adm No.</th>
              <th className="p-4">Term</th>
              <th className="p-4">Total Fee</th>
              <th className="p-4">Parent Phone</th>
              <th className="p-4">Balance</th>
              <th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredStudents.map(student => {
              const balance = getStudentBalance(student.id, student.term, students, payments);
              return (
                <tr key={student.id} className="border-b hover:bg-gray-50">
                  <td className="p-4">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-100 border-2 border-blue-300">
                      {student.passport ? (
                        <img src={student.passport} alt={student.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          <i className="fas fa-user"></i>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="p-4 font-medium">{student.name}</td>
                  <td className="p-4">{student.class}</td>
                  <td className="p-4 text-xs">{student.admissionNumber}</td>
                  <td className="p-4">{student.term}</td>
                  <td className="p-4">₦{student.totalFee.toLocaleString()}</td>
                  <td className="p-4">{student.parentPhone}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-sm ${balance > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                      ₦{balance.toLocaleString()}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                      <button onClick={() => handleEdit(student)} className="bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 text-sm">
                        <i className="fas fa-edit mr-1"></i>Edit
                      </button>
                      <button onClick={() => handleDelete(student.id)} className="bg-red-600 text-white px-3 py-1.5 rounded-lg hover:bg-red-700 text-sm">
                        <i className="fas fa-trash mr-1"></i>Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-3">
        {filteredStudents.map(student => {
          const balance = getStudentBalance(student.id, student.term, students, payments);
          return (
            <div key={student.id} className="bg-white rounded-lg shadow-md p-4 border-l-4 border-blue-600">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-100 border-2 border-blue-300 shrink-0">
                    {student.passport ? (
                      <img src={student.passport} alt={student.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400">
                        <i className="fas fa-user text-xl"></i>
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="font-bold text-lg text-gray-800">{student.name}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs font-medium">{student.class}</span>
                      <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs font-medium">{student.term} Term</span>
                    </div>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-bold ${balance > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                  ₦{balance.toLocaleString()}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
                <div>
                  <i className="fas fa-money-bill mr-1 text-green-600"></i>
                  Fee: ₦{student.totalFee.toLocaleString()}
                </div>
                <div>
                  <i className="fas fa-phone mr-1 text-blue-600"></i>
                  {student.parentPhone}
                </div>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleEdit(student)} 
                  className="flex-1 bg-blue-600 text-white py-2.5 rounded-lg hover:bg-blue-700 font-medium text-sm"
                >
                  <i className="fas fa-edit mr-2"></i>Edit Student
                </button>
                <button 
                  onClick={() => handleDelete(student.id)} 
                  className="bg-red-600 text-white px-4 py-2.5 rounded-lg hover:bg-red-700"
                >
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredStudents.length === 0 && (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <i className="fas fa-users-slash text-5xl text-gray-300 mb-4"></i>
          <p className="text-gray-500">No students found</p>
        </div>
      )}
    </div>
  );
}

// Payment Module Component
function PaymentModule({ students, payments, setSelectedReceipt, onRequestPIN, setPendingPayment }: { 
  students: Student[]; 
  payments: Payment[]; 
  setSelectedReceipt: React.Dispatch<React.SetStateAction<Payment | null>>;
  onRequestPIN?: () => void;
  setPendingPayment?: (data: any) => void;
}) {
  const [selectedStudent, setSelectedStudent] = useState('');
  const [amount, setAmount] = useState('');
  const [term, setTerm] = useState('1st');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStudents = useMemo(() => {
    if (!searchTerm) return [];
    return students.filter(student => {
      const balance = getStudentBalance(student.id, term, students, payments);
      return (
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.class.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.parentPhone.includes(searchTerm)
      ) && balance > 0;
    });
  }, [students, searchTerm, term, payments]);

  const handleSelectStudent = (studentId: string) => {
    setSelectedStudent(studentId);
    const student = students.find(s => s.id === parseInt(studentId));
    if (student) {
      setSearchTerm(student.name);
    }
  };

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find(s => s.id === parseInt(selectedStudent));
    if (!student) {
      alert('Please search and select a student first!');
      return;
    }

    const currentBalance = getStudentBalance(student.id, term, students, payments);
    const paymentAmount = parseFloat(amount);

    if (paymentAmount > currentBalance) {
      alert('Payment amount exceeds outstanding balance!');
      return;
    }

    if (onRequestPIN && setPendingPayment) {
      setPendingPayment({
        studentId: student.id,
        term: term,
        amount: paymentAmount,
        totalFee: student.totalFee,
        balance: currentBalance
      });
      onRequestPIN();
    }
  };

  const selectedStudentData = students.find(s => s.id === parseInt(selectedStudent));
  const currentBalance = selectedStudentData ? getStudentBalance(selectedStudentData.id, term, students, payments) : 0;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Record Payment</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handlePayment} className="space-y-4">
            {/* Search Student */}
            <div className="relative">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <i className="fas fa-search mr-1 text-blue-600"></i>
                Search Student
              </label>
              <input
                type="text"
                placeholder="Type student name, class, or admission no..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  if (!e.target.value) setSelectedStudent('');
                }}
                className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 focus:border-blue-500 focus:outline-none text-lg"
                autoFocus
              />
              {searchTerm && !selectedStudent && filteredStudents.length > 0 && (
                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border-2 border-blue-300 rounded-lg shadow-xl max-h-72 overflow-y-auto">
                  {filteredStudents.map(student => {
                    const balance = getStudentBalance(student.id, term, students, payments);
                    return (
                      <button
                        key={student.id}
                        type="button"
                        onClick={() => handleSelectStudent(student.id.toString())}
                        className="w-full text-left px-4 py-3 hover:bg-blue-50 border-b last:border-b-0 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-100 border-2 border-blue-300 shrink-0">
                            {student.passport ? (
                              <img src={student.passport} alt={student.name} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-gray-400">
                                <i className="fas fa-user"></i>
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="font-bold text-gray-800">{student.name}</p>
                            <p className="text-sm text-gray-600">{student.class} • {student.admissionNumber}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-red-600">₦{balance.toLocaleString()}</p>
                            <p className="text-xs text-gray-500">Balance</p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
              {searchTerm && !selectedStudent && filteredStudents.length === 0 && (
                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border-2 border-gray-300 rounded-lg shadow-xl p-4 text-center text-gray-500">
                  <i className="fas fa-search text-2xl mb-2"></i>
                  <p className="text-sm">No student found with outstanding balance</p>
                </div>
              )}
            </div>

            {/* Selected Student Info */}
            {selectedStudentData && (
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border-2 border-blue-200">
                <div className="flex items-start space-x-4">
                  {/* Passport Photo */}
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-white border-2 border-blue-400 shadow-md shrink-0">
                    {selectedStudentData.passport ? (
                      <img src={selectedStudentData.passport} alt={selectedStudentData.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50">
                        <i className="fas fa-user text-3xl"></i>
                      </div>
                    )}
                  </div>
                  {/* Student Details */}
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-bold text-lg text-gray-800">{selectedStudentData.name}</p>
                        <p className="text-sm text-gray-600">{selectedStudentData.class} • {selectedStudentData.admissionNumber}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          <i className="fas fa-phone mr-1"></i>{selectedStudentData.parentPhone}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => { setSelectedStudent(''); setSearchTerm(''); }}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-3 bg-white rounded-lg p-3 text-center">
                  <p className="text-xs text-gray-500">Outstanding Balance</p>
                  <p className="text-3xl font-bold text-blue-600">₦{currentBalance.toLocaleString()}</p>
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Term</label>
              <select
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                className="w-full border rounded-lg px-3 py-2"
              >
                {TERM_OPTIONS.map(t => (
                  <option key={t} value={t}>{t} Term</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount Paid (₦)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-lg focus:border-green-500 focus:outline-none"
                placeholder="Enter amount"
                required
                min="1"
              />
            </div>

            <button 
              type="submit" 
              disabled={!selectedStudent}
              className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="fas fa-check-circle mr-2"></i>
              Record Payment & Generate Receipt
            </button>
          </form>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold mb-4">Recent Transactions</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {payments.slice(-10).reverse().map(payment => {
              const student = students.find(s => s.id === payment.studentId);
              return (
                <div 
                  key={payment.id} 
                  className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedReceipt(payment)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold">{student?.name}</p>
                      <p className="text-sm text-gray-600">{student?.class} - {payment.term} Term</p>
                      <p className="text-xs text-gray-500">{new Date(payment.date).toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">₦{payment.amountPaid.toLocaleString()}</p>
                      <p className="text-xs text-gray-600">Bal: ₦{payment.balance.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// Receipt Modal Component
function ReceiptModal({ receipt, settings, student, onClose, onPrint, onPrintBluetooth, onExportPDF }: { 
  receipt: Payment; 
  settings: Settings; 
  student: Student | undefined; 
  onClose: () => void;
  onPrint: () => void;
  onPrintBluetooth: () => void;
  onExportPDF: () => void;
}) {
  if (!student) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
        <div className="p-6 no-print">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold">Payment Receipt</h3>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
            <button onClick={onPrint} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
              <i className="fas fa-print mr-2"></i>Print
            </button>
            <button onClick={onPrintBluetooth} className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
              <i className="fab fa-bluetooth-b mr-2"></i>Bluetooth Print
            </button>
            <button onClick={onExportPDF} className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
              <i className="fas fa-image mr-2"></i>Save as Image
            </button>
          </div>
        </div>

        <div className="receipt-print mx-auto bg-white" style={{ fontFamily: "'Segoe UI', 'Arial', sans-serif", maxWidth: '320px' }}>
          {/* Top Border */}
          <div className="bg-gray-800 h-2"></div>
          
          {/* Header */}
          <div className="text-center py-4 px-4 border-b-2 border-gray-800">
            {settings.logo && (
              <div className="mb-3">
                <img src={settings.logo} alt="School Logo" className="h-20 w-20 mx-auto object-contain" />
              </div>
            )}
            <h2 className="font-bold uppercase tracking-wide text-gray-900" style={{ fontSize: `${settings.receiptFontSize + 4}px` }}>
              {settings.schoolName}
            </h2>
            <p className="text-gray-600 mt-1" style={{ fontSize: `${settings.receiptFontSize - 1}px` }}>
              {settings.schoolAddress}
            </p>
            <div className="mt-2 bg-gray-800 text-white py-1 px-3 inline-block rounded text-xs font-bold tracking-widest uppercase">
              Payment Receipt
            </div>
          </div>

          {/* Receipt Info */}
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-300">
            <div className="flex justify-between" style={{ fontSize: `${settings.receiptFontSize}px` }}>
              <span className="text-gray-500">Receipt No</span>
              <span className="font-bold text-gray-800">#{receipt.id.toString().padStart(6, '0')}</span>
            </div>
            <div className="flex justify-between mt-1" style={{ fontSize: `${settings.receiptFontSize}px` }}>
              <span className="text-gray-500">Date & Time</span>
              <span className="font-bold text-gray-800">{new Date(receipt.date).toLocaleDateString()} {new Date(receipt.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
            </div>
          </div>

          {/* Student Details */}
          <div className="px-4 py-3 border-b border-gray-300">
            <p className="text-xs text-gray-400 uppercase tracking-widest font-bold mb-2">Student Information</p>
            <table className="w-full" style={{ fontSize: `${settings.receiptFontSize}px` }}>
              <tbody>
                <tr>
                  <td className="text-gray-500 py-0.5 pr-2">Name</td>
                  <td className="font-bold text-gray-900 text-right">{student.name}</td>
                </tr>
                <tr>
                  <td className="text-gray-500 py-0.5 pr-2">Class</td>
                  <td className="font-bold text-gray-900 text-right">{student.class}</td>
                </tr>
                <tr>
                  <td className="text-gray-500 py-0.5 pr-2">Term</td>
                  <td className="font-bold text-gray-900 text-right">{receipt.term} Term</td>
                </tr>
                <tr>
                  <td className="text-gray-500 py-0.5 pr-2">Adm No</td>
                  <td className="font-bold text-gray-900 text-right">{student.admissionNumber}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Details */}
          <div className="px-4 py-3 border-b border-gray-300">
            <p className="text-xs text-gray-400 uppercase tracking-widest font-bold mb-2">Payment Details</p>
            <div className="flex justify-between items-center" style={{ fontSize: `${settings.receiptFontSize}px` }}>
              <span className="text-gray-500">Total Fee</span>
              <span className="font-bold text-gray-800">₦{receipt.totalFee.toLocaleString()}</span>
            </div>
            
            {/* Amount Paid - Highlighted */}
            <div className="bg-gray-800 text-white rounded-lg p-3 my-3 flex justify-between items-center">
              <span className="font-bold" style={{ fontSize: `${settings.receiptFontSize}px` }}>AMOUNT PAID</span>
              <span className="font-black" style={{ fontSize: `${settings.receiptFontSize + 6}px` }}>₦{receipt.amountPaid.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center" style={{ fontSize: `${settings.receiptFontSize}px` }}>
              <span className="text-gray-500">Balance</span>
              <span className={`font-bold ${receipt.balance === 0 ? 'text-green-600' : 'text-red-600'}`}>
                {receipt.balance === 0 ? '✓ FULLY PAID' : `₦${receipt.balance.toLocaleString()}`}
              </span>
            </div>
          </div>

          {/* Signature */}
          <div className="px-4 py-3 border-b border-gray-300 text-center">
            <p className="text-xs text-gray-400 uppercase tracking-widest font-bold mb-2">Authorized Signature</p>
            {settings.signature ? (
              <img src={settings.signature} alt="Signature" className="h-12 mx-auto object-contain" />
            ) : (
              <div className="h-10 border-b border-gray-400 w-40 mx-auto mt-4"></div>
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 text-center">
            <p className="text-gray-600 font-medium" style={{ fontSize: `${settings.receiptFontSize - 1}px` }}>
              Thank you for your payment!
            </p>
            <p className="text-gray-400 mt-1" style={{ fontSize: `${settings.receiptFontSize - 3}px` }}>
              This is a computer generated receipt
            </p>
          </div>

          {/* Bottom Border */}
          <div className="bg-gray-800 h-2"></div>
        </div>

        <div className="p-6 no-print">
          <button onClick={onClose} className="w-full bg-gray-200 text-gray-800 py-2 rounded hover:bg-gray-300">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

// Reports Component
function Reports({ students, payments, settings }: { students: Student[]; payments: Payment[]; settings: Settings }) {
  const [showSmsModal, setShowSmsModal] = useState(false);
  const [smsData, setSmsData] = useState<Array<{phone: string; message: string; studentName: string; class: string; balance: number}>>([]);
  const [currentSmsIndex, setCurrentSmsIndex] = useState(0);
  const [sentCount, setSentCount] = useState(0);
  const [showStudentExport, setShowStudentExport] = useState(false);
  const [exportSelectedClasses, setExportSelectedClasses] = useState<string[]>([]);
  const [exportType, setExportType] = useState<'names' | 'names-passport'>('names');
  const [deadlineDate, setDeadlineDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() + 14);
    return date.toISOString().split('T')[0];
  });
  
  const today = new Date().toDateString();
  const todayPayments = payments.filter(p => new Date(p.date).toDateString() === today);
  
  const unpaidStudents = useMemo(() => {
    return students.filter(student => {
      const balance = getStudentBalance(student.id, student.term, students, payments);
      return balance > 0;
    }).sort((a, b) => a.class.localeCompare(b.class));
  }, [students, payments]);

  const dailyReport = todayPayments.map(payment => {
    const student = students.find(s => s.id === payment.studentId);
    return {
      'Student Name': student?.name,
      'Class': student?.class,
      'Amount Paid': `₦${payment.amountPaid.toLocaleString()}`,
      'Time': new Date(payment.date).toLocaleTimeString()
    };
  });

  const exportUnpaidByClass = () => {
    const headers = ['Student Name', 'Class', 'Term', 'Outstanding Balance'];
    const csvData = [headers, ...unpaidStudents.map(s => [
      s.name,
      s.class,
      s.term,
      `₦${getStudentBalance(s.id, s.term, students, payments).toLocaleString()}`
    ])];
    exportToCSV(csvData, `unpaid_students_by_class_${new Date().toISOString().split('T')[0]}.csv`);
  };

  const exportDaily = () => {
    const headers = ['Student Name', 'Class', 'Amount Paid', 'Time'];
    const csvData = [headers, ...dailyReport.map(r => Object.values(r))];
    exportToCSV(csvData, `daily_collection_${new Date().toISOString().split('T')[0]}.csv`);
  };

  const sendBulkSMS = () => {
    if (unpaidStudents.length === 0) {
      alert('No unpaid students found! All students have cleared their fees.');
      return;
    }

    const unpaidWithDetails = unpaidStudents.map(student => {
      const balance = getStudentBalance(student.id, student.term, students, payments);
      return {
        phone: student.parentPhone,
        name: student.name,
        class: student.class,
        term: student.term,
        totalFee: student.totalFee,
        balance: balance
      };
    });

    const deadlineStr = new Date(deadlineDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

    const smsMessages = unpaidWithDetails.map(student => {
      const message = `Dear Parent/Guardian,

This is to kindly remind you that the school fees for your child, ${student.name}, in ${student.class} for the ${student.term} is due for payment.

- Total Fees: ₦${student.totalFee.toLocaleString()}
- Outstanding Balance: ₦${student.balance.toLocaleString()}
- Payment Deadline: ${deadlineStr}

We kindly request that you settle the outstanding balance before the deadline to avoid any inconvenience to your child's academic activities.

For payment details or assistance, please contact the school office.

Thank you for your cooperation.

${settings.schoolName}`;

      return { 
        phone: student.phone, 
        message,
        studentName: student.name,
        class: student.class,
        balance: student.balance
      };
    });

    setSmsData(smsMessages);
    setShowSmsModal(true);
  };

  // Group unpaid students by class
  const unpaidByClass = useMemo(() => {
    const grouped: Record<string, typeof unpaidStudents> = {};
    unpaidStudents.forEach(student => {
      if (!grouped[student.class]) {
        grouped[student.class] = [];
      }
      grouped[student.class].push(student);
    });
    return grouped;
  }, [unpaidStudents]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Reports & Exports</h2>
        <button 
          onClick={sendBulkSMS}
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          disabled={unpaidStudents.length === 0}
        >
          <i className="fas fa-sms mr-2"></i>Send SMS to Unpaid Students ({unpaidStudents.length})
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold">Unpaid Students (By Class)</h3>
            <button 
              onClick={exportUnpaidByClass}
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 text-sm"
            >
              <i className="fas fa-file-csv mr-2"></i>Export CSV
            </button>
          </div>
          <div className="space-y-4">
            {Object.entries(unpaidByClass).map(([className, classStudents]) => (
              <div key={className} className="border rounded-lg overflow-hidden">
                <div className="bg-gray-100 px-4 py-2 font-bold">
                  {className} ({classStudents.length} students)
                </div>
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="p-2 text-left">Name</th>
                      <th className="p-2 text-left">Term</th>
                      <th className="p-2 text-left">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classStudents.map((student) => (
                      <tr key={student.id} className="border-b">
                        <td className="p-2">{student.name}</td>
                        <td className="p-2">{student.term}</td>
                        <td className="p-2 text-red-600">₦{getStudentBalance(student.id, student.term, students, payments).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
            {unpaidStudents.length === 0 && (
              <p className="text-center text-gray-500 py-4">No unpaid students!</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold">Today's Collection</h3>
            <button 
              onClick={exportDaily}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-sm"
            >
              <i className="fas fa-file-csv mr-2"></i>Export CSV
            </button>
          </div>
          <div className="mb-4 bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Total Collected Today:</p>
            <p className="text-2xl font-bold text-green-600">
              ₦{todayPayments.reduce((sum, p) => sum + p.amountPaid, 0).toLocaleString()}
            </p>
          </div>
          <div className="overflow-x-auto max-h-64 overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="p-2 text-left">Student</th>
                  <th className="p-2 text-left">Amount</th>
                  <th className="p-2 text-left">Time</th>
                </tr>
              </thead>
              <tbody>
                {todayPayments.map((payment) => {
                  const student = students.find(s => s.id === payment.studentId);
                  return (
                    <tr key={payment.id} className="border-b">
                      <td className="p-2">{student?.name}</td>
                      <td className="p-2">₦{payment.amountPaid.toLocaleString()}</td>
                      <td className="p-2">{new Date(payment.date).toLocaleTimeString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Export Student Names by Class */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold">
            <i className="fas fa-file-csv text-green-600 mr-2"></i>
            Export Student Names by Class
          </h3>
          <button
            onClick={() => setShowStudentExport(!showStudentExport)}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
          >
            {showStudentExport ? 'Hide' : 'Show'} Options
          </button>
        </div>

        {showStudentExport && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">Select classes to export student names:</p>

            {/* Select/Deselect All */}
            <div className="flex space-x-3">
              <button
                onClick={() => setExportSelectedClasses([...CLASS_OPTIONS])}
                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                <i className="fas fa-check-double mr-1"></i>Select All
              </button>
              <button
                onClick={() => setExportSelectedClasses([])}
                className="text-sm text-gray-600 hover:text-gray-800 font-medium"
              >
                <i className="fas fa-times mr-1"></i>Deselect All
              </button>
            </div>

            {/* Class Checkboxes */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
              {CLASS_OPTIONS.map(className => {
                const count = students.filter(s => s.class === className).length;
                const isSelected = exportSelectedClasses.includes(className);
                return (
                  <button
                    key={className}
                    onClick={() => {
                      setExportSelectedClasses(prev =>
                        prev.includes(className)
                          ? prev.filter(c => c !== className)
                          : [...prev, className]
                      );
                    }}
                    className={`p-2 rounded-lg border-2 text-left text-sm transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    } ${count === 0 ? 'opacity-50' : ''}`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{className}</span>
                      {isSelected && <i className="fas fa-check text-blue-600 text-xs"></i>}
                    </div>
                    <p className="text-xs text-gray-500">{count} student{count !== 1 ? 's' : ''}</p>
                  </button>
                );
              })}
            </div>

            {/* Preview */}
            {exportSelectedClasses.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4 max-h-60 overflow-y-auto">
                <p className="text-sm font-bold text-gray-700 mb-2">
                  Preview ({students.filter(s => exportSelectedClasses.includes(s.class)).length} students):
                </p>
                {exportSelectedClasses.sort((a, b) => CLASS_OPTIONS.indexOf(a) - CLASS_OPTIONS.indexOf(b)).map(className => {
                  const classStudents = students.filter(s => s.class === className);
                  if (classStudents.length === 0) return null;
                  return (
                    <div key={className} className="mb-2">
                      <p className="text-xs font-bold text-blue-600">{className} ({classStudents.length})</p>
                      {classStudents.map((s, i) => (
                        <p key={s.id} className="text-xs text-gray-600 ml-3">{i + 1}. {s.name}</p>
                      ))}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Export Type Selector */}
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-bold text-gray-700 mb-3">
                <i className="fas fa-file-export mr-2"></i>Select Export Type:
              </p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setExportType('names')}
                  className={`p-3 rounded-lg border-2 text-left transition-all ${
                    exportType === 'names' 
                      ? 'border-green-500 bg-green-50' 
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <i className={`fas fa-list text-lg ${exportType === 'names' ? 'text-green-600' : 'text-gray-400'}`}></i>
                    <div>
                      <p className="font-bold text-sm text-gray-800">Names Only</p>
                      <p className="text-xs text-gray-500">Export CSV with student names</p>
                    </div>
                  </div>
                  {exportType === 'names' && <i className="fas fa-check-circle text-green-600 text-xs mt-1"></i>}
                </button>
                <button
                  onClick={() => setExportType('names-passport')}
                  className={`p-3 rounded-lg border-2 text-left transition-all ${
                    exportType === 'names-passport' 
                      ? 'border-green-500 bg-green-50' 
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <i className={`fas fa-id-badge text-lg ${exportType === 'names-passport' ? 'text-green-600' : 'text-gray-400'}`}></i>
                    <div>
                      <p className="font-bold text-sm text-gray-800">Names + Passport</p>
                      <p className="text-xs text-gray-500">Export PDF with photos</p>
                    </div>
                  </div>
                  {exportType === 'names-passport' && <i className="fas fa-check-circle text-green-600 text-xs mt-1"></i>}
                </button>
              </div>
            </div>

            {/* Export Button */}
            <button
              onClick={() => {
                if (exportSelectedClasses.length === 0) {
                  alert('Please select at least one class!');
                  return;
                }
                const selectedStudents = students
                  .filter(s => exportSelectedClasses.includes(s.class))
                  .sort((a, b) => {
                    const classCompare = CLASS_OPTIONS.indexOf(a.class) - CLASS_OPTIONS.indexOf(b.class);
                    if (classCompare !== 0) return classCompare;
                    return a.name.localeCompare(b.name);
                  });

                if (exportType === 'names') {
                  // CSV export - names only
                  const headers = ['S/N', 'Student Name', 'Class', 'Admission No'];
                  const csvData = [
                    headers,
                    ...selectedStudents.map((s, i) => [
                      (i + 1).toString(),
                      s.name,
                      s.class,
                      s.admissionNumber
                    ])
                  ];
                  exportToCSV(csvData, `student_names_${new Date().toISOString().split('T')[0]}.csv`);
                } else {
                  // PDF export - names with passport photos
                  const doc = new jsPDF();
                  const pw = doc.internal.pageSize.getWidth();
                  let py = 20;

                  // Title
                  doc.setFontSize(16);
                  doc.setFont('helvetica', 'bold');
                  doc.setTextColor(22, 101, 52);
                  doc.text('Student List with Passport Photos', pw / 2, py, { align: 'center' });
                  py += 8;
                  doc.setFontSize(10);
                  doc.setFont('helvetica', 'normal');
                  doc.setTextColor(100, 100, 100);
                  doc.text(`Generated: ${new Date().toLocaleDateString()} | Classes: ${exportSelectedClasses.join(', ')}`, pw / 2, py, { align: 'center' });
                  py += 10;

                  let currentClass = '';
                  let sn = 0;

                  selectedStudents.forEach((student) => {
                    // Check if new page needed
                    if (py > 260) {
                      doc.addPage();
                      py = 20;
                    }

                    // Class header
                    if (student.class !== currentClass) {
                      currentClass = student.class;
                      sn = 0;
                      if (py > 240) { doc.addPage(); py = 20; }
                      doc.setFillColor(22, 101, 52);
                      doc.rect(20, py - 4, pw - 40, 8, 'F');
                      doc.setFontSize(11);
                      doc.setFont('helvetica', 'bold');
                      doc.setTextColor(255, 255, 255);
                      doc.text(currentClass, 25, py + 2);
                      py += 12;
                    }

                    sn++;

                    // Student row with photo placeholder
                    doc.setDrawColor(200, 200, 200);
                    doc.setLineWidth(0.3);
                    doc.rect(20, py - 4, pw - 40, 22, 'S');

                    // Photo
                    if (student.passport) {
                      try {
                        doc.addImage(student.passport, 'JPEG', 22, py - 3, 18, 18);
                      } catch {
                        doc.setFillColor(240, 240, 240);
                        doc.rect(22, py - 3, 18, 18, 'F');
                        doc.setFontSize(7);
                        doc.setTextColor(150, 150, 150);
                        doc.text('No Photo', 25, py + 8);
                      }
                    } else {
                      doc.setFillColor(240, 240, 240);
                      doc.rect(22, py - 3, 18, 18, 'F');
                      doc.setFontSize(7);
                      doc.setTextColor(150, 150, 150);
                      doc.text('No Photo', 25, py + 8);
                    }

                    // Student info
                    doc.setFontSize(11);
                    doc.setFont('helvetica', 'bold');
                    doc.setTextColor(30, 30, 30);
                    doc.text(`${sn}. ${student.name}`, 44, py + 3);
                    doc.setFontSize(9);
                    doc.setFont('helvetica', 'normal');
                    doc.setTextColor(100, 100, 100);
                    doc.text(`Class: ${student.class} | Adm: ${student.admissionNumber} | Phone: ${student.parentPhone}`, 44, py + 10);

                    py += 24;
                  });

                  // Page numbers
                  const totalPages = doc.getNumberOfPages();
                  for (let i = 1; i <= totalPages; i++) {
                    doc.setPage(i);
                    doc.setFontSize(8);
                    doc.setTextColor(150, 150, 150);
                    doc.text(`Page ${i} of ${totalPages}`, pw / 2, 290, { align: 'center' });
                  }

                  doc.save(`student_list_with_photos_${new Date().toISOString().split('T')[0]}.pdf`);
                }
              }}
              disabled={exportSelectedClasses.length === 0}
              className={`w-full text-white py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed ${
                exportType === 'names' 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-purple-600 hover:bg-purple-700'
              }`}
            >
              <i className={`fas ${exportType === 'names' ? 'fa-file-csv' : 'fa-file-pdf'} mr-2`}></i>
              {exportType === 'names' 
                ? `Export ${students.filter(s => exportSelectedClasses.includes(s.class)).length} Names to CSV`
                : `Export ${students.filter(s => exportSelectedClasses.includes(s.class)).length} Names + Photos to PDF`
              }
            </button>
          </div>
        )}
      </div>

      {/* SMS Modal */}
      {showSmsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-screen overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Send SMS to Parents with Outstanding Fees</h3>
                <button onClick={() => setShowSmsModal(false)} className="text-gray-500 hover:text-gray-700">
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="mb-4 bg-green-50 p-4 rounded-lg border-2 border-green-200">
                <p className="text-sm text-green-800 font-semibold">
                  <i className="fas fa-check-circle mr-2"></i>
                  SMS will be sent to <strong>{smsData.length} parent(s) with outstanding fees only</strong>
                </p>
                <p className="text-xs text-green-600 mt-1">
                  <i className="fas fa-users mr-1"></i>
                  Students who have fully paid will not receive messages
                </p>
              </div>

              <div className="mb-4 bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <i className="fas fa-calendar-alt mr-2"></i>
                  Payment Deadline Date
                </label>
                <input
                  type="date"
                  value={deadlineDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => {
                    setDeadlineDate(e.target.value);
                    // Regenerate SMS messages with new deadline
                    const newDeadlineStr = new Date(e.target.value).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
                    setSmsData(prevData => prevData.map(sms => {
                      const student = unpaidStudents.find(s => s.name === sms.studentName);
                      if (!student) return sms;
                      const newMessage = `Dear Parent/Guardian,

This is to kindly remind you that the school fees for your child, ${student.name}, in ${student.class} for the ${student.term} is due for payment.

- Total Fees: ₦${student.totalFee.toLocaleString()}
- Outstanding Balance: ₦${sms.balance.toLocaleString()}
- Payment Deadline: ${newDeadlineStr}

We kindly request that you settle the outstanding balance before the deadline to avoid any inconvenience to your child's academic activities.

For payment details or assistance, please contact the school office.

Thank you for your cooperation.

${settings.schoolName}`;
                      return { ...sms, message: newMessage };
                    }));
                  }}
                  className="w-full border-2 border-yellow-300 rounded-lg px-3 py-2 text-lg font-semibold focus:border-yellow-500 focus:outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">
                  <i className="fas fa-clock mr-1"></i>
                  Selected: {new Date(deadlineDate).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              </div>

              <div className="mb-4 flex justify-between items-center">
                <p className="text-sm font-semibold">Progress: {sentCount} / {smsData.length} sent</p>
                <div className="w-48 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full transition-all" 
                    style={{ width: `${(sentCount / smsData.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              {smsData.length > 0 && currentSmsIndex < smsData.length && (
                <div className="border rounded-lg p-4 mb-4 bg-gray-50">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-bold text-lg">{smsData[currentSmsIndex].studentName}</p>
                      <p className="text-sm text-gray-600">Class: {smsData[currentSmsIndex].class} | Phone: {smsData[currentSmsIndex].phone}</p>
                      <p className="text-sm text-red-600">Outstanding: ₦{smsData[currentSmsIndex].balance.toLocaleString()}</p>
                    </div>
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      SMS {currentSmsIndex + 1} of {smsData.length}
                    </span>
                  </div>
                  
                  <div className="bg-white border rounded p-3 mb-3">
                    <p className="text-sm whitespace-pre-wrap font-mono">{smsData[currentSmsIndex].message}</p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const sms = smsData[currentSmsIndex];
                        const encodedMessage = encodeURIComponent(sms.message);
                        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
                        
                        if (isMobile) {
                          window.location.href = `sms:${sms.phone}?body=${encodedMessage}`;
                        } else {
                          window.open(`sms:${sms.phone}?body=${encodedMessage}`, '_blank');
                        }
                        
                        setSentCount(prev => prev + 1);
                        setCurrentSmsIndex(prev => prev + 1);
                      }}
                      className="flex-1 bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 font-semibold"
                    >
                      <i className="fas fa-paper-plane mr-2"></i>
                      Send SMS to This Parent
                    </button>
                    <button
                      onClick={() => {
                        const sms = smsData[currentSmsIndex];
                        navigator.clipboard.writeText(sms.message);
                        alert('Message copied to clipboard!');
                      }}
                      className="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700"
                      title="Copy message to clipboard"
                    >
                      <i className="fas fa-copy"></i>
                    </button>
                  </div>
                </div>
              )}

              {currentSmsIndex >= smsData.length && smsData.length > 0 && (
                <div className="text-center p-8 bg-green-50 rounded-lg">
                  <i className="fas fa-check-circle text-5xl text-green-600 mb-4"></i>
                  <h4 className="text-xl font-bold text-green-800 mb-2">All SMS Messages Sent!</h4>
                  <p className="text-gray-600">You have successfully processed all {smsData.length} messages.</p>
                </div>
              )}

              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => {
                    // Download all messages as text file
                    const smsContent = smsData.map((sms, idx) => 
                      `--- SMS ${idx + 1} ---\nTo: ${sms.phone}\nStudent: ${sms.studentName} (${sms.class})\nBalance: ₦${sms.balance.toLocaleString()}\n\n${sms.message}\n\n`
                    ).join('\n');
                    const blob = new Blob([smsContent], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `sms_messages_${new Date().toISOString().split('T')[0]}.txt`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="flex-1 bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
                >
                  <i className="fas fa-download mr-2"></i>Download All Messages
                </button>
                <button
                  onClick={() => {
                    setCurrentSmsIndex(0);
                    setSentCount(0);
                  }}
                  className="flex-1 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  <i className="fas fa-redo mr-2"></i>Restart
                </button>
                <button
                  onClick={() => {
                    // Regenerate all messages with current deadline date
                    const deadlineStr = new Date(deadlineDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
                    const newSmsData = unpaidStudents.map(student => {
                      const balance = getStudentBalance(student.id, student.term, students, payments);
                      const message = `Dear Parent/Guardian,

This is to kindly remind you that the school fees for your child, ${student.name}, in ${student.class} for the ${student.term} is due for payment.

- Total Fees: ₦${student.totalFee.toLocaleString()}
- Outstanding Balance: ₦${balance.toLocaleString()}
- Payment Deadline: ${deadlineStr}

We kindly request that you settle the outstanding balance before the deadline to avoid any inconvenience to your child's academic activities.

For payment details or assistance, please contact the school office.

Thank you for your cooperation.

${settings.schoolName}`;
                      return {
                        phone: student.parentPhone,
                        message,
                        studentName: student.name,
                        class: student.class,
                        balance
                      };
                    });
                    setSmsData(newSmsData);
                    setCurrentSmsIndex(0);
                    setSentCount(0);
                    alert('Messages updated with new deadline date!');
                  }}
                  className="flex-1 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
                >
                  <i className="fas fa-sync-alt mr-2"></i>Update Messages
                </button>
                <button
                  onClick={() => setShowSmsModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Settings Component
function Settings({ settings, setSettings, currentUser, feeStructures, setFeeStructures, students, setStudents }: { 
  settings: Settings; 
  setSettings: React.Dispatch<React.SetStateAction<Settings>>; 
  currentUser: any;
  feeStructures: any[];
  setFeeStructures: React.Dispatch<React.SetStateAction<any[]>>;
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}) {
  const [schoolName, setSchoolName] = useState(settings.schoolName);
  const [schoolAddress, setSchoolAddress] = useState(settings.schoolAddress);
  const [signaturePreview, setSignaturePreview] = useState(settings.signature);
  const [logoPreview, setLogoPreview] = useState(settings.logo);
  const [receiptFontSize, setReceiptFontSize] = useState(settings.receiptFontSize);
  const [themeColor, setThemeColor] = useState(settings.themeColor || 'teal');
  const [showSignaturePad, setShowSignaturePad] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const sigCanvasRef = React.useRef<HTMLCanvasElement>(null);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#000000';
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignaturePad = () => {
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const saveSignature = () => {
    const canvas = sigCanvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    setSignaturePreview(dataUrl);
    setShowSignaturePad(false);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    setSettings({
      schoolName: schoolName,
      schoolAddress: schoolAddress,
      signature: signaturePreview,
      logo: logoPreview,
      receiptFontSize: receiptFontSize,
      themeColor: themeColor
    });
    alert('Settings saved successfully!');
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">System Settings</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">School Name</label>
          <input
            type="text"
            value={schoolName}
            onChange={(e) => setSchoolName(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">School Address</label>
          <textarea
            value={schoolAddress}
            onChange={(e) => setSchoolAddress(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
            rows={3}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">School Logo</label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            {logoPreview ? (
              <div className="mb-4">
                <img src={logoPreview} alt="Logo Preview" className="h-24 mx-auto object-contain" />
              </div>
            ) : (
              <div className="mb-4 text-gray-400">
                <i className="fas fa-image text-4xl"></i>
                <p>No logo uploaded</p>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleLogoUpload}
              className="hidden"
              id="logo-upload"
            />
            <label 
              htmlFor="logo-upload"
              className="cursor-pointer bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 inline-block"
            >
              <i className="fas fa-upload mr-2"></i>
              {logoPreview ? 'Change Logo' : 'Upload Logo'}
            </label>
            <p className="text-xs text-gray-500 mt-2">Logo will appear on both sides of receipt header</p>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-signature text-blue-600 mr-1"></i>
            Digital Signature
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            {signaturePreview ? (
              <div className="mb-4">
                <div className="bg-white border-2 border-gray-200 rounded-lg p-3 inline-block">
                  <img src={signaturePreview} alt="Signature" className="h-20 mx-auto object-contain" />
                </div>
              </div>
            ) : (
              <div className="mb-4 text-gray-400">
                <i className="fas fa-pen-fancy text-4xl"></i>
                <p className="mt-2">No signature yet</p>
              </div>
            )}
            <div className="flex justify-center space-x-2">
              <button
                type="button"
                onClick={() => setShowSignaturePad(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                <i className="fas fa-pen-fancy mr-2"></i>
                {signaturePreview ? 'Redraw Signature' : 'Draw Signature'}
              </button>
              {signaturePreview && (
                <button
                  type="button"
                  onClick={() => setSignaturePreview(null)}
                  className="bg-red-100 text-red-600 px-4 py-2 rounded hover:bg-red-200"
                >
                  <i className="fas fa-trash mr-1"></i>Remove
                </button>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-2">Draw your signature using touch or mouse</p>
          </div>

          {/* Digital Signature Pad Modal */}
          {showSignaturePad && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-2xl max-w-lg w-full">
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-800">
                      <i className="fas fa-pen-fancy text-blue-600 mr-2"></i>
                      Draw Your Signature
                    </h3>
                    <button
                      onClick={() => setShowSignaturePad(false)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <i className="fas fa-times text-xl"></i>
                    </button>
                  </div>

                  <p className="text-sm text-gray-600 mb-3">
                    Use your finger (mobile) or mouse (desktop) to sign below:
                  </p>

                  {/* Canvas */}
                  <div className="border-2 border-gray-300 rounded-lg overflow-hidden bg-white mb-4">
                    <canvas
                      ref={sigCanvasRef}
                      width={440}
                      height={200}
                      className="w-full cursor-crosshair touch-none"
                      style={{ backgroundColor: '#fff' }}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      onTouchStart={startDrawing}
                      onTouchMove={draw}
                      onTouchEnd={stopDrawing}
                    />
                  </div>

                  <div className="flex space-x-2">
                    <button
                      type="button"
                      onClick={clearSignaturePad}
                      className="flex-1 bg-yellow-100 text-yellow-700 py-2 rounded-lg hover:bg-yellow-200 font-medium"
                    >
                      <i className="fas fa-eraser mr-2"></i>Clear
                    </button>
                    <button
                      type="button"
                      onClick={saveSignature}
                      className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium"
                    >
                      <i className="fas fa-check mr-2"></i>Save Signature
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowSignaturePad(false)}
                      className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Receipt Font Size: {receiptFontSize}px</label>
          <input
            type="range"
            min="10"
            max="20"
            value={receiptFontSize}
            onChange={(e) => setReceiptFontSize(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>Small (10px)</span>
            <span>Large (20px)</span>
          </div>
        </div>

        {/* Theme Color */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-palette mr-1"></i>
            App Theme Color
          </label>
          <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
            {[
              { name: 'teal', bg: 'bg-teal-600', label: 'Teal' },
              { name: 'blue', bg: 'bg-blue-600', label: 'Blue' },
              { name: 'green', bg: 'bg-green-600', label: 'Green' },
              { name: 'purple', bg: 'bg-purple-600', label: 'Purple' },
              { name: 'red', bg: 'bg-red-600', label: 'Red' },
              { name: 'orange', bg: 'bg-orange-600', label: 'Orange' },
              { name: 'pink', bg: 'bg-pink-600', label: 'Pink' },
              { name: 'indigo', bg: 'bg-indigo-600', label: 'Indigo' },
              { name: 'cyan', bg: 'bg-cyan-600', label: 'Cyan' },
              { name: 'amber', bg: 'bg-amber-600', label: 'Amber' },
              { name: 'lime', bg: 'bg-lime-600', label: 'Lime' },
              { name: 'emerald', bg: 'bg-emerald-600', label: 'Emerald' },
              { name: 'sky', bg: 'bg-sky-600', label: 'Sky' },
              { name: 'violet', bg: 'bg-violet-600', label: 'Violet' },
              { name: 'rose', bg: 'bg-rose-600', label: 'Rose' },
              { name: 'fuchsia', bg: 'bg-fuchsia-600', label: 'Fuchsia' },
              { name: 'slate', bg: 'bg-slate-600', label: 'Slate' },
              { name: 'zinc', bg: 'bg-zinc-600', label: 'Zinc' },
              { name: 'stone', bg: 'bg-stone-600', label: 'Stone' },
              { name: 'gray', bg: 'bg-gray-600', label: 'Gray' },
            ].map(color => (
              <button
                key={color.name}
                onClick={() => setThemeColor(color.name)}
                className={`w-full aspect-square rounded-lg ${color.bg} flex items-center justify-center transition-all ${
                  themeColor === color.name ? 'ring-4 ring-offset-2 ring-gray-800 scale-110' : 'hover:scale-105'
                }`}
                title={color.label}
              >
                {themeColor === color.name && <i className="fas fa-check text-white text-xs"></i>}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2">Selected: <strong className="capitalize">{themeColor}</strong></p>
        </div>

        <button 
          onClick={handleSave}
          className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-semibold"
        >
          <i className="fas fa-save mr-2"></i>Save Settings
        </button>

        <div className="border-t pt-6 mt-6">
          <h3 className="font-bold text-gray-700 mb-2">
            <i className="fas fa-database text-teal-600 mr-2"></i>
            Database & Storage
          </h3>
          <DatabaseInfo />
          <div className="mt-4"></div>
          <button 
            onClick={() => {
              const pin = prompt('Enter Payment PIN to reset all data:');
              if (!pin) return;
              const storedPIN = localStorage.getItem('paymentPIN') || '8562';
              if (pin !== storedPIN) {
                alert('❌ Incorrect PIN. Reset cancelled.');
                return;
              }
              if(confirm('⚠️ WARNING: This will permanently delete ALL data including students, payments, settings, and receipts. This cannot be undone!\n\nAre you absolutely sure?')) {
                dbClearAll().then(() => {
                  localStorage.clear();
                  window.location.reload();
                });
              }
            }}
            className="w-full bg-red-100 text-red-600 border border-red-300 py-2 rounded hover:bg-red-200"
          >
            <i className="fas fa-trash-alt mr-2"></i>Reset All Data
          </button>
          <p className="text-xs text-gray-500 mt-2 text-center">
            <i className="fas fa-lock mr-1"></i>Requires Payment PIN to reset
          </p>
        </div>

        

        {/* Fee Structure Section - Admin Only */}
        {currentUser?.role === 'admin' && (
          <div className="border-t pt-6 mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-700 flex items-center">
                <i className="fas fa-file-invoice-dollar text-blue-600 mr-2"></i>
                Fee Structure
              </h3>
              <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-medium">
                Admin Only
              </span>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Set fees for each class and term. Fees will auto-fill when adding students.
            </p>
            <FeeStructureInline feeStructures={feeStructures} setFeeStructures={setFeeStructures} />
          </div>
        )}

        {/* Credential Management - All Users */}
        <div className="border-t pt-6 mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-700 flex items-center">
              <i className="fas fa-user-cog text-blue-600 mr-2"></i>
              Account & Security
            </h3>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            Change your password and payment PIN. Use your current password for verification.
          </p>
          <CredentialManagement currentUser={currentUser} />
        </div>

        {/* Class Promotion - Admin Only */}
        {currentUser?.role === 'admin' && (
          <div className="border-t pt-6 mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-700 flex items-center">
                <i className="fas fa-level-up-alt text-blue-600 mr-2"></i>
                Class Promotion & Graduation
              </h3>
              <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-medium">
                Admin Only
              </span>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Promote students to the next class automatically. SS3 students will be moved to the Graduate list.
            </p>
            <ClassPromotion students={students} setStudents={setStudents} />
          </div>
        )}
      </div>
    </div>
  );
}

// Database Info Component
function DatabaseInfo() {
  const [info, setInfo] = useState<{ used: string; stores: Record<string, number> } | null>(null);
  const [quota, setQuota] = useState<{ used: number; quota: number; percent: number } | null>(null);
  const [persistent, setPersistent] = useState<boolean | null>(null);

  useEffect(() => {
    dbGetSize().then(setInfo);
    getStorageQuota().then(setQuota);
    if (navigator.storage && navigator.storage.persisted) {
      navigator.storage.persisted().then(setPersistent);
    }
  }, []);

  if (!info) return null;

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const storeLabels: Record<string, string> = {
    students: 'Students',
    payments: 'Payments',
    settings: 'Settings',
    feeStructures: 'Fee Structures',
    graduates: 'Graduates',
    users: 'Users',
    logs: 'Logs',
  };

  return (
    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
      {/* Storage Bar */}
      {quota && quota.quota > 0 && (
        <div>
          <div className="flex justify-between text-xs text-gray-600 mb-1">
            <span>Used: {formatBytes(quota.used)}</span>
            <span>Available: {formatBytes(quota.quota)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className={`h-3 rounded-full ${quota.percent < 50 ? 'bg-green-500' : quota.percent < 80 ? 'bg-yellow-500' : 'bg-red-500'}`}
              style={{ width: `${Math.max(1, quota.percent)}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 mt-1 text-right">{quota.percent}% used</p>
        </div>
      )}

      {/* Record Counts */}
      <div className="grid grid-cols-3 gap-2">
        {Object.entries(info.stores).filter(([_, count]) => count > 0 || ['students','payments','graduates'].includes(_)).map(([store, count]) => (
          <div key={store} className="bg-white rounded p-2 border text-center">
            <p className="text-xl font-bold text-teal-600">{count}</p>
            <p className="text-xs text-gray-500">{storeLabels[store] || store}</p>
          </div>
        ))}
      </div>

      {/* Status */}
      <div className="space-y-1">
        <div className="flex items-center text-xs text-green-600">
          <i className="fas fa-database mr-2"></i>
          <span className="font-medium">IndexedDB Active — 500MB+ capacity</span>
        </div>
        <div className={`flex items-center text-xs ${persistent ? 'text-green-600' : 'text-yellow-600'}`}>
          <i className={`fas ${persistent ? 'fa-lock' : 'fa-unlock'} mr-2`}></i>
          <span className="font-medium">
            {persistent ? 'Persistent Storage — Data protected from auto-delete' : 'Standard Storage — Data may be cleared if device is low on space'}
          </span>
        </div>
        <div className="flex items-center text-xs text-green-600">
          <i className="fas fa-wifi-slash mr-2"></i>
          <span className="font-medium">Works Offline — All data stored locally</span>
        </div>
      </div>
    </div>
  );
}

// Main App Component
function App() {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [showDeveloperInfo, setShowDeveloperInfo] = useState(false);

  // App State
  const [currentView, setCurrentView] = useState('dashboard');
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('students');
    return saved ? JSON.parse(saved) : initialStudents;
  });
  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem('payments');
    return saved ? JSON.parse(saved) : initialPayments;
  });
  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('settings');
    return saved ? JSON.parse(saved) : initialSettings;
  });
  const [feeStructures, setFeeStructures] = useState<any[]>(() => {
    const saved = localStorage.getItem('feeStructures');
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedReceipt, setSelectedReceipt] = useState<Payment | null>(null);
  const [bluetoothDevice, setBluetoothDevice] = useState<any | null>(null);
  const [showPINModal, setShowPINModal] = useState(false);
  const [pendingPaymentData, setPendingPaymentData] = useState<any>(null);
  const [dbReady, setDbReady] = useState(false);

  // Load data from IndexedDB on startup
  useEffect(() => {
    const loadFromDB = async () => {
      try {
        // Request persistent storage so browser never auto-deletes data
        await requestPersistentStorage();

        // Migrate localStorage data to IndexedDB first
        await migrateFromLocalStorage();

        // Load from IndexedDB
        const dbStudents = await dbGetAll<Student>(STORES.students);
        if (dbStudents.length > 0) setStudents(dbStudents);

        const dbPayments = await dbGetAll<Payment>(STORES.payments);
        if (dbPayments.length > 0) setPayments(dbPayments);

        const dbSettings = await dbGetSettings('settings');
        if (dbSettings) setSettings(dbSettings);

        const dbFees = await dbGetAll<any>(STORES.feeStructures);
        if (dbFees.length > 0) setFeeStructures(dbFees);

        console.log('[DB] Data loaded from IndexedDB');
      } catch (err) {
        console.log('[DB] IndexedDB load failed, using localStorage', err);
      }
      setDbReady(true);
    };
    loadFromDB();
  }, []);

  // Login Handler
  const handleLogin = (user: any) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
  };

  // Logout Handler
  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('loginTime');
    setCurrentUser(null);
    setIsAuthenticated(false);
    setCurrentView('dashboard');
  };
  
  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [swUpdateAvailable, setSwUpdateAvailable] = useState(false);

  useEffect(() => {
    // Detect iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIOSDevice);
    
    // Check if already dismissed
    const dismissed = localStorage.getItem('pwa_install_dismissed');
    const dismissedAt = dismissed ? parseInt(dismissed) : 0;
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    
    // Don't show if dismissed within last 7 days
    if (dismissed && Date.now() - dismissedAt < sevenDays) {
      return;
    }

    // Listen for install prompt (Android/Desktop)
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      
      // Don't show if running as PWA
      if (window.matchMedia('(display-mode: standalone)').matches) {
        return;
      }
      
      // Show install button after a short delay
      setTimeout(() => setShowInstallPrompt(true), 3000);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    // Listen for SW updates
    const handleSwUpdate = () => {
      setSwUpdateAvailable(true);
    };
    
    window.addEventListener('swUpdate', handleSwUpdate);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true) {
      setShowInstallPrompt(false);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('swUpdate', handleSwUpdate);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      // Android/Desktop - use beforeinstallprompt
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      
      if (outcome === 'accepted') {
        console.log('User accepted the install prompt');
      }
      setDeferredPrompt(null);
    }
    
    setShowInstallPrompt(false);
    localStorage.setItem('pwa_install_dismissed', Date.now().toString());
  };

  const dismissInstallPrompt = () => {
    setShowInstallPrompt(false);
    // Dismiss for 7 days
    localStorage.setItem('pwa_install_dismissed', Date.now().toString());
  };

  const reloadToUpdate = () => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'SKIP_WAITING' });
      window.location.reload();
    }
  };

  useEffect(() => {
    if (!dbReady) return;
    // Save to both IndexedDB and localStorage
    localStorage.setItem('students', JSON.stringify(students));
    localStorage.setItem('payments', JSON.stringify(payments));
    localStorage.setItem('settings', JSON.stringify(settings));
    
    // Save to IndexedDB (async, non-blocking)
    dbSaveAll(STORES.students, students).catch(() => {});
    dbSaveAll(STORES.payments, payments).catch(() => {});
    dbSaveSettings('settings', settings).catch(() => {});
  }, [students, payments, settings, dbReady]);

  // Save fee structures to IndexedDB when changed
  useEffect(() => {
    if (!dbReady) return;
    localStorage.setItem('feeStructures', JSON.stringify(feeStructures));
    dbSaveAll(STORES.feeStructures, feeStructures).catch(() => {});
  }, [feeStructures, dbReady]);

  // Bluetooth connection
  // Bluetooth state
  const [btServer, setBtServer] = useState<any>(null);
  const [btCharacteristic, setBtCharacteristic] = useState<any>(null);

  const connectBluetooth = async () => {
    try {
      // @ts-ignore
      if (!navigator.bluetooth) {
        alert('Bluetooth not supported. Use Chrome on Android or Desktop.');
        return;
      }

      // Disconnect existing device first
      if (bluetoothDevice && btServer) {
        try {
          btServer.disconnect();
        } catch {}
        setBluetoothDevice(null);
        setBtServer(null);
        setBtCharacteristic(null);
        return; // Toggle off
      }

      // Scan for printers - try multiple common thermal printer services
      // @ts-ignore
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '000018f0-0000-1000-8000-00805f9b34fb', // Generic thermal printer
          '0000ff00-0000-1000-8000-00805f9b34fb', // Common Chinese printer
          '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC serial
          '0000ffe0-0000-1000-8000-00805f9b34fb', // HM-10 BLE
          'e7810a71-73ae-499d-8c15-faa9aef0c3f2', // RN4870
          '0000fff0-0000-1000-8000-00805f9b34fb', // Another common
        ]
      });

      if (!device) return;

      setBluetoothDevice(device);

      // Listen for disconnect
      device.addEventListener('gattserverdisconnected', () => {
        setBluetoothDevice(null);
        setBtServer(null);
        setBtCharacteristic(null);
      });

      // Connect to GATT server
      // @ts-ignore
      const server = await device.gatt.connect();
      setBtServer(server);

      // Try to find a writable characteristic
      const serviceUUIDs = [
        '000018f0-0000-1000-8000-00805f9b34fb',
        '0000ff00-0000-1000-8000-00805f9b34fb',
        '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        '0000ffe0-0000-1000-8000-00805f9b34fb',
        'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
        '0000fff0-0000-1000-8000-00805f9b34fb',
      ];

      let foundChar: any = null;

      for (const svcUUID of serviceUUIDs) {
        try {
          const service = await server.getPrimaryService(svcUUID);
          const characteristics = await service.getCharacteristics();
          for (const char of characteristics) {
            if (char.properties.write || char.properties.writeWithoutResponse) {
              foundChar = char;
              break;
            }
          }
          if (foundChar) break;
        } catch {
          continue;
        }
      }

      if (foundChar) {
        setBtCharacteristic(foundChar);
        alert('✅ Printer connected: ' + (device.name || 'Bluetooth Printer') + '\n\nReady to print!');
      } else {
        alert('⚠️ Connected to ' + (device.name || 'device') + ' but no print service found.\n\nTry turning the printer off and on, then reconnect.');
      }

    } catch (error: any) {
      if (error.name === 'NotFoundError') {
        // User cancelled the picker
        return;
      }
      console.error('Bluetooth failed:', error);
      alert('Bluetooth connection failed: ' + (error.message || 'Unknown error'));
      setBluetoothDevice(null);
      setBtServer(null);
      setBtCharacteristic(null);
    }
  };

  // Send data to Bluetooth printer in chunks (optimized for 58mm BLE printers)
  const sendToPrinter = async (data: Uint8Array) => {
    if (!btCharacteristic) return false;
    
    // 58mm BLE printers work best with 20-100 byte chunks
    const CHUNK_SIZE = 20;
    const DELAY = 30; // ms between chunks
    const IMAGE_DELAY = 60; // slower for image data
    const isImage = data.length > 500;
    
    try {
      for (let i = 0; i < data.length; i += CHUNK_SIZE) {
        const chunk = data.slice(i, Math.min(i + CHUNK_SIZE, data.length));
        
        try {
          if (btCharacteristic.properties.writeWithoutResponse) {
            await btCharacteristic.writeValueWithoutResponse(chunk);
          } else {
            await btCharacteristic.writeValue(chunk);
          }
        } catch (writeErr) {
          // Retry once on failure
          await new Promise(r => setTimeout(r, 100));
          try {
            await btCharacteristic.writeValue(chunk);
          } catch {
            console.error('Chunk write failed at byte', i);
            return false;
          }
        }
        
        await new Promise(r => setTimeout(r, isImage ? IMAGE_DELAY : DELAY));
      }
      return true;
    } catch (error) {
      console.error('Print write error:', error);
      return false;
    }
  };

  // Convert image to ESC/POS bitmap for 58mm printer
  // 58mm printer = 384 dots printable width
  // Logo centered, scaled to fit
  const imageToEscPos = async (imageDataUrl: string, maxWidth: number = 384): Promise<Uint8Array> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        
        // Scale logo to fit 58mm width, keep aspect ratio
        let targetW = Math.min(maxWidth, img.width);
        let targetH = Math.floor((targetW / img.width) * img.height);
        
        // Limit height to prevent huge prints
        if (targetH > 300) {
          targetH = 300;
          targetW = Math.floor((targetH / img.height) * img.width);
        }
        
        // Width must be multiple of 8 for ESC/POS
        targetW = Math.ceil(targetW / 8) * 8;
        
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d')!;
        
        // White background
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw centered
        const offsetX = (targetW - Math.min(targetW, Math.floor((targetH / img.height) * img.width))) / 2;
        ctx.drawImage(img, offsetX, 0, targetW - offsetX * 2, targetH);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageData.data;
        const w = canvas.width;
        const h = canvas.height;

        // Use ESC * (bit image) command - most compatible with 58mm printers
        // Process 8 rows at a time
        const commands: number[] = [];
        
        for (let y = 0; y < h; y += 8) {
          // ESC * m nL nH - Select bit image mode
          // m=0: 8-dot single density
          // m=1: 8-dot double density  
          // m=32: 24-dot single density
          // m=33: 24-dot double density
          commands.push(0x1B, 0x2A, 0x00, w & 0xFF, (w >> 8) & 0xFF);
          
          for (let x = 0; x < w; x++) {
            let byte = 0;
            for (let bit = 0; bit < 8; bit++) {
              const py = y + bit;
              if (py < h) {
                const idx = (py * w + x) * 4;
                const gray = pixels[idx] * 0.3 + pixels[idx + 1] * 0.59 + pixels[idx + 2] * 0.11;
                if (gray < 128) {
                  byte |= (0x80 >> bit);
                }
              }
            }
            commands.push(byte);
          }
          commands.push(0x0A); // Line feed after each row of dots
        }

        resolve(new Uint8Array(commands));
      };
      img.onerror = () => {
        console.error('Logo image load failed');
        resolve(new Uint8Array([]));
      };
      img.src = imageDataUrl;
    });
  };

  const printToBluetooth = async (receipt: Payment, student: Student) => {
    if (!bluetoothDevice || !btCharacteristic) {
      alert('Please connect a Bluetooth printer first!\n\nTap the Bluetooth button at the bottom right.');
      return;
    }

    if (!btServer || !btServer.connected) {
      try {
        // @ts-ignore
        const server = await bluetoothDevice.gatt.connect();
        setBtServer(server);
      } catch {
        alert('Printer disconnected. Please reconnect.');
        setBluetoothDevice(null);
        setBtServer(null);
        setBtCharacteristic(null);
        return;
      }
    }

    try {
      const ESC = '\x1B';
      const GS = '\x1D';
      const LF = '\n';

      const pad = (left: string, right: string, width: number = 32) => {
        const space = width - left.length - right.length;
        return left + ' '.repeat(Math.max(1, space)) + right;
      };

      // Initialize printer
      await sendToPrinter(new TextEncoder().encode(ESC + '@' + ESC + '3' + '\x18'));

      // ====== PRINT LOGO AS IMAGE ======
      if (settings.logo) {
        try {
          await sendToPrinter(new TextEncoder().encode(ESC + 'a' + '\x01')); // Center
          const logoBitmap = await imageToEscPos(settings.logo, 192); // Half width for logo
          if (logoBitmap.length > 0) {
            await sendToPrinter(logoBitmap);
            await new Promise(r => setTimeout(r, 300));
            await sendToPrinter(new TextEncoder().encode(LF));
          }
        } catch {}
      }

      // ====== HEADER ======
      let text = '';
      text += ESC + 'a' + '\x01';             // Center
      text += ESC + 'E' + '\x01';             // Bold
      text += ESC + '!' + '\x10';             // Double height
      text += settings.schoolName + LF;
      text += ESC + '!' + '\x00';             // Normal
      text += ESC + 'E' + '\x00';
      text += settings.schoolAddress + LF;
      text += LF;
      text += ESC + 'E' + '\x01';             // Bold
      text += '--- PAYMENT RECEIPT ---' + LF;
      text += ESC + 'E' + '\x00';
      text += LF;

      // Send header
      await sendToPrinter(new TextEncoder().encode(text));
      await new Promise(r => setTimeout(r, 100));

      // ====== RECEIPT INFO ======
      text = '';
      text += ESC + 'a' + '\x00';             // Left
      text += pad('Receipt No', '#' + receipt.id.toString().padStart(6, '0')) + LF;
      text += pad('Date', new Date(receipt.date).toLocaleDateString()) + LF;
      text += pad('Time', new Date(receipt.date).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})) + LF;
      text += LF;

      await sendToPrinter(new TextEncoder().encode(text));

      // ====== STUDENT INFO ======
      text = '';
      text += ESC + 'a' + '\x01';             // Center
      text += ESC + 'E' + '\x01';
      text += '- Student Information -' + LF;
      text += ESC + 'E' + '\x00';
      text += ESC + 'a' + '\x00';             // Left
      text += LF;
      text += pad('Name', student.name) + LF;
      text += pad('Class', student.class) + LF;
      text += pad('Term', receipt.term + ' Term') + LF;
      text += pad('Adm No', student.admissionNumber) + LF;
      text += LF;

      await sendToPrinter(new TextEncoder().encode(text));

      // ====== PAYMENT INFO ======
      text = '';
      text += ESC + 'a' + '\x01';             // Center
      text += ESC + 'E' + '\x01';
      text += '- Payment Details -' + LF;
      text += ESC + 'E' + '\x00';
      text += ESC + 'a' + '\x00';             // Left
      text += LF;
      text += pad('Total Fee', 'N' + receipt.totalFee.toLocaleString()) + LF;
      text += LF;

      await sendToPrinter(new TextEncoder().encode(text));

      // ====== AMOUNT PAID (BIG) ======
      text = '';
      text += ESC + 'a' + '\x01';             // Center
      text += ESC + 'E' + '\x01';             // Bold
      text += ESC + '!' + '\x30';             // Double width + height
      text += 'PAID' + LF;
      text += 'N' + receipt.amountPaid.toLocaleString() + LF;
      text += ESC + '!' + '\x00';             // Normal
      text += ESC + 'E' + '\x00';
      text += LF;

      await sendToPrinter(new TextEncoder().encode(text));
      await new Promise(r => setTimeout(r, 100));

      // ====== BALANCE ======
      text = '';
      text += ESC + 'a' + '\x00';             // Left
      if (receipt.balance === 0) {
        text += ESC + 'a' + '\x01';           // Center
        text += ESC + 'E' + '\x01';
        text += '** FULLY PAID **' + LF;
        text += ESC + 'E' + '\x00';
      } else {
        text += pad('Balance', 'N' + receipt.balance.toLocaleString()) + LF;
      }
      text += LF;

      await sendToPrinter(new TextEncoder().encode(text));

      // ====== SIGNATURE AS IMAGE ======
      if (settings.signature) {
        try {
          await sendToPrinter(new TextEncoder().encode(
            ESC + 'a' + '\x01' + 'Authorized Signature:' + LF
          ));
          await new Promise(r => setTimeout(r, 150));
          const sigBitmap = await imageToEscPos(settings.signature, 160);
          if (sigBitmap.length > 0) {
            await sendToPrinter(sigBitmap);
            await new Promise(r => setTimeout(r, 300));
          }
          await sendToPrinter(new TextEncoder().encode(LF));
        } catch {
          await sendToPrinter(new TextEncoder().encode(
            'Authorized Signature:' + LF + '____________________' + LF
          ));
        }
      } else {
        await sendToPrinter(new TextEncoder().encode(
          ESC + 'a' + '\x01' + 
          'Authorized Signature:' + LF + LF +
          '____________________' + LF
        ));
      }

      // ====== FOOTER ======
      text = '';
      text += ESC + 'a' + '\x01';             // Center
      text += LF;
      text += 'Thank you for your payment!' + LF;
      text += 'Computer generated receipt' + LF;
      text += LF + LF + LF + LF + LF;
      text += GS + 'V' + '\x41' + '\x03';     // Partial cut

      const success = await sendToPrinter(new TextEncoder().encode(text));

      if (success) {
        alert('✅ Receipt printed!');
      } else {
        alert('❌ Print failed. Reconnect printer.');
      }
    } catch (error) {
      console.error('Bluetooth print failed:', error);
      alert('Print failed. Reconnect and try again.');
      setBluetoothDevice(null);
      setBtServer(null);
      setBtCharacteristic(null);
    }
  };

  const exportReceiptPDF = async (_receipt: Payment, student: Student) => {
    const receiptEl = document.querySelector('.receipt-print') as HTMLElement;
    if (!receiptEl) {
      alert('Receipt not found.');
      return;
    }

    try {
      const canvas = await html2canvas(receiptEl, {
        scale: 3,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      canvas.toBlob((blob) => {
        if (blob) {
          const link = document.createElement('a');
          link.download = `receipt_${student.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.png`;
          link.href = URL.createObjectURL(blob);
          link.click();
          URL.revokeObjectURL(link.href);
        }
      }, 'image/png', 1.0);
    } catch {
      alert('Failed to save image. Try the Print button instead.');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const selectedStudent = selectedReceipt ? students.find(s => s.id === selectedReceipt.studentId) : undefined;

  const renderView = () => {
    switch(currentView) {
      case 'dashboard':
        return <Dashboard students={students} payments={payments} settings={settings} />;
      case 'students':
        return <StudentManagement students={students} setStudents={setStudents} payments={payments} feeStructures={feeStructures} />;
      case 'payments':
        return <PaymentModule 
          students={students}
          payments={payments}
          setSelectedReceipt={setSelectedReceipt}
          onRequestPIN={() => setShowPINModal(true)}
          setPendingPayment={setPendingPaymentData}
        />;
      case 'history':
        return <PaymentHistory 
          students={students} 
          payments={payments} 
          onReprintReceipt={(payment) => setSelectedReceipt(payment)} 
        />;
      case 'reports':
        return <Reports students={students} payments={payments} settings={settings} />;
      case 'settings':
        return <Settings settings={settings} setSettings={setSettings} currentUser={currentUser} feeStructures={feeStructures} setFeeStructures={setFeeStructures} students={students} setStudents={setStudents} />;
      default:
        return <Dashboard students={students} payments={payments} settings={settings} />;
    }
  };

  // Show Login Page if not authenticated
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Bar with User Info */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <i className="fas fa-user-circle text-teal-600"></i>
            <span className="font-medium">{currentUser?.name}</span>
            <span className={`px-2 py-0.5 rounded-full text-xs ${
              currentUser?.role === 'admin' ? 'bg-purple-100 text-purple-800' :
              currentUser?.role === 'accountant' ? 'bg-green-100 text-green-800' :
              'bg-blue-100 text-blue-800'
            }`}>
              {currentUser?.role?.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleLogout}
              className="text-sm text-red-600 hover:text-red-800"
            >
              <i className="fas fa-sign-out-alt mr-1"></i>
              Logout
            </button>
          </div>
        </div>
      </div>

      <Navigation currentView={currentView} setCurrentView={setCurrentView} themeColor={settings.themeColor || 'teal'} />
      <div className="container mx-auto px-4 py-8">
        {renderView()}
      </div>
      {selectedReceipt && selectedStudent && (
        <ReceiptModal 
          receipt={selectedReceipt}
          settings={settings}
          student={selectedStudent}
          onClose={() => setSelectedReceipt(null)}
          onPrint={handlePrint}
          onPrintBluetooth={() => printToBluetooth(selectedReceipt, selectedStudent)}
          onExportPDF={() => exportReceiptPDF(selectedReceipt, selectedStudent)}
        />
      )}
      {/* Payment PIN Modal */}
      {showPINModal && (
        <PaymentPIN
          onVerify={() => {
            setShowPINModal(false);
            // Process the pending payment after PIN verification
            if (pendingPaymentData) {
              const newPayment = {
                id: Date.now(),
                studentId: pendingPaymentData.studentId,
                term: pendingPaymentData.term,
                amountPaid: pendingPaymentData.amount,
                totalFee: pendingPaymentData.totalFee,
                balance: pendingPaymentData.balance - pendingPaymentData.amount,
                date: new Date().toISOString()
              };
              setPayments([...payments, newPayment]);
              setSelectedReceipt(newPayment);
              setPendingPaymentData(null);
            }
          }}
          onCancel={() => {
            setShowPINModal(false);
            setPendingPaymentData(null);
          }}
        />
      )}

      {/* SW Update Available Banner */}
      {swUpdateAvailable && (
        <div className="fixed top-0 left-0 right-0 bg-green-600 text-white p-3 z-50 flex justify-between items-center animate-slide-up">
          <div className="flex items-center">
            <i className="fas fa-sync-alt fa-spin mr-2"></i>
            <span className="text-sm font-medium">New version available!</span>
          </div>
          <button
            onClick={reloadToUpdate}
            className="bg-white text-green-600 px-4 py-1 rounded-lg text-sm font-semibold hover:bg-green-50"
          >
            Update Now
          </button>
        </div>
      )}

      {/* PWA Install Prompt - Android/Desktop */}
      {!isIOS && showInstallPrompt && (
        <div className="fixed bottom-6 left-6 right-20 bg-white rounded-lg shadow-2xl p-4 z-40 border-l-4 border-blue-600 animate-slide-up">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <i className="fas fa-mobile-alt text-blue-600 text-xl"></i>
              </div>
              <div>
                <h4 className="font-bold text-gray-800">Install SchoolFees Pro</h4>
                <p className="text-sm text-gray-600 mt-1">
                  Install this app on your device for quick access and offline support!
                </p>
                <div className="flex items-center space-x-2 mt-2 text-xs text-gray-500">
                  <span className="flex items-center">
                    <i className="fas fa-check-circle text-green-500 mr-1"></i>
                    Works offline
                  </span>
                  <span className="flex items-center">
                    <i className="fas fa-check-circle text-green-500 mr-1"></i>
                    Fast & secure
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleInstallClick}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm font-semibold whitespace-nowrap"
              >
                <i className="fas fa-download mr-1"></i>
                Install
              </button>
              <button
                onClick={dismissInstallPrompt}
                className="text-gray-400 hover:text-gray-600 p-1"
                title="Dismiss"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PWA Install Instructions - iOS */}
      {isIOS && showInstallPrompt && (
        <div className="fixed bottom-6 left-6 right-6 bg-white rounded-lg shadow-2xl p-4 z-40 border-l-4 border-blue-600 animate-slide-up">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-start space-x-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <i className="fab fa-apple text-blue-600 text-xl"></i>
              </div>
              <div>
                <h4 className="font-bold text-gray-800">Install on iPhone/iPad</h4>
                <p className="text-sm text-gray-600 mt-1">
                  To install this app on your iOS device:
                </p>
              </div>
            </div>
            <button
              onClick={dismissInstallPrompt}
              className="text-gray-400 hover:text-gray-600 p-1"
              title="Dismiss"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="bg-gray-50 rounded-lg p-3 space-y-2">
            <p className="text-sm text-gray-700">
              <span className="font-semibold">1.</span> Tap the <i className="fas fa-share-square text-blue-600 mx-1"></i> <strong>Share</strong> button
            </p>
            <p className="text-sm text-gray-700">
              <span className="font-semibold">2.</span> Scroll down and tap <strong>"Add to Home Screen"</strong>
            </p>
            <p className="text-sm text-gray-700">
              <span className="font-semibold">3.</span> Tap <strong>Add</strong> in the top right corner
            </p>
          </div>
          <div className="flex items-center space-x-2 mt-3 text-xs text-gray-500">
            <span className="flex items-center">
              <i className="fas fa-check-circle text-green-500 mr-1"></i>
              Works offline
            </span>
            <span className="flex items-center">
              <i className="fas fa-check-circle text-green-500 mr-1"></i>
              Looks like native app
            </span>
          </div>
        </div>
      )}

      {/* Developer Info Modal */}
      <DeveloperInfo
        isVisible={showDeveloperInfo}
        onClose={() => setShowDeveloperInfo(false)}
      />

      {/* Developer Credit Button */}
      <button
        onClick={() => setShowDeveloperInfo(true)}
        className="fixed bottom-6 left-6 p-4 rounded-full shadow-lg z-30 bg-gradient-to-br from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white transition-all transform hover:scale-110"
        title="Developer Information"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
          <polyline points="16 18 22 12 16 6"></polyline>
          <polyline points="8 6 2 12 8 18"></polyline>
          <line x1="12" y1="2" x2="12" y2="22" strokeDasharray="2 2"></line>
        </svg>
      </button>

      {/* Bluetooth Connect Button - Fixed position */}
      <button
        onClick={connectBluetooth}
        className={`fixed bottom-6 right-6 p-4 rounded-full shadow-lg z-30 transition-all transform hover:scale-110 ${
          bluetoothDevice 
            ? 'bg-gradient-to-br from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700' 
            : 'bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700'
        } text-white`}
        title={bluetoothDevice ? 'Bluetooth Connected' : 'Connect Bluetooth Printer'}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path d="M14.88 12l3.37-3.37c.29-.29.29-.77 0-1.06l-4.25-4.25c-.29-.29-.77-.29-1.06 0L9.57 6.7 7.44 4.57a.75.75 0 10-1.06 1.06l2.13 2.13-2.13 2.13a.75.75 0 101.06 1.06L9.57 8.82l2.68 2.68-2.68 2.68-2.13-2.13a.75.75 0 10-1.06 1.06l2.13 2.13-2.13 2.13a.75.75 0 101.06 1.06l2.13-2.13 3.37 3.37c.29.29.77.29 1.06 0l4.25-4.25c.29-.29.29-.77 0-1.06L14.88 12zm-2.13-6.19l2.68 2.68-2.68 2.68V5.81zm0 12.38v-5.38l2.68 2.68-2.68 2.7z"/>
        </svg>
        {bluetoothDevice && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white animate-ping"></span>
        )}
      </button>
    </div>
  );
}

export default App;
